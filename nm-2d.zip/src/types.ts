export interface User {
  id: string;
  username: string;
  name: string;
  balance: number;
  role: 'admin' | 'user';
}

export interface Bet2D {
  id: string;
  userId: string;
  username: string;
  date: string;
  time: string;
  section: '12:01 PM' | '04:30 PM';
  number: string;
  multiplier: number;
  amount: number;
  status: 'pending' | 'win' | 'lose' | 'cancelled_by_admin';
  winAmount: number;
  commission: number;
  netAmount: number;
  resultNumber?: string;
  createdAt?: string;
}

export interface Bet3D {
  id: string;
  userId: string;
  username: string;
  date: string;
  time: string;
  number: string;
  multiplier: number;
  amount: number;
  status: 'pending' | 'win' | 'lose' | 'cancelled_by_admin';
  winAmount: number;
  commission: number;
  netAmount: number;
  resultNumber?: string;
  winType?: 'direct' | 'toot' | 'adjacent';
  winLabel?: string;
  createdAt?: string;
}

export interface LiveMarketData {
  live: {
    set: string;
    value: string;
    time: string;
    twod: string;
  };
  result: Array<{
    set: string;
    value: string;
    open_time: string;
    twod: string;
  }>;
}

export interface AppSettings {
  serverOnline?: boolean;
  maintenanceMessage?: string;
  betting2D_enabled?: boolean;
  betting3D_enabled?: boolean;
  closedNumbers2D_1201: string[];
  closedNumbers2D_1630: string[];
  closedNumbersDate2D_1201?: string;
  closedNumbersDate2D_1630?: string;
  autoResetDailyClosed?: boolean;
  closedNumbers3D?: string[];
  customLimits2D_1201?: Record<string, number>;
  customLimits2D_1630?: Record<string, number>;
  customLimits3D?: Record<string, number>;
  limit2D?: number;
  limit3D?: number;
  closeTime2D_1201: string;
  closeTime2D_1630: string;
  closeTime3D: string;
  closeDays2D?: string[];
  multiplier2D: number;
  commissionRate2D: number;
  multiplier3D: number;
  multiplier3D_toot?: number;
  multiplier3D_chai?: number;
  commissionRate3D: number;
  manual3DResult: string;
  official3DResults?: Record<string, string>;
  announcement?: string;
  minVersion?: string;
  serviceLink1: { label: string; url: string };
  serviceLink2: { label: string; url: string };
}

export interface DailyLedgerEntry {
  date: string;
  totalBet: number;
  winLose: number;
  commission: number;
  netTotal: number;
  bets: (Bet2D | Bet3D)[];
}
