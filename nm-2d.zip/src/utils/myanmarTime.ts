/**
 * Myanmar Time utilities (MST/MMT: UTC + 06:30)
 * Thai Stock Exchange Trading Schedule and Closing Rules
 */

export function getMyanmarDateTime(): Date {
  const now = new Date();
  // Myanmar is UTC + 6:30
  const utc = now.getTime() + now.getTimezoneOffset() * 60000;
  return new Date(utc + 6.5 * 3600000);
}

export function formatMyanmarDate(d = getMyanmarDateTime()): string {
  const pad = (n: number) => n.toString().padStart(2, '0');
  return `${pad(d.getDate())}-${pad(d.getMonth() + 1)}-${d.getFullYear()}`;
}

export function formatMyanmarTime(d = getMyanmarDateTime()): string {
  const pad = (n: number) => n.toString().padStart(2, '0');
  const hours = d.getHours();
  const minutes = pad(d.getMinutes());
  const seconds = pad(d.getSeconds());
  const ampm = hours >= 12 ? 'PM' : 'AM';
  const h12 = hours % 12 || 12;
  return `${pad(h12)}:${minutes}:${seconds} ${ampm}`;
}

/**
 * Check if today is weekend (Saturday = 6, Sunday = 0)
 * Stock market is strictly closed on weekends.
 */
export function isMarketWeekend(d = getMyanmarDateTime()): boolean {
  const day = d.getDay();
  return day === 0 || day === 6;
}

/**
 * Check if current time is within stock market trading hours
 * Monday - Friday: Morning 9:00 AM - 12:00 PM MMT, Afternoon 1:30 PM - 4:00 PM MMT
 */
export function isMarketOpenNow(d = getMyanmarDateTime()): boolean {
  if (isMarketWeekend(d)) return false;
  const currentMin = d.getHours() * 60 + d.getMinutes();
  const morningOpen = 9 * 60;
  const morningClose = 12 * 60 + 5;
  const afternoonOpen = 13 * 60 + 30;
  const afternoonClose = 16 * 60 + 35;
  return (currentMin >= morningOpen && currentMin <= morningClose) ||
         (currentMin >= afternoonOpen && currentMin <= afternoonClose);
}

/**
 * Exact section closing rules:
 * - 12:01 section closes 10 minutes before result: 11:50 AM MMT
 * - 4:30 section closes at 03:50 PM (15:50 MMT)
 * - If weekend, both sections are closed.
 */
export function getSectionCloseStatus(section: '12:01 PM' | '04:30 PM') {
  const mmt = getMyanmarDateTime();
  const weekend = isMarketWeekend(mmt);
  const currentMinutes = mmt.getHours() * 60 + mmt.getMinutes();

  if (weekend) {
    return {
      closeTimeLabel: section === '12:01 PM' ? '11:50 AM' : '03:50 PM',
      isClosed: true,
      remainingText: 'Market Closed (Weekend)',
      isWeekend: true,
    };
  }

  if (section === '12:01 PM') {
    const closeMin = 11 * 60 + 50; // 11:50 AM MMT
    const isClosed = currentMinutes >= closeMin;
    const diff = Math.max(0, closeMin - currentMinutes);
    const h = Math.floor(diff / 60);
    const m = diff % 60;
    return {
      closeTimeLabel: '11:50 AM',
      isClosed,
      remainingText: isClosed ? 'Closed' : `${h > 0 ? `${h}h ` : ''}${m}m left`,
      isWeekend: false,
    };
  } else {
    const closeMin = 15 * 60 + 50; // 03:50 PM MMT
    const isClosed = currentMinutes >= closeMin;
    const diff = Math.max(0, closeMin - currentMinutes);
    const h = Math.floor(diff / 60);
    const m = diff % 60;
    return {
      closeTimeLabel: '03:50 PM',
      isClosed,
      remainingText: isClosed ? 'Closed' : `${h > 0 ? `${h}h ` : ''}${m}m left`,
      isWeekend: false,
    };
  }
}

/**
 * 3D Official Thai Government Lottery Schedule
 * Only drawn on the 1st and 16th of each month.
 */
export function get3DLotteryStatus(d = getMyanmarDateTime()) {
  const dayOfMonth = d.getDate();
  const isDrawDay = dayOfMonth === 1 || dayOfMonth === 16;
  const currentMin = d.getHours() * 60 + d.getMinutes();
  const closeMin = 14 * 60 + 30; // 02:30 PM MMT on draw day

  const isClosed = !isDrawDay || currentMin >= closeMin;

  // Calculate next draw date string
  let nextDrawDate = '';
  if (dayOfMonth < 1) {
    nextDrawDate = `01-${(d.getMonth() + 1).toString().padStart(2, '0')}-${d.getFullYear()}`;
  } else if (dayOfMonth <= 16) {
    nextDrawDate = `16-${(d.getMonth() + 1).toString().padStart(2, '0')}-${d.getFullYear()}`;
  } else {
    const nextMonth = d.getMonth() + 2 > 12 ? 1 : d.getMonth() + 2;
    const nextYear = d.getMonth() + 2 > 12 ? d.getFullYear() + 1 : d.getFullYear();
    nextDrawDate = `01-${nextMonth.toString().padStart(2, '0')}-${nextYear}`;
  }

  return {
    isDrawDay,
    isClosed,
    closeTimeLabel: '02:30 PM (1st & 16th)',
    nextDrawDate,
    statusText: isDrawDay
      ? (isClosed ? 'Draw in Progress / Closed' : 'Draw Today (Closes 02:30 PM)')
      : `Next Draw: ${nextDrawDate}`,
  };
}

/**
 * Generate 3D Permutations for [R] reverse button
 * e.g., '112' -> ['112', '121', '211']
 * e.g., '123' -> ['123', '132', '213', '231', '312', '321']
 */
export function generate3DPermutations(input: string): string[] {
  const digits = input.trim();
  if (digits.length !== 3) return [digits];

  const results = new Set<string>();
  const arr = digits.split('');

  function permute(subArr: string[], memo: string[] = []) {
    if (subArr.length === 0) {
      results.add(memo.join(''));
    } else {
      for (let i = 0; i < subArr.length; i++) {
        const curr = subArr.slice();
        const next = curr.splice(i, 1);
        permute(curr.slice(), memo.concat(next));
      }
    }
  }

  permute(arr);
  return Array.from(results).sort();
}

/**
 * 3D Winning Calculation:
 * Result: e.g. "456"
 * 1. Direct (ဒဲ့/တိုက်ရိုက်): "456" -> 500x
 * 2. Permutation / Toot (ပတ်လည်): "654", "645", "546", "564", "465" -> 10x
 * 3. Adjacent / Chai (အနီးစပ် / ချာ: +/- 1): "457" (+1) and "455" (-1) -> 10x
 */
export function get3DWinningNumbersBreakdown(resultNumber: string) {
  if (!resultNumber || resultNumber.trim().length !== 3) {
    return { direct: '', toot: [] as string[], adjacent: [] as string[] };
  }
  const direct = resultNumber.trim();
  const perms = generate3DPermutations(direct).filter((p) => p !== direct);

  const val = parseInt(direct, 10);
  const plus1 = ((val + 1) % 1000).toString().padStart(3, '0');
  const minus1 = ((val - 1 + 1000) % 1000).toString().padStart(3, '0');
  const adjacent = Array.from(new Set([plus1, minus1])).filter((n) => n !== direct);

  return { direct, toot: perms, adjacent };
}

export function calculate3DWin(
  betNumber: string,
  resultNumber: string,
  multiplierDirect = 500,
  multiplierToot = 10,
  multiplierAdjacent = 10
): {
  isWin: boolean;
  winType: 'direct' | 'toot' | 'adjacent' | null;
  multiplier: number;
  label: string;
} {
  if (!resultNumber || resultNumber.trim().length !== 3 || !betNumber || betNumber.trim().length !== 3) {
    return { isWin: false, winType: null, multiplier: 0, label: 'ရှုံး' };
  }

  const trimmedBet = betNumber.trim();
  const trimmedRes = resultNumber.trim();

  // 1. Direct match (ဒဲ့ပေါက်)
  if (trimmedBet === trimmedRes) {
    return {
      isWin: true,
      winType: 'direct',
      multiplier: multiplierDirect,
      label: `👑 ဒဲ့ပေါက် (${multiplierDirect}ဆ)`,
    };
  }

  // 2. Toot / Permutations (ပတ်လည်)
  const perms = generate3DPermutations(trimmedRes).filter((p) => p !== trimmedRes);
  if (perms.includes(trimmedBet)) {
    return {
      isWin: true,
      winType: 'toot',
      multiplier: multiplierToot,
      label: `🔄 ပတ်လည်ပေါက် (${multiplierToot}ဆ)`,
    };
  }

  // 3. Adjacent / Chai (အနီးစပ် / ချာ: +/- 1)
  const val = parseInt(trimmedRes, 10);
  const plus1 = ((val + 1) % 1000).toString().padStart(3, '0');
  const minus1 = ((val - 1 + 1000) % 1000).toString().padStart(3, '0');

  if (trimmedBet === plus1 || trimmedBet === minus1) {
    return {
      isWin: true,
      winType: 'adjacent',
      multiplier: multiplierAdjacent,
      label: `🎯 အနီးစပ်/ချာပေါက် (${multiplierAdjacent}ဆ)`,
    };
  }

  return { isWin: false, winType: null, multiplier: 0, label: 'ရှုံး' };
}
