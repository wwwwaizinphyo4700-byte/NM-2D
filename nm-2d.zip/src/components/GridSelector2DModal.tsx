import { useState, useEffect } from 'react';
import { X, Check, Trash2, Sliders, ShieldAlert, Sparkles, RefreshCw, CheckSquare } from 'lucide-react';
import { playTouchSound } from '../utils/audio.ts';

interface GridSelector2DModalProps {
  isOpen: boolean;
  onClose: () => void;
  section: '12:01 PM' | '04:30 PM';
  onSectionChange: (sec: '12:01 PM' | '04:30 PM') => void;
  initialClosedNumbers: string[];
  initialCustomLimits: Record<string, number>;
  defaultLimit: number;
  onSave: (closedNumbers: string[], customLimits: Record<string, number>) => void;
}

export default function GridSelector2DModal({
  isOpen,
  onClose,
  section,
  onSectionChange,
  initialClosedNumbers,
  initialCustomLimits,
  defaultLimit,
  onSave,
}: GridSelector2DModalProps) {
  const [closedSet, setClosedSet] = useState<Set<string>>(new Set(initialClosedNumbers));
  const [customLimits, setCustomLimits] = useState<Record<string, number>>(initialCustomLimits || {});
  const [activeMode, setActiveMode] = useState<'close' | 'limit'>('close');
  
  // Multi-select for Limit mode
  const [selectedLimitNums, setSelectedLimitNums] = useState<Set<string>>(new Set());
  const [batchLimitAmount, setBatchLimitAmount] = useState<string>('20000');

  useEffect(() => {
    setClosedSet(new Set(initialClosedNumbers));
    setCustomLimits(initialCustomLimits || {});
    setSelectedLimitNums(new Set());
  }, [initialClosedNumbers, initialCustomLimits, section]);

  if (!isOpen) return null;

  // Toggle single number closed/open or limit selection
  const handleToggleNumber = (numStr: string) => {
    playTouchSound('tap');
    if (activeMode === 'close') {
      const next = new Set(closedSet);
      if (next.has(numStr)) {
        next.delete(numStr);
      } else {
        next.add(numStr);
      }
      setClosedSet(next);
    } else {
      // Multiple selection in Limit mode
      const next = new Set(selectedLimitNums);
      if (next.has(numStr)) {
        next.delete(numStr);
      } else {
        next.add(numStr);
      }
      setSelectedLimitNums(next);
    }
  };

  // Quick selection helpers
  const handleSelectQuick = (type: 'even' | 'odd' | 'twin' | 'small' | 'big' | 'clear' | 'all') => {
    playTouchSound('select');
    if (activeMode === 'close') {
      const next = new Set(closedSet);
      if (type === 'clear') {
        setClosedSet(new Set());
        return;
      }
      for (let i = 0; i < 100; i++) {
        const s = i.toString().padStart(2, '0');
        const d1 = parseInt(s[0], 10);
        const d2 = parseInt(s[1], 10);
        if (type === 'all') next.add(s);
        else if (type === 'even' && i % 2 === 0) next.add(s);
        else if (type === 'odd' && i % 2 !== 0) next.add(s);
        else if (type === 'twin' && d1 === d2) next.add(s);
        else if (type === 'small' && i < 50) next.add(s);
        else if (type === 'big' && i >= 50) next.add(s);
      }
      setClosedSet(next);
    } else {
      // In limit mode, apply quick select to selectedLimitNums
      const next = new Set(selectedLimitNums);
      if (type === 'clear') {
        setSelectedLimitNums(new Set());
        return;
      }
      for (let i = 0; i < 100; i++) {
        const s = i.toString().padStart(2, '0');
        const d1 = parseInt(s[0], 10);
        const d2 = parseInt(s[1], 10);
        if (type === 'all') next.add(s);
        else if (type === 'even' && i % 2 === 0) next.add(s);
        else if (type === 'odd' && i % 2 !== 0) next.add(s);
        else if (type === 'twin' && d1 === d2) next.add(s);
        else if (type === 'small' && i < 50) next.add(s);
        else if (type === 'big' && i >= 50) next.add(s);
      }
      setSelectedLimitNums(next);
    }
  };

  const handleSelectHead = (headDigit: number) => {
    playTouchSound('select');
    if (activeMode === 'close') {
      const next = new Set(closedSet);
      for (let i = 0; i < 10; i++) {
        next.add(`${headDigit}${i}`);
      }
      setClosedSet(next);
    } else {
      const next = new Set(selectedLimitNums);
      for (let i = 0; i < 10; i++) {
        next.add(`${headDigit}${i}`);
      }
      setSelectedLimitNums(next);
    }
  };

  // Apply limit to all selected numbers
  const handleApplyBatchLimit = () => {
    const val = Number(batchLimitAmount);
    if (isNaN(val) || val <= 0) return;
    playTouchSound('success');
    const updated = { ...customLimits };
    selectedLimitNums.forEach((num) => {
      updated[num] = val;
    });
    setCustomLimits(updated);
    setSelectedLimitNums(new Set());
  };

  // Clear limit on all selected numbers
  const handleClearBatchLimit = () => {
    playTouchSound('alert');
    const updated = { ...customLimits };
    selectedLimitNums.forEach((num) => {
      delete updated[num];
    });
    setCustomLimits(updated);
    setSelectedLimitNums(new Set());
  };

  const handleRemoveCustomLimit = (numStr: string) => {
    playTouchSound('alert');
    const updated = { ...customLimits };
    delete updated[numStr];
    setCustomLimits(updated);
  };

  const handleConfirmSave = () => {
    playTouchSound('success');
    onSave(Array.from(closedSet).sort(), customLimits);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 select-none overflow-y-auto">
      <div className="w-full max-w-2xl bg-[#0a1122] border border-cyan-500/30 rounded-2xl shadow-2xl flex flex-col max-h-[92vh] overflow-hidden">
        {/* MODAL HEADER */}
        <div className="shrink-0 p-4 bg-[#0d1628] border-b border-slate-800 flex items-center justify-between">
          <div>
            <h2 className="text-base font-black text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              <span>2D 00-99 Quick Grid Selector (ပိတ်ဂဏန်း / သီးသန့် Limit ရွေးရန်)</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              စာရိုက်စရာမလိုဘဲ 00-99 နိပ်ပြီး ပိတ်ဂဏန်းနှင့် သီးသန့် Limit များ စိတ်ကြိုက် သတ်မှတ်နိုင်ပါသည်
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* SECTION & MODE BAR */}
        <div className="shrink-0 p-3 bg-[#080d1a] border-b border-slate-800/80 flex flex-wrap items-center justify-between gap-3">
          {/* Section Selector */}
          <div className="flex items-center gap-1.5 bg-[#0e1628] p-1 rounded-xl border border-slate-700">
            <button
              type="button"
              onClick={() => onSectionChange('12:01 PM')}
              className={`px-3 py-1.5 rounded-lg text-xs font-black transition-all cursor-pointer ${
                section === '12:01 PM'
                  ? 'bg-cyan-400 text-black shadow-md shadow-cyan-400/20'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              12:01 PM Section
            </button>
            <button
              type="button"
              onClick={() => onSectionChange('04:30 PM')}
              className={`px-3 py-1.5 rounded-lg text-xs font-black transition-all cursor-pointer ${
                section === '04:30 PM'
                  ? 'bg-blue-500 text-white shadow-md shadow-blue-500/20'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              04:30 PM Section
            </button>
          </div>

          {/* Mode Switcher: Close Mode vs Custom Limit Mode */}
          <div className="flex items-center gap-1.5 bg-[#0e1628] p-1 rounded-xl border border-slate-700">
            <button
              type="button"
              onClick={() => setActiveMode('close')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                activeMode === 'close'
                  ? 'bg-rose-600 text-white shadow-md shadow-rose-600/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <ShieldAlert className="w-3.5 h-3.5" />
              <span>ပိတ်ဂဏန်း ရွေးမည် ({closedSet.size})</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveMode('limit')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                activeMode === 'limit'
                  ? 'bg-amber-500 text-black shadow-md shadow-amber-500/30 font-black'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Sliders className="w-3.5 h-3.5" />
              <span>သီးသန့် Limit ({Object.keys(customLimits).length})</span>
            </button>
          </div>
        </div>

        {/* QUICK SHORTCUTS (Visible when in Close Mode) */}
        {activeMode === 'close' && (
          <div className="shrink-0 px-4 py-2 bg-[#091122] border-b border-slate-800 flex flex-wrap items-center gap-1.5 text-[11px]">
            <span className="text-slate-400 font-bold mr-1">အမြန်ရွေး:</span>
            <button
              type="button"
              onClick={() => handleSelectQuick('even')}
              className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 cursor-pointer font-medium"
            >
              စုံအားလုံး (50)
            </button>
            <button
              type="button"
              onClick={() => handleSelectQuick('odd')}
              className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 cursor-pointer font-medium"
            >
              မအားလုံး (50)
            </button>
            <button
              type="button"
              onClick={() => handleSelectQuick('twin')}
              className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 cursor-pointer font-medium"
            >
              အပူး (10)
            </button>
            <button
              type="button"
              onClick={() => handleSelectQuick('small')}
              className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 cursor-pointer font-medium"
            >
              00-49
            </button>
            <button
              type="button"
              onClick={() => handleSelectQuick('big')}
              className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 cursor-pointer font-medium"
            >
              50-99
            </button>

            {/* Quick Heads 0 to 9 */}
            <div className="flex items-center gap-1 ml-auto">
              <span className="text-slate-500 text-[10px]">ထိပ်:</span>
              {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((h) => (
                <button
                  key={h}
                  type="button"
                  onClick={() => handleSelectHead(h)}
                  className="w-5 h-5 rounded bg-slate-800 hover:bg-cyan-500/20 text-slate-300 hover:text-cyan-300 text-[10px] font-mono font-bold cursor-pointer"
                >
                  {h}
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={() => handleSelectQuick('clear')}
              className="px-2 py-1 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 cursor-pointer font-bold ml-1"
            >
              အားလုံးရှင်းမည်
            </button>
          </div>
        )}

        {/* CUSTOM LIMIT BATCH BAR (When in Limit Mode) */}
        {activeMode === 'limit' && (
          <div className="shrink-0 p-3 bg-amber-500/10 border-b border-amber-500/30 space-y-2">
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
              <div className="flex items-center gap-1.5 font-bold text-amber-300">
                <CheckSquare className="w-4 h-4 text-amber-400" />
                <span>ရွေးချယ်ထားသော ဂဏန်း: <span className="text-white text-sm font-black font-mono-numbers px-1.5 py-0.5 rounded bg-amber-500/20">{selectedLimitNums.size}</span> ခု</span>
              </div>

              {/* Quick Select Buttons for Limit */}
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => handleSelectQuick('all')}
                  className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-[10px] text-slate-300"
                >
                  အားလုံး (100)
                </button>
                <button
                  type="button"
                  onClick={() => handleSelectQuick('even')}
                  className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-[10px] text-slate-300"
                >
                  စုံ (50)
                </button>
                <button
                  type="button"
                  onClick={() => handleSelectQuick('odd')}
                  className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-[10px] text-slate-300"
                >
                  မ (50)
                </button>
                <button
                  type="button"
                  onClick={() => handleSelectQuick('twin')}
                  className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-[10px] text-amber-300"
                >
                  အပူး (10)
                </button>
                <button
                  type="button"
                  onClick={() => handleSelectQuick('clear')}
                  className="px-2 py-0.5 rounded bg-slate-800 hover:bg-rose-500/20 text-[10px] text-rose-300"
                >
                  ရွေးထားသမျှဖြုတ်မည်
                </button>
              </div>
            </div>

            {/* Batch Amount Selection & Apply */}
            <div className="flex flex-wrap items-center gap-2 pt-1">
              <span className="text-[11px] font-bold text-slate-300">Limit သတ်မှတ်ငွေ:</span>
              {['10000', '20000', '30000', '50000', '100000'].map((amt) => (
                <button
                  key={amt}
                  type="button"
                  onClick={() => {
                    playTouchSound('tap');
                    setBatchLimitAmount(amt);
                  }}
                  className={`px-2.5 py-1 rounded-lg text-xs font-mono-numbers font-bold cursor-pointer transition-all ${
                    batchLimitAmount === amt
                      ? 'bg-amber-400 text-black font-black shadow-md'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                  }`}
                >
                  {Number(amt).toLocaleString()}
                </button>
              ))}

              <div className="flex items-center gap-1.5 ml-auto">
                <input
                  type="number"
                  value={batchLimitAmount}
                  onChange={(e) => setBatchLimitAmount(e.target.value)}
                  placeholder="Custom"
                  className="w-24 px-2 py-1 bg-[#060b17] border border-amber-500/50 rounded-lg text-white font-mono-numbers text-xs font-bold focus:border-amber-400 outline-none"
                />
                <button
                  type="button"
                  onClick={handleApplyBatchLimit}
                  disabled={selectedLimitNums.size === 0 || !batchLimitAmount}
                  className="px-3 py-1 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 disabled:opacity-40 text-black font-black text-xs rounded-lg shadow cursor-pointer active:scale-95 transition-all"
                >
                  သတ်မှတ်မည် ({selectedLimitNums.size})
                </button>
                <button
                  type="button"
                  onClick={handleClearBatchLimit}
                  disabled={selectedLimitNums.size === 0}
                  className="px-2.5 py-1 bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 disabled:opacity-40 text-rose-300 font-bold text-xs rounded-lg cursor-pointer"
                >
                  Limit ဖျက်မည်
                </button>
              </div>
            </div>
          </div>
        )}

        {/* 10x10 NUMBER GRID (00 to 99) */}
        <div className="flex-1 overflow-y-auto p-4 custom-scrollbar">
          <div className="grid grid-cols-10 gap-1.5 sm:gap-2">
            {Array.from({ length: 100 }, (_, i) => {
              const numStr = i.toString().padStart(2, '0');
              const isClosed = closedSet.has(numStr);
              const customLim = customLimits[numStr];
              const isSelectedForLimit = activeMode === 'limit' && selectedLimitNums.has(numStr);

              return (
                <button
                  key={numStr}
                  type="button"
                  onClick={() => handleToggleNumber(numStr)}
                  className={`relative flex flex-col items-center justify-center rounded-xl p-1 sm:p-2 border transition-all cursor-pointer aspect-square ${
                    isSelectedForLimit
                      ? 'bg-amber-400 text-black font-black ring-2 ring-amber-300 shadow-lg scale-105 z-10'
                      : isClosed
                      ? 'bg-rose-600/90 border-rose-400 text-white font-black shadow-md shadow-rose-900/50 scale-[1.02]'
                      : customLim
                      ? 'bg-amber-950/50 border-amber-500 text-amber-200 hover:border-amber-400 ring-1 ring-amber-500/50'
                      : 'bg-[#060b17] border-slate-800 text-slate-300 hover:border-cyan-400/60 hover:text-white'
                  }`}
                >
                  <span className={`text-xs sm:text-sm font-black font-mono-numbers ${isSelectedForLimit ? 'text-black' : ''}`}>
                    {numStr}
                  </span>

                  {isClosed && (
                    <span className="text-[8px] font-black uppercase text-rose-200 tracking-tight leading-none mt-0.5">
                      ပိတ်
                    </span>
                  )}

                  {!isClosed && customLim && (
                    <span className={`text-[8px] font-mono-numbers font-bold leading-none mt-0.5 ${isSelectedForLimit ? 'text-black font-black' : 'text-amber-400'}`}>
                      {customLim >= 1000 ? `${customLim / 1000}K` : customLim}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* ACTIVE CUSTOM LIMITS CHIPS LIST */}
          {Object.keys(customLimits).length > 0 && (
            <div className="mt-5 p-3 rounded-xl bg-[#060b17] border border-slate-800">
              <div className="text-xs font-bold text-amber-400 mb-2 flex items-center justify-between">
                <span>သီးသန့် Limit သတ်မှတ်ထားသော ဂဏန်းများ ({Object.keys(customLimits).length}):</span>
                <span className="text-[10px] text-slate-400">Default Limit: {defaultLimit.toLocaleString()} MMK</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {Object.entries(customLimits).map(([num, lim]) => (
                  <div
                    key={num}
                    className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-mono-numbers font-bold"
                  >
                    <span>{num} :</span>
                    <span className="text-white font-black">{lim.toLocaleString()} MMK</span>
                    <button
                      type="button"
                      onClick={() => handleRemoveCustomLimit(num)}
                      className="ml-1 text-slate-400 hover:text-rose-400 cursor-pointer"
                      title="ဖျက်မည်"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* FOOTER ACTIONS */}
        <div className="shrink-0 p-4 bg-[#0d1628] border-t border-slate-800 flex items-center justify-between gap-3">
          <div className="text-xs text-slate-300">
            ပိတ်ထားသော ဂဏန်း: <span className="font-bold text-rose-400">{closedSet.size} ခု</span> •
            သီးသန့် Limit: <span className="font-bold text-amber-400">{Object.keys(customLimits).length} ခု</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold cursor-pointer"
            >
              မသိမ်းတော့ပါ
            </button>
            <button
              type="button"
              onClick={handleConfirmSave}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black text-xs font-black shadow-lg shadow-cyan-500/25 active:scale-95 transition-all cursor-pointer flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              <span>အတည်ပြုသိမ်းဆည်းမည်</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
