import { useState, useEffect } from 'react';
import { 
  ShieldCheck, Users, UserPlus, Database, Clock, 
  Settings as SettingsIcon, AlertCircle, CheckCircle2, 
  RefreshCw, Power, DollarSign, Trash2, ArrowUpRight, ArrowDownRight,
  TrendingUp, Award, ExternalLink, Calendar, Search, LogOut, Check, X,
  FileSpreadsheet, Lock, Eye, EyeOff, Sparkles, Sliders, Crown, RotateCcw, Target
} from 'lucide-react';
import { AppSettings, User, Bet2D, Bet3D, DailyLedgerEntry } from '../types.ts';
import { formatMyanmarDate, get3DWinningNumbersBreakdown } from '../utils/myanmarTime.ts';
import GridSelector2DModal from './GridSelector2DModal.tsx';

interface WebAdminPortalProps {
  settings: AppSettings;
  onUpdateSettings: (newSettings: AppSettings) => void;
}

export default function WebAdminPortal({
  settings,
  onUpdateSettings,
}: WebAdminPortalProps) {
  // Navigation tabs (Clearly separated: Users | 2D Bets | 3D Bets | Unified Ledger | Closed Numbers | Bet Limits | Controls | Notices)
  const [activeTab, setActiveTab] = useState<'users' | '2d_bets' | '3d_bets' | 'ledger' | 'closed_numbers' | 'limits' | 'controls' | 'announcements'>('users');

  // Admin Auth lock - Password protection with 'waizin4700'
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return sessionStorage.getItem('nm2d_admin_session') === 'authenticated_waizin4700';
    }
    return false;
  });
  const [enteredPassword, setEnteredPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [authError, setAuthError] = useState('');

  // Data states
  const [usersList, setUsersList] = useState<User[]>([]);
  const [bets2D, setBets2D] = useState<Bet2D[]>([]);
  const [bets3D, setBets3D] = useState<Bet3D[]>([]);
  const [ledgerAll, setLedgerAll] = useState<DailyLedgerEntry[]>([]);
  const [ledgerLoading, setLedgerLoading] = useState(false);
  const [selectedLedgerEntry, setSelectedLedgerEntry] = useState<DailyLedgerEntry | null>(null);

  const [loading, setLoading] = useState(false);
  const [actionNotice, setActionNotice] = useState<{ text: string; success: boolean } | null>(null);

  // Filter states
  const [todayDate, setTodayDate] = useState(formatMyanmarDate());
  const [section2D, setSection2D] = useState<'12:01 PM' | '04:30 PM'>('12:01 PM');
  const [userSearchQuery, setUserSearchQuery] = useState('');
  const [selectedLedgerUserId, setSelectedLedgerUserId] = useState<string>('');

  // Form states - Create User
  const [createUsername, setCreateUsername] = useState('');
  const [createPassword, setCreatePassword] = useState('');
  const [createName, setCreateName] = useState('');
  const [createPhone, setCreatePhone] = useState('');
  const [createBalance, setCreateBalance] = useState('100000');
  const [createRole, setCreateRole] = useState<'user' | 'admin'>('user');
  const [creatingUser, setCreatingUser] = useState(false);

  // Form states - Delete User modal
  const [userToDelete, setUserToDelete] = useState<User | null>(null);
  const [deletingUser, setDeletingUser] = useState(false);
  const [clearingHistory, setClearingHistory] = useState(false);

  // Form states - Balance adjustment
  const [balanceModalUser, setBalanceModalUser] = useState<User | null>(null);
  const [adjustAmount, setAdjustAmount] = useState('');
  const [adjustAction, setAdjustAction] = useState<'add' | 'subtract'>('add');
  const [adjustRemark, setAdjustRemark] = useState('');
  const [adjustingBalance, setAdjustingBalance] = useState(false);

  // Form states - Results & Settling
  const [manual2DResult, setManual2DResult] = useState('');
  const [settling2D, setSettling2D] = useState(false);
  const [settleDate3D, setSettleDate3D] = useState(formatMyanmarDate());
  const [manual3DResult, setManual3DResult] = useState(settings.manual3DResult || '');
  const [settling3D, setSettling3D] = useState(false);

  // 00-99 Quick Grid Selector modal state
  const [isGridModalOpen, setIsGridModalOpen] = useState(false);
  const [gridSection, setGridSection] = useState<'12:01 PM' | '04:30 PM'>('12:01 PM');

  // Settings forms: Dedicated persistent inputs synced with server/db.json
  const [closeTime2D1201, setCloseTime2D1201] = useState(settings.closeTime2D_1201 || '11:50 AM');
  const [closeTime2D1630, setCloseTime2D1630] = useState(settings.closeTime2D_1630 || '03:50 PM');
  const [closeTime3D, setCloseTime3D] = useState(settings.closeTime3D || '02:30 PM');
  const [multiplier2DInput, setMultiplier2DInput] = useState(String(settings.multiplier2D || 80));
  const [commission2DInput, setCommission2DInput] = useState(String(settings.commissionRate2D ? Math.round(settings.commissionRate2D * 100) : 12));
  const [limit2DInput, setLimit2DInput] = useState(String(settings.limit2D || 100000));
  const [closed2D1201Input, setClosed2D1201Input] = useState(settings.closedNumbers2D_1201?.join(', ') || '');
  const [closed2D1630Input, setClosed2D1630Input] = useState(settings.closedNumbers2D_1630?.join(', ') || '');
  const [customLimits2D_1201, setCustomLimits2D_1201] = useState<Record<string, number>>(settings.customLimits2D_1201 || {});
  const [customLimits2D_1630, setCustomLimits2D_1630] = useState<Record<string, number>>(settings.customLimits2D_1630 || {});
  
  const [limit3DInput, setLimit3DInput] = useState(String(settings.limit3D || 50000));
  const [closed3DInput, setClosed3DInput] = useState(settings.closedNumbers3D?.join(', ') || '');
  const [customLimits3D, setCustomLimits3D] = useState<Record<string, number>>(settings.customLimits3D || {});
  const [newClosed3D, setNewClosed3D] = useState('');
  const [custom3DNumber, setCustom3DNumber] = useState('');
  const [custom3DLimitAmount, setCustom3DLimitAmount] = useState('20000');
  
  const [multiplier3DInput, setMultiplier3DInput] = useState(String(settings.multiplier3D || 500));
  const [multiplier3DTootInput, setMultiplier3DTootInput] = useState(String(settings.multiplier3D_toot || 10));
  const [multiplier3DChaiInput, setMultiplier3DChaiInput] = useState(String(settings.multiplier3D_chai || 10));
  const [commission3DInput, setCommission3DInput] = useState(String(settings.commissionRate3D ? Math.round(settings.commissionRate3D * 100) : 10));
  const [announcementInput, setAnnouncementInput] = useState(settings.announcement !== undefined ? settings.announcement : '');
  const [viberLinkInput, setViberLinkInput] = useState(settings.serviceLink1?.url || 'viber://chat?number=%2B959781187965');
  const [telegramLinkInput, setTelegramLinkInput] = useState(settings.serviceLink2?.url || 'https://t.me/zussio2');
  const [savingSettings, setSavingSettings] = useState(false);

  // Sync settings when props change (on load, reload, or second phone fetch)
  useEffect(() => {
    if (!savingSettings) {
      if (settings.closeTime2D_1201) setCloseTime2D1201(settings.closeTime2D_1201);
      if (settings.closeTime2D_1630) setCloseTime2D1630(settings.closeTime2D_1630);
      if (settings.closeTime3D) setCloseTime3D(settings.closeTime3D);
      if (settings.announcement !== undefined) setAnnouncementInput(settings.announcement);
      if (settings.serviceLink1?.url) setViberLinkInput(settings.serviceLink1.url);
      if (settings.serviceLink2?.url) setTelegramLinkInput(settings.serviceLink2.url);
      if (settings.multiplier2D) setMultiplier2DInput(String(settings.multiplier2D));
      if (settings.commissionRate2D !== undefined) setCommission2DInput(String(Math.round(settings.commissionRate2D * 100)));
      if (settings.multiplier3D) setMultiplier3DInput(String(settings.multiplier3D));
      if (settings.multiplier3D_toot) setMultiplier3DTootInput(String(settings.multiplier3D_toot));
      if (settings.multiplier3D_chai) setMultiplier3DChaiInput(String(settings.multiplier3D_chai));
      if (settings.commissionRate3D !== undefined) setCommission3DInput(String(Math.round(settings.commissionRate3D * 100)));
      if (settings.limit2D) setLimit2DInput(String(settings.limit2D));
      if (settings.limit3D) setLimit3DInput(String(settings.limit3D));
      if (settings.customLimits2D_1201) setCustomLimits2D_1201(settings.customLimits2D_1201);
      if (settings.customLimits2D_1630) setCustomLimits2D_1630(settings.customLimits2D_1630);
      if (settings.customLimits3D) setCustomLimits3D(settings.customLimits3D);
      if (settings.closedNumbers2D_1201) setClosed2D1201Input(settings.closedNumbers2D_1201.join(', '));
      if (settings.closedNumbers2D_1630) setClosed2D1630Input(settings.closedNumbers2D_1630.join(', '));
      if (settings.closedNumbers3D) setClosed3DInput(settings.closedNumbers3D.join(', '));
    }
  }, [settings]);

  // Auth Submit
  const handleAuthSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (enteredPassword.trim() === 'waizin4700') {
      setIsAuthenticated(true);
      sessionStorage.setItem('nm2d_admin_session', 'authenticated_waizin4700');
      setAuthError('');
    } else {
      setAuthError('Incorrect Admin Password. Access Denied.');
    }
  };

  const handleAdminLogout = () => {
    setIsAuthenticated(false);
    sessionStorage.removeItem('nm2d_admin_session');
    setEnteredPassword('');
  };

  // Fetch all live data (Polling updates user balances & bets without resetting inputs)
  const fetchData = async () => {
    setLoading(true);
    try {
      // Fetch users
      const resUsers = await fetch('/api/users');
      if (resUsers.ok) {
        const uData = await resUsers.json();
        setUsersList(uData);
      }

      // Fetch bets for active day
      const resBets = await fetch(`/api/bets?date=${todayDate}`);
      if (resBets.ok) {
        const bData = await resBets.json();
        setBets2D(bData.bets2D || []);
        setBets3D(bData.bets3D || []);
      }

      // Fetch unified all-user ledger or filtered by specific user
      const ledgerUrl = selectedLedgerUserId ? `/api/ledger?userId=${selectedLedgerUserId}` : '/api/ledger';
      const resLedger = await fetch(ledgerUrl);
      if (resLedger.ok) {
        const lData = await resLedger.json();
        setLedgerAll(lData.ledgerAll || []);
      }

      // Fetch settings
      const resSet = await fetch('/api/settings');
      if (resSet.ok) {
        const sData = await resSet.json();
        onUpdateSettings(sData);
      }
    } catch (e) {
      console.error('Fetch error:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isAuthenticated) {
      fetchData();
      const interval = setInterval(fetchData, 6000);
      return () => clearInterval(interval);
    }
  }, [todayDate, isAuthenticated, selectedLedgerUserId]);

  const showNotice = (text: string, success = true) => {
    setActionNotice({ text, success });
    setTimeout(() => setActionNotice(null), 4000);
  };

  // Handle User Creation
  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!createUsername.trim() || !createPassword.trim()) {
      showNotice('Username and Password are required', false);
      return;
    }

    setCreatingUser(true);
    try {
      const res = await fetch('/api/users/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: createUsername.trim(),
          password: createPassword.trim(),
          name: createName.trim() || createUsername.trim(),
          phone: createPhone.trim() || undefined,
          balance: Number(createBalance) || 0,
          role: createRole,
        }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        showNotice(`User @${createUsername} created successfully in Supabase!`);
        setCreateUsername('');
        setCreatePassword('');
        setCreateName('');
        setCreatePhone('');
        setCreateBalance('100000');
        fetchData();
      } else {
        showNotice(data.message || 'Failed to create user', false);
      }
    } catch (e) {
      showNotice('Connection error while creating user', false);
    } finally {
      setCreatingUser(false);
    }
  };

  // Handle Balance Adjust
  const handleAdjustBalance = async () => {
    if (!balanceModalUser || !adjustAmount) return;
    const num = Number(adjustAmount);
    if (isNaN(num) || num <= 0) {
      showNotice('Please enter a valid amount', false);
      return;
    }

    setAdjustingBalance(true);
    try {
      const res = await fetch(`/api/users/${balanceModalUser.id}/balance`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount: num,
          action: adjustAction,
          remark: adjustRemark || (adjustAction === 'add' ? 'Manual Deposit by Admin' : 'Manual Withdrawal by Admin'),
        }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        showNotice(`Balance updated for ${balanceModalUser.username}! New Balance: ${data.balance.toLocaleString()} MMK`);
        setBalanceModalUser(null);
        setAdjustAmount('');
        setAdjustRemark('');
        fetchData();
      } else {
        showNotice(data.message || 'Failed to update balance', false);
      }
    } catch (e) {
      showNotice('Connection error while updating balance', false);
    } finally {
      setAdjustingBalance(false);
    }
  };

  // Handle Bet Cancel
  const handleCancelBet = async (betId: string, type: '2d' | '3d') => {
    if (!confirm('Are you sure you want to cancel this bet and refund the user?')) return;

    try {
      const res = await fetch('/api/bets/cancel', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ betId, type }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        showNotice(`Bet cancelled and refunded successfully!`);
        fetchData();
      } else {
        showNotice(data.message || 'Failed to cancel bet', false);
      }
    } catch (e) {
      showNotice('Connection error', false);
    }
  };

  // Handle Save Settings
  const handleSaveSettings = async (partial: Partial<AppSettings>) => {
    setSavingSettings(true);
    try {
      const res = await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(partial),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        onUpdateSettings(data.settings);
        showNotice('Settings updated and synced with Supabase successfully!');
      } else {
        showNotice('Failed to update settings', false);
      }
    } catch (e) {
      showNotice('Connection error', false);
    } finally {
      setSavingSettings(false);
    }
  };

  // Handle 2D Manual Settle
  const handleSettle2D = async () => {
    if (!manual2DResult.trim() || manual2DResult.trim().length !== 2) {
      showNotice('Please enter a valid 2-digit number (e.g. 74)', false);
      return;
    }

    setSettling2D(true);
    try {
      const res = await fetch('/api/bets/2d/settle', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          date: todayDate,
          section: section2D,
          resultNumber: manual2DResult.trim(),
        }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        showNotice(`2D settled! Winning number: ${manual2DResult.trim()} (${data.winnersCount || 0} winners)`);
        setManual2DResult('');
        fetchData();
      } else {
        showNotice(data.message || 'Failed to settle 2D', false);
      }
    } catch (e) {
      showNotice('Error settling 2D', false);
    } finally {
      setSettling2D(false);
    }
  };

  // Handle Delete User
  const handleDeleteUser = async (u: User) => {
    setDeletingUser(true);
    try {
      const res = await fetch(`/api/users/${u.id}`, { method: 'DELETE' });
      const data = await res.json();
      if (res.ok && data.success) {
        showNotice(`အကောင့် @${u.username} ကို အောင်မြင်စွာ ဖျက်ချပြီးပါပြီ`);
        setUserToDelete(null);
        fetchData();
      } else {
        showNotice(data.message || 'User ဖျက်ရာတွင် မအောင်မြင်ပါ', false);
      }
    } catch (e) {
      showNotice('Connection error during deletion', false);
    } finally {
      setDeletingUser(false);
    }
  };

  // Handle Clear History (Purge completed bets on demand to save data/storage)
  const handleClearHistory = async (type: 'all' | 'beforeDate' | 'user') => {
    if (!confirm('ရှင်းတမ်းပြီးသော ထိုးစာရင်းများကို အပြီးတိုင် ဖျက်ပါမည်။ Pending (မထွက်သေးသော ထိုးကြေးများ) မပျက်ပါ။ အတည်ပြုပါသလား?')) return;
    setClearingHistory(true);
    try {
      const res = await fetch('/api/admin/clear-history', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          clearAllSettled: type === 'all',
          date: type === 'beforeDate' ? todayDate : undefined,
          userId: type === 'user' ? selectedLedgerUserId : undefined,
        }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        showNotice(data.message || 'စာရင်းများ ရှင်းလင်းပြီးပါပြီ');
        fetchData();
      } else {
        showNotice('Failed to clear history', false);
      }
    } catch (e) {
      showNotice('Connection error', false);
    } finally {
      setClearingHistory(false);
    }
  };

  // Handle Reset Closed Numbers
  const handleResetClosed = async (sec: '12:01 PM' | '04:30 PM' | '3d' | 'all') => {
    if (!confirm(`${sec} ပိတ်ဂဏန်းများကို ယနေ့အတွက် အသစ်ပြန်လည် စတင်ပါမည်လား?`)) return;
    try {
      const res = await fetch('/api/admin/reset-closed', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ section: sec }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        if (sec === '12:01 PM' || sec === 'all') {
          setClosed2D1201Input('');
          setCustomLimits2D_1201({});
        }
        if (sec === '04:30 PM' || sec === 'all') {
          setClosed2D1630Input('');
          setCustomLimits2D_1630({});
        }
        if (sec === '3d' || sec === 'all') {
          setClosed3DInput('');
          setCustomLimits3D({});
        }
        onUpdateSettings(data.settings);
        showNotice(data.message);
      }
    } catch (e) {
      showNotice('Error resetting closed numbers', false);
    }
  };
  const handleSettle3D = async () => {
    if (!settleDate3D.trim()) {
      showNotice('ကျေးဇူးပြု၍ 3D ထွက်ရက်စွဲ (Date) ရွေးချယ်ပါ', false);
      return;
    }
    if (!manual3DResult.trim() || manual3DResult.trim().length !== 3) {
      showNotice('ကျေးဇူးပြု၍ ၃ လုံး ဂဏန်း (e.g. 456) မှန်ကန်စွာ ထည့်ပါ', false);
      return;
    }

    setSettling3D(true);
    try {
      const res = await fetch('/api/admin/settle-3d', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          date: settleDate3D.trim(),
          resultNumber: manual3DResult.trim(),
        }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        showNotice(`3D settled for ${settleDate3D.trim()}! Winning number: ${manual3DResult.trim()} (${data.winnersCount || 0} winners)`);
        fetchData();
      } else {
        showNotice(data.message || 'Failed to settle 3D', false);
      }
    } catch (e) {
      showNotice('Error settling 3D', false);
    } finally {
      setSettling3D(false);
    }
  };

  // Metrics calculations
  const total2DVolume = bets2D.filter(b => b.status !== 'cancelled_by_admin').reduce((sum, b) => sum + b.amount, 0);
  const total3DVolume = bets3D.filter(b => b.status !== 'cancelled_by_admin').reduce((sum, b) => sum + b.amount, 0);
  const total2DPayout = bets2D.filter(b => b.status === 'win').reduce((sum, b) => sum + (b.winAmount || 0), 0);
  const total3DPayout = bets3D.filter(b => b.status === 'win').reduce((sum, b) => sum + (b.winAmount || 0), 0);

  // Filtered lists
  const filteredUsers = usersList.filter(u => 
    u.username.toLowerCase().includes(userSearchQuery.toLowerCase()) ||
    (u.name && u.name.toLowerCase().includes(userSearchQuery.toLowerCase()))
  );

  const active2DBets = bets2D.filter(b => b.section === section2D);

  // =========================================================================
  // PASSWORD GATE: If not authenticated, require password 'waizin4700'
  // =========================================================================
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen w-full bg-[#050914] flex flex-col items-center justify-center p-6 text-slate-100 font-sans select-none overflow-y-auto">
        <div className="w-full max-w-md bg-[#0a1122] border border-cyan-500/30 rounded-3xl p-8 shadow-2xl shadow-black/80 flex flex-col items-center">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-cyan-400 to-blue-600 flex items-center justify-center text-black font-black text-2xl shadow-lg shadow-cyan-500/30 mb-5">
            <Lock className="w-8 h-8 text-black" />
          </div>

          <h1 className="text-xl font-black text-white tracking-wide text-center">
            ADMIN PORTAL ACCESS
          </h1>
          <p className="text-xs text-slate-400 mt-1 mb-6 text-center">
            NM 2D/3D Master Control Center • Authorized Access Only
          </p>

          <form onSubmit={handleAuthSubmit} className="w-full space-y-4">
            <div>
              <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2">
                Admin Password (စကားဝှက် ရိုက်ထည့်ပါ)
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  autoFocus
                  required
                  value={enteredPassword}
                  onChange={(e) => {
                    setEnteredPassword(e.target.value);
                    setAuthError('');
                  }}
                  placeholder="Enter admin password"
                  className="w-full px-4 py-3 bg-[#060b17] border border-slate-700 rounded-xl text-white font-mono text-sm focus:border-cyan-400 focus:outline-none"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-3 text-slate-400 hover:text-white"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {authError && (
              <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs font-bold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{authError}</span>
              </div>
            )}

            <button
              type="submit"
              className="w-full py-3 px-4 bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black font-extrabold rounded-xl text-sm shadow-lg shadow-cyan-500/25 active:scale-95 transition-all cursor-pointer"
            >
              Unlock Master Panel
            </button>
          </form>

          <div className="mt-6 text-[10px] text-slate-500 uppercase tracking-widest font-mono">
            SECURE SHA-256 RESTRICTED
          </div>
        </div>
      </div>
    );
  }

  // =========================================================================
  // MAIN ADMIN CONTROL CENTER INTERFACE (Full Smooth Scrolling Support)
  // =========================================================================
  return (
    <div className="min-h-screen h-screen w-full bg-[#060b17] text-slate-100 flex flex-col font-sans select-none antialiased overflow-hidden">
      {/* Top Notification Toast */}
      {actionNotice && (
        <div className={`fixed top-4 right-4 z-50 px-4 py-3 rounded-xl border shadow-2xl flex items-center gap-2 text-sm font-bold transition-all ${
          actionNotice.success 
            ? 'bg-emerald-950/90 border-emerald-500/60 text-emerald-300' 
            : 'bg-rose-950/90 border-rose-500/60 text-rose-300'
        }`}>
          {actionNotice.success ? <CheckCircle2 className="w-5 h-5 text-emerald-400" /> : <AlertCircle className="w-5 h-5 text-rose-400" />}
          <span>{actionNotice.text}</span>
        </div>
      )}

      {/* ADMIN TOP MASTER BAR */}
      <header className="shrink-0 bg-[#0a1224]/95 backdrop-blur-md border-b border-slate-800 px-6 py-3.5 flex flex-wrap items-center justify-between gap-4 z-40">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-400 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-500/20 text-black font-black text-lg">
            NM
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base font-extrabold text-white tracking-wide">NM 2D/3D MASTER CONTROL CENTER</h1>
              <span className="px-2 py-0.5 rounded text-[10px] font-black bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 uppercase">
                WEB ADMIN
              </span>
            </div>
            <p className="text-[11px] text-slate-400">Direct Supabase Cloud Connected • High-Level Control</p>
          </div>
        </div>

        {/* Master Status Quick Indicators */}
        <div className="flex items-center gap-2 text-xs font-mono-numbers">
          {/* Server status */}
          <div className={`px-2.5 py-1 rounded-lg border flex items-center gap-1.5 font-bold ${
            settings.serverOnline !== false 
              ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-400' 
              : 'bg-rose-500/10 border-rose-500/40 text-rose-400'
          }`}>
            <span className={`w-2 h-2 rounded-full ${settings.serverOnline !== false ? 'bg-emerald-400 animate-pulse' : 'bg-rose-500'}`} />
            <span>SERVER: {settings.serverOnline !== false ? 'ONLINE' : 'MAINTENANCE'}</span>
          </div>

          {/* 2D Status */}
          <div className={`px-2.5 py-1 rounded-lg border flex items-center gap-1.5 font-bold ${
            settings.betting2D_enabled !== false 
              ? 'bg-cyan-500/10 border-cyan-500/40 text-cyan-400' 
              : 'bg-rose-500/10 border-rose-500/40 text-rose-400'
          }`}>
            <span>2D: {settings.betting2D_enabled !== false ? 'OPEN' : 'CLOSED'}</span>
          </div>

          {/* 3D Status */}
          <div className={`px-2.5 py-1 rounded-lg border flex items-center gap-1.5 font-bold ${
            settings.betting3D_enabled !== false 
              ? 'bg-amber-500/10 border-amber-500/40 text-amber-400' 
              : 'bg-rose-500/10 border-rose-500/40 text-rose-400'
          }`}>
            <span>3D: {settings.betting3D_enabled !== false ? 'OPEN' : 'CLOSED'}</span>
          </div>
        </div>

        {/* Right Action buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={fetchData}
            disabled={loading}
            title="Refresh All Data"
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-colors cursor-pointer"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-cyan-400' : ''}`} />
          </button>

          <button
            onClick={handleAdminLogout}
            title="Lock Panel"
            className="px-3 py-1.5 rounded-xl bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-500/40 text-xs font-bold transition-all cursor-pointer flex items-center gap-1"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Lock</span>
          </button>
        </div>
      </header>

      {/* DASHBOARD METRICS STRIP */}
      <section className="shrink-0 bg-[#0b1328] border-b border-slate-800/80 px-6 py-3.5">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="p-3 rounded-xl bg-[#0e172e] border border-slate-800 flex items-center justify-between">
            <div>
              <div className="text-[11px] uppercase tracking-wider font-bold text-slate-400">Total Users</div>
              <div className="text-xl font-black font-mono-numbers text-white mt-0.5">{usersList.length} Accounts</div>
            </div>
            <div className="p-2.5 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
              <Users className="w-5 h-5" />
            </div>
          </div>

          <div className="p-3 rounded-xl bg-[#0e172e] border border-slate-800 flex items-center justify-between">
            <div>
              <div className="text-[11px] uppercase tracking-wider font-bold text-slate-400">Today 2D Bets</div>
              <div className="text-xl font-black font-mono-numbers text-cyan-400 mt-0.5">{total2DVolume.toLocaleString()} MMK</div>
              <div className="text-[10px] text-slate-400 font-mono-numbers">Payout: {total2DPayout.toLocaleString()} MMK</div>
            </div>
            <div className="p-2.5 rounded-xl bg-blue-500/10 text-blue-400 border border-blue-500/20">
              <TrendingUp className="w-5 h-5" />
            </div>
          </div>

          <div className="p-3 rounded-xl bg-[#0e172e] border border-slate-800 flex items-center justify-between">
            <div>
              <div className="text-[11px] uppercase tracking-wider font-bold text-slate-400">Today 3D Bets</div>
              <div className="text-xl font-black font-mono-numbers text-amber-400 mt-0.5">{total3DVolume.toLocaleString()} MMK</div>
              <div className="text-[10px] text-slate-400 font-mono-numbers">Payout: {total3DPayout.toLocaleString()} MMK</div>
            </div>
            <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
              <Award className="w-5 h-5" />
            </div>
          </div>

          <div className="p-3 rounded-xl bg-[#0e172e] border border-slate-800 flex items-center justify-between">
            <div>
              <div className="text-[11px] uppercase tracking-wider font-bold text-slate-400">Total Net Income</div>
              <div className="text-xl font-black font-mono-numbers text-emerald-400 mt-0.5">
                {((total2DVolume + total3DVolume) - (total2DPayout + total3DPayout)).toLocaleString()} MMK
              </div>
              <div className="text-[10px] text-emerald-400/80">Active Daily Book</div>
            </div>
            <div className="p-2.5 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <DollarSign className="w-5 h-5" />
            </div>
          </div>
        </div>
      </section>

      {/* MAIN NAVIGATION TABS (Strict separation: Bets vs Unified Ledger) */}
      <div className="shrink-0 bg-[#091022] border-b border-slate-800 px-6 flex items-center gap-1 overflow-x-auto custom-scrollbar">
        {[
          { id: 'users', label: '👥 Users & Wallets' },
          { id: '2d_bets', label: '📊 2D Live Bets' },
          { id: '3d_bets', label: '🎲 3D Live Bets' },
          { id: 'ledger', label: '📑 စာရင်းချုပ် & ရှင်းလင်းမှု (Ledger & Clean)' },
          { id: 'closed_numbers', label: '🚫 ပိတ်ဂဏန်းများ (Closed Numbers)' },
          { id: 'limits', label: '💰 Limit သတ်မှတ်ချက်များ (Bet Limits)' },
          { id: 'controls', label: '⚙️ ဆ/ကော်မရှင် & ပိတ်ချိန်များ (Controls)' },
          { id: 'announcements', label: '📢 Notice & Customer Care' },
        ].map((t) => (
          <button
            key={t.id}
            onClick={() => setActiveTab(t.id as any)}
            className={`px-4 py-3 text-xs font-bold transition-all border-b-2 whitespace-nowrap cursor-pointer ${
              activeTab === t.id
                ? 'text-cyan-400 border-cyan-400 bg-cyan-500/5'
                : 'text-slate-400 border-transparent hover:text-slate-200 hover:bg-slate-800/40'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* SCROLLABLE MAIN CONTENT AREA (Full overflow-y-auto scrolling with custom scrollbar) */}
      <main className="flex-1 p-6 overflow-y-auto custom-scrollbar">
        {/* TAB 1: USERS & WALLETS */}
        {activeTab === 'users' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Create New User Card */}
            <div className="bg-[#0e172e] border border-slate-800 rounded-2xl p-5 h-fit shadow-xl">
              <div className="flex items-center gap-2 mb-4 pb-3 border-b border-slate-800">
                <UserPlus className="w-5 h-5 text-cyan-400" />
                <h2 className="text-sm font-bold text-white uppercase tracking-wider">Create New User (အကောင့်သစ်ဖွင့်ရန်)</h2>
              </div>

              <form onSubmit={handleCreateUser} className="space-y-3.5">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Username (ဝင်ရောက်ရန် အမည်) *</label>
                  <input
                    type="text"
                    required
                    value={createUsername}
                    onChange={(e) => setCreateUsername(e.target.value)}
                    placeholder="e.g. user001"
                    className="w-full px-3 py-2 bg-[#060b17] border border-slate-700 rounded-xl text-white text-xs font-mono focus:border-cyan-400 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Password (စကားဝှက်) *</label>
                  <input
                    type="text"
                    required
                    value={createPassword}
                    onChange={(e) => setCreatePassword(e.target.value)}
                    placeholder="e.g. 123456"
                    className="w-full px-3 py-2 bg-[#060b17] border border-slate-700 rounded-xl text-white text-xs font-mono focus:border-cyan-400 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Full Name / Nickname</label>
                  <input
                    type="text"
                    value={createName}
                    onChange={(e) => setCreateName(e.target.value)}
                    placeholder="e.g. Ko Phyo"
                    className="w-full px-3 py-2 bg-[#060b17] border border-slate-700 rounded-xl text-white text-xs focus:border-cyan-400 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Phone Number</label>
                  <input
                    type="tel"
                    value={createPhone}
                    onChange={(e) => setCreatePhone(e.target.value)}
                    placeholder="09xxxxxxxxx"
                    className="w-full px-3 py-2 bg-[#060b17] border border-slate-700 rounded-xl text-white text-xs font-mono focus:border-cyan-400 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Initial Balance (အစောပိုင်း ထည့်ပေးမည့်ငွေ)</label>
                  <input
                    type="number"
                    value={createBalance}
                    onChange={(e) => setCreateBalance(e.target.value)}
                    placeholder="100000"
                    className="w-full px-3 py-2 bg-[#060b17] border border-slate-700 rounded-xl text-white text-xs font-mono-numbers focus:border-cyan-400 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Account Role</label>
                  <select
                    value={createRole}
                    onChange={(e) => setCreateRole(e.target.value as any)}
                    className="w-full px-3 py-2 bg-[#060b17] border border-slate-700 rounded-xl text-white text-xs focus:border-cyan-400 outline-none"
                  >
                    <option value="user">Regular User (ကစားသမား)</option>
                    <option value="admin">Admin / Sub-admin (ဒိုင်)</option>
                  </select>
                </div>

                <button
                  type="submit"
                  disabled={creatingUser}
                  className="w-full py-2.5 px-4 bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black font-extrabold rounded-xl text-xs shadow-lg shadow-cyan-500/20 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  <UserPlus className="w-4 h-4" />
                  <span>{creatingUser ? 'Creating in Supabase...' : 'Create Account Now'}</span>
                </button>
              </form>
            </div>

            {/* Users List & Balance Management */}
            <div className="lg:col-span-2 bg-[#0e172e] border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col">
              <div className="flex flex-wrap items-center justify-between gap-3 mb-4 pb-3 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <Users className="w-5 h-5 text-blue-400" />
                  <h2 className="text-sm font-bold text-white uppercase tracking-wider">
                    All User Accounts ({filteredUsers.length})
                  </h2>
                </div>

                {/* Search */}
                <div className="relative">
                  <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                  <input
                    type="text"
                    value={userSearchQuery}
                    onChange={(e) => setUserSearchQuery(e.target.value)}
                    placeholder="Search by username..."
                    className="pl-9 pr-3 py-1.5 bg-[#060b17] border border-slate-700 rounded-xl text-xs text-white focus:border-cyan-400 outline-none w-56"
                  />
                </div>
              </div>

              {/* Table */}
              <div className="overflow-x-auto custom-scrollbar flex-1 max-h-[500px]">
                <table className="w-full text-left text-xs font-mono-numbers">
                  <thead>
                    <tr className="border-b border-slate-800 text-slate-400 text-[11px] uppercase">
                      <th className="py-2.5 px-3">Username</th>
                      <th className="py-2.5 px-3">Name</th>
                      <th className="py-2.5 px-3">Role</th>
                      <th className="py-2.5 px-3 text-right">Balance</th>
                      <th className="py-2.5 px-3 text-center">Action (ငွေသွင်း/ထုတ်)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {filteredUsers.map((u) => (
                      <tr key={u.id} className="hover:bg-slate-800/40 transition-colors">
                        <td className="py-3 px-3 font-bold text-white flex items-center gap-1.5">
                          <span>@{u.username}</span>
                          {u.role === 'admin' && (
                            <span className="px-1.5 py-0.2 rounded text-[9px] bg-amber-500/20 text-amber-300 border border-amber-500/30 uppercase">
                              Admin
                            </span>
                          )}
                        </td>
                        <td className="py-3 px-3 text-slate-300 font-sans">{u.name || '-'}</td>
                        <td className="py-3 px-3 text-slate-400 uppercase text-[10px]">{u.role}</td>
                        <td className="py-3 px-3 text-right font-black text-cyan-300">
                          {u.balance.toLocaleString()} MMK
                        </td>
                        <td className="py-3 px-3 text-center flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => {
                              setSelectedLedgerUserId(u.id);
                              setActiveTab('ledger');
                            }}
                            title="ဒီ User ၏ စာရင်းချုပ်ကြည့်ရန်"
                            className="px-2 py-1 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-[11px] font-bold cursor-pointer transition-all inline-flex items-center gap-1"
                          >
                            <FileSpreadsheet className="w-3.5 h-3.5" />
                            <span>စာရင်းချုပ်</span>
                          </button>
                          <button
                            onClick={() => {
                              setBalanceModalUser(u);
                              setAdjustAmount('');
                              setAdjustRemark('');
                            }}
                            className="px-2.5 py-1 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 text-[11px] font-bold cursor-pointer transition-all inline-flex items-center gap-1"
                          >
                            <DollarSign className="w-3.5 h-3.5" />
                            <span>ငွေသွင်း/ထုတ်</span>
                          </button>
                          <button
                            onClick={() => setUserToDelete(u)}
                            title="အကောင့်ဖျက်ရန်"
                            className="px-2 py-1 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 text-[11px] font-bold cursor-pointer transition-all inline-flex items-center gap-1"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>ဖျက်ရန်</span>
                          </button>
                        </td>
                      </tr>
                    ))}
                    {filteredUsers.length === 0 && (
                      <tr>
                        <td colSpan={5} className="py-8 text-center text-slate-500">
                          No users found.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: 2D LIVE BETS ONLY (Separated from Ledger) */}
        {activeTab === '2d_bets' && (
          <div className="space-y-6">
            {/* Header filters & Manual Settle Bar */}
            <div className="bg-[#0e172e] border border-slate-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <span className="text-xs font-bold text-slate-400 uppercase">Section:</span>
                <div className="flex items-center bg-[#060b17] p-1 rounded-xl border border-slate-700">
                  <button
                    onClick={() => setSection2D('12:01 PM')}
                    className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      section2D === '12:01 PM' ? 'bg-cyan-400 text-black' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    12:01 PM
                  </button>
                  <button
                    onClick={() => setSection2D('04:30 PM')}
                    className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      section2D === '04:30 PM' ? 'bg-cyan-400 text-black' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    04:30 PM
                  </button>
                </div>
              </div>

              {/* Manual 2D Draw Result Settle Box */}
              <div className="flex items-center gap-2 bg-[#060b17] border border-cyan-500/30 p-2 rounded-xl">
                <span className="text-xs font-bold text-cyan-300">Enter Winning 2D:</span>
                <input
                  type="text"
                  maxLength={2}
                  value={manual2DResult}
                  onChange={(e) => setManual2DResult(e.target.value.replace(/[^0-9]/g, ''))}
                  placeholder="e.g. 74"
                  className="w-16 px-2 py-1 bg-slate-900 border border-slate-700 rounded-lg text-center font-mono-numbers font-black text-white text-sm focus:border-cyan-400 outline-none"
                />
                <button
                  onClick={handleSettle2D}
                  disabled={settling2D || manual2DResult.length !== 2}
                  className="px-3 py-1 bg-cyan-400 hover:bg-cyan-300 text-black font-extrabold text-xs rounded-lg transition-all cursor-pointer disabled:opacity-40"
                >
                  {settling2D ? 'Settling...' : 'Settle Payout (80x)'}
                </button>
              </div>
            </div>

            {/* 2D Bets Table */}
            <div className="bg-[#0e172e] border border-slate-800 rounded-2xl p-5 shadow-xl">
              <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-800 text-xs font-bold text-slate-300">
                <span>{todayDate} • {section2D} Section ({active2DBets.length} Total Bets)</span>
                <span className="text-cyan-400 font-mono-numbers">
                  Total Bet: {active2DBets.reduce((s, b) => s + b.amount, 0).toLocaleString()} MMK
                </span>
              </div>

              <div className="overflow-x-auto custom-scrollbar max-h-[500px]">
                <table className="w-full text-left text-xs font-mono-numbers">
                  <thead>
                    <tr className="border-b border-slate-800 text-slate-400 text-[11px] uppercase">
                      <th className="py-2.5 px-3">Bet ID</th>
                      <th className="py-2.5 px-3">User</th>
                      <th className="py-2.5 px-3 text-center">Number</th>
                      <th className="py-2.5 px-3 text-right">Amount</th>
                      <th className="py-2.5 px-3 text-center">Multiplier</th>
                      <th className="py-2.5 px-3 text-center">Status</th>
                      <th className="py-2.5 px-3 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {active2DBets.map((b) => (
                      <tr key={b.id} className="hover:bg-slate-800/40 transition-colors">
                        <td className="py-3 px-3 text-slate-400">{b.id.slice(0, 10)}...</td>
                        <td className="py-3 px-3 font-bold text-white">@{b.username}</td>
                        <td className="py-3 px-3 text-center font-black text-cyan-300 text-sm">
                          <span className="px-2 py-0.5 rounded bg-cyan-500/20 border border-cyan-500/40">
                            {b.number}
                          </span>
                        </td>
                        <td className="py-3 px-3 text-right font-bold text-white">
                          {b.amount.toLocaleString()} MMK
                        </td>
                        <td className="py-3 px-3 text-center text-slate-300">{b.multiplier}x</td>
                        <td className="py-3 px-3 text-center">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase ${
                            b.status === 'win'
                              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                              : b.status === 'lose'
                              ? 'bg-slate-800 text-slate-400'
                              : b.status === 'cancelled_by_admin'
                              ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40'
                              : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                          }`}>
                            {b.status}
                          </span>
                        </td>
                        <td className="py-3 px-3 text-right">
                          {b.status !== 'cancelled_by_admin' && (
                            <button
                              onClick={() => handleCancelBet(b.id, '2d')}
                              className="px-2 py-1 rounded bg-rose-500/20 hover:bg-rose-500/30 text-rose-400 border border-rose-500/40 text-[10px] font-bold cursor-pointer transition-all inline-flex items-center gap-1"
                            >
                              <Trash2 className="w-3 h-3" />
                              <span>Cancel & Refund</span>
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                    {active2DBets.length === 0 && (
                      <tr>
                        <td colSpan={7} className="py-8 text-center text-slate-500">
                          No 2D bets recorded for this section yet.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: 3D LIVE BETS ONLY */}
        {activeTab === '3d_bets' && (
          <div className="space-y-6">
            {/* Header filters & Manual Settle Bar */}
            <div className="bg-[#0e172e] border border-amber-500/30 rounded-2xl p-5 shadow-xl space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <Award className="w-5 h-5 text-amber-400" />
                  <h3 className="text-sm font-black text-white uppercase tracking-wider">
                    3D Result & Settle Center (3D ထွက်ဂဏန်းနှင့် ရက်စွဲထည့်သွင်းရန်)
                  </h3>
                </div>
                <div className="flex items-center gap-2 text-xs">
                  <span className="px-2.5 py-1 rounded-lg bg-amber-500/20 text-amber-300 font-mono-numbers font-bold border border-amber-500/30">
                    ဒဲ့: {settings.multiplier3D || 500}ဆ
                  </span>
                  <span className="px-2.5 py-1 rounded-lg bg-blue-500/20 text-blue-300 font-mono-numbers font-bold border border-blue-500/30">
                    ပတ်လည်: {settings.multiplier3D_toot || 10}ဆ
                  </span>
                  <span className="px-2.5 py-1 rounded-lg bg-purple-500/20 text-purple-300 font-mono-numbers font-bold border border-purple-500/30">
                    အနီးစပ်/ချာ: {settings.multiplier3D_chai || 10}ဆ
                  </span>
                </div>
              </div>

              {/* Date & 3D Result Input Form */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
                {/* 1. Date Selector */}
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1.5 flex items-center justify-between">
                    <span className="flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Draw Date (ထွက်သည့်ရက်စွဲ) *</span>
                    </span>
                    <button
                      type="button"
                      onClick={() => setSettleDate3D(todayDate)}
                      className="text-[10px] text-cyan-400 hover:underline cursor-pointer"
                    >
                      ယနေ့ရက်စွဲ
                    </button>
                  </label>
                  <input
                    type="text"
                    required
                    value={settleDate3D}
                    onChange={(e) => setSettleDate3D(e.target.value)}
                    placeholder="DD-MM-YYYY (e.g. 16-09-2026)"
                    className="w-full px-3 py-2.5 bg-[#060b17] border border-slate-700 rounded-xl font-mono text-white text-xs focus:border-amber-400 outline-none font-bold"
                  />
                </div>

                {/* 2. 3-digit Result Number */}
                <div>
                  <label className="block text-xs font-bold text-amber-300 mb-1.5 flex items-center gap-1.5">
                    <Target className="w-3.5 h-3.5 text-amber-400" />
                    <span>Official 3D Result (ထွက်ဂဏန်း ၃ လုံး) *</span>
                  </label>
                  <input
                    type="text"
                    maxLength={3}
                    required
                    value={manual3DResult}
                    onChange={(e) => setManual3DResult(e.target.value.replace(/[^0-9]/g, ''))}
                    placeholder="e.g. 456"
                    className="w-full px-3 py-2 bg-slate-900 border border-amber-500/50 rounded-xl text-center font-mono-numbers font-black text-amber-300 text-lg focus:border-amber-400 outline-none tracking-widest"
                  />
                </div>

                {/* 3. Settle Action Button */}
                <div>
                  <button
                    type="button"
                    onClick={handleSettle3D}
                    disabled={settling3D || manual3DResult.length !== 3 || !settleDate3D}
                    className="w-full py-2.5 px-4 bg-gradient-to-r from-amber-400 via-amber-300 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-black font-black text-xs rounded-xl shadow-lg shadow-amber-500/25 active:scale-95 transition-all cursor-pointer disabled:opacity-40 flex items-center justify-center gap-2"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>
                      {settling3D ? 'Settling Bets...' : `Settle 3D for ${settleDate3D}`}
                    </span>
                  </button>
                </div>
              </div>

              {/* Dynamic Winning Breakdown Preview (Shows Toot and Adjacent numbers for entered result) */}
              {manual3DResult.length === 3 && (() => {
                const breakdown = get3DWinningNumbersBreakdown(manual3DResult);
                return (
                  <div className="p-3 rounded-xl bg-[#060b17] border border-amber-500/20 text-xs space-y-1.5">
                    <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wide">
                      Winning Prize Structure Preview for '{manual3DResult}':
                    </div>
                    <div className="flex flex-wrap items-center gap-3">
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-amber-300">👑 ဒဲ့ (500ဆ):</span>
                        <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-200 font-mono-numbers font-black">
                          {breakdown.direct}
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-blue-300">🔄 ပတ်လည် (10ဆ):</span>
                        <span className="px-2 py-0.5 rounded bg-blue-500/20 text-blue-200 font-mono-numbers font-black">
                          {breakdown.toot.length > 0 ? breakdown.toot.join(', ') : 'မရှိ'}
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-purple-300">🎯 အနီးစပ်/ချာ (10ဆ):</span>
                        <span className="px-2 py-0.5 rounded bg-purple-500/20 text-purple-200 font-mono-numbers font-black">
                          {breakdown.adjacent.join(', ')}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })()}

              {/* Official Settled Results History Chips */}
              {settings.official3DResults && Object.keys(settings.official3DResults).length > 0 && (
                <div className="pt-2 border-t border-slate-800 flex flex-wrap items-center gap-2">
                  <span className="text-[11px] font-bold text-slate-400">ယခင် ထွက်ဂဏန်းများ:</span>
                  {Object.entries(settings.official3DResults).map(([d, res]) => (
                    <button
                      key={d}
                      type="button"
                      onClick={() => {
                        setSettleDate3D(d);
                        setManual3DResult(res);
                      }}
                      className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-mono-numbers font-bold text-slate-200 flex items-center gap-1.5 cursor-pointer border border-slate-700"
                    >
                      <span className="text-slate-400">{d}:</span>
                      <span className="text-amber-400 font-black">{res}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* 3D Bets Table */}
            <div className="bg-[#0e172e] border border-slate-800 rounded-2xl p-5 shadow-xl">
              <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-800 text-xs font-bold text-slate-300">
                <span>3D Current Book ({bets3D.length} Total Bets)</span>
                <span className="text-amber-400 font-mono-numbers">
                  Total Bet: {bets3D.reduce((s, b) => s + b.amount, 0).toLocaleString()} MMK
                </span>
              </div>

              <div className="overflow-x-auto custom-scrollbar max-h-[500px]">
                <table className="w-full text-left text-xs font-mono-numbers">
                  <thead>
                    <tr className="border-b border-slate-800 text-slate-400 text-[11px] uppercase">
                      <th className="py-2.5 px-3">Bet ID</th>
                      <th className="py-2.5 px-3">User</th>
                      <th className="py-2.5 px-3 text-center">Number</th>
                      <th className="py-2.5 px-3 text-right">Amount</th>
                      <th className="py-2.5 px-3 text-center">Multiplier</th>
                      <th className="py-2.5 px-3 text-center">Status</th>
                      <th className="py-2.5 px-3 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {bets3D.map((b) => (
                      <tr key={b.id} className="hover:bg-slate-800/40 transition-colors">
                        <td className="py-3 px-3 text-slate-400">{b.id.slice(0, 10)}...</td>
                        <td className="py-3 px-3 font-bold text-white">@{b.username}</td>
                        <td className="py-3 px-3 text-center font-black text-amber-300 text-sm">
                          <span className="px-2 py-0.5 rounded bg-amber-500/20 border border-amber-500/40">
                            {b.number}
                          </span>
                        </td>
                        <td className="py-3 px-3 text-right font-bold text-white">
                          {b.amount.toLocaleString()} MMK
                        </td>
                        <td className="py-3 px-3 text-center text-slate-300">{b.multiplier}x</td>
                        <td className="py-3 px-3 text-center">
                          {b.status === 'win' ? (
                            <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 inline-flex items-center gap-1">
                              {b.winType === 'direct' ? (
                                <span>👑 ဒဲ့ ({b.multiplier}x)</span>
                              ) : b.winType === 'toot' ? (
                                <span>🔄 ပတ်လည် ({b.multiplier}x)</span>
                              ) : b.winType === 'adjacent' ? (
                                <span>🎯 အနီးစပ် ({b.multiplier}x)</span>
                              ) : (
                                <span>WIN {b.multiplier}x</span>
                              )}
                              <span>+{b.winAmount.toLocaleString()}</span>
                            </span>
                          ) : (
                            <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase ${
                              b.status === 'lose'
                                ? 'bg-slate-800 text-slate-400'
                                : b.status === 'cancelled_by_admin'
                                ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40'
                                : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                            }`}>
                              {b.status}
                            </span>
                          )}
                        </td>
                        <td className="py-3 px-3 text-right">
                          {b.status !== 'cancelled_by_admin' && (
                            <button
                              onClick={() => handleCancelBet(b.id, '3d')}
                              className="px-2 py-1 rounded bg-rose-500/20 hover:bg-rose-500/30 text-rose-400 border border-rose-500/40 text-[10px] font-bold cursor-pointer transition-all inline-flex items-center gap-1"
                            >
                              <Trash2 className="w-3 h-3" />
                              <span>Cancel & Refund</span>
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                    {bets3D.length === 0 && (
                      <tr>
                        <td colSpan={7} className="py-8 text-center text-slate-500">
                          No 3D bets recorded yet.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: UNIFIED ALL-USERS LEDGER (Date-------- နဲ့ပါ 2D/3D ရော အားလုံးရဲ့ စာရင်းချုပ် - User တစ်ယောက်ချင်းစီအလိုက် ရွေးချယ်နိုင်သည်) */}
        {activeTab === 'ledger' && (
          <div className="space-y-6">
            <div className="bg-[#0e172e] border border-slate-800 rounded-2xl p-5 shadow-xl">
              <div className="flex flex-wrap items-center justify-between gap-4 mb-4 pb-3 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <FileSpreadsheet className="w-5 h-5 text-emerald-400" />
                  <div>
                    <h2 className="text-sm font-bold text-white uppercase tracking-wider">
                      2D & 3D Settlement Ledger (စာရင်းချုပ်)
                    </h2>
                    <p className="text-[11px] text-slate-400">
                      {selectedLedgerUserId ? `Showing ledger for: @${usersList.find(u => u.id === selectedLedgerUserId)?.username || selectedLedgerUserId}` : 'Showing combined ledger for ALL users'}
                    </p>
                  </div>
                </div>

                {/* User Dropdown Selector for Single User Ledger */}
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-slate-400">User စာရင်း ရွေးရန်:</span>
                  <select
                    value={selectedLedgerUserId}
                    onChange={(e) => setSelectedLedgerUserId(e.target.value)}
                    className="px-3 py-1.5 bg-[#060b17] border border-cyan-500/40 rounded-xl text-xs font-bold text-cyan-300 focus:border-cyan-400 outline-none cursor-pointer"
                  >
                    <option value="">👥 User အားလုံး စာရင်းချုပ် (All Users Combined)</option>
                    {usersList.map((u) => (
                      <option key={u.id} value={u.id}>
                        👤 @{u.username} {u.name ? `(${u.name})` : ''} — {u.balance.toLocaleString()} MMK
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Unified Ledger Table */}
              <div className="overflow-x-auto custom-scrollbar max-h-[500px]">
                <table className="w-full text-left text-xs font-mono-numbers">
                  <thead>
                    <tr className="border-b border-slate-800 text-slate-400 text-[11px] uppercase">
                      <th className="py-3 px-3">Date (ရက်စွဲ)</th>
                      <th className="py-3 px-3 text-center">Total Bets (2D + 3D)</th>
                      <th className="py-3 px-3 text-right">Total Bet (ထိုးကြေး)</th>
                      <th className="py-3 px-3 text-right">Commission (ကော်မရှင်)</th>
                      <th className="py-3 px-3 text-right">Win/Lose</th>
                      <th className="py-3 px-3 text-right">Net Settlement (အသားတင်)</th>
                      <th className="py-3 px-3 text-center">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {ledgerAll.map((row: any) => (
                      <tr key={row.date} className="hover:bg-slate-800/40 transition-colors">
                        <td className="py-3.5 px-3 font-bold text-white flex items-center gap-2">
                          <Calendar className="w-4 h-4 text-cyan-400" />
                          <span>{row.date}</span>
                        </td>
                        <td className="py-3.5 px-3 text-center text-slate-300">
                          <span className="px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-[11px]">
                            {row.bets?.length || 0} bets ({row.bets2DCount || 0} 2D, {row.bets3DCount || 0} 3D)
                          </span>
                        </td>
                        <td className="py-3.5 px-3 text-right font-bold text-white">
                          {row.totalBet.toLocaleString()} MMK
                        </td>
                        <td className="py-3.5 px-3 text-right text-emerald-400">
                          +{row.commission.toLocaleString()} MMK
                        </td>
                        <td className="py-3.5 px-3 text-right font-bold">
                          <span className={row.winLose >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                            {row.winLose >= 0 ? `+${row.winLose.toLocaleString()}` : row.winLose.toLocaleString()} MMK
                          </span>
                        </td>
                        <td className="py-3.5 px-3 text-right font-black text-sm">
                          <span className={row.netTotal >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                            {row.netTotal >= 0 ? `+${row.netTotal.toLocaleString()}` : row.netTotal.toLocaleString()} MMK
                          </span>
                        </td>
                        <td className="py-3.5 px-3 text-center">
                          <button
                            onClick={() => setSelectedLedgerEntry(row)}
                            className="px-2.5 py-1 rounded-lg bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 border border-blue-500/40 text-[11px] font-bold cursor-pointer transition-all"
                          >
                            အသေးစိတ်ကြည့်ရန်
                          </button>
                        </td>
                      </tr>
                    ))}
                    {ledgerAll.length === 0 && (
                      <tr>
                        <td colSpan={7} className="py-10 text-center text-slate-500">
                          No settlement records found yet.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Drilldown Detailed Modal for Selected Day */}
            {selectedLedgerEntry && (
              <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
                <div className="bg-[#0e172e] border border-slate-700 rounded-3xl p-5 max-w-2xl w-full max-h-[85vh] flex flex-col shadow-2xl">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                    <div>
                      <h3 className="text-base font-extrabold text-white flex items-center gap-2">
                        <Calendar className="w-5 h-5 text-cyan-400" />
                        <span>Date: {selectedLedgerEntry.date} — Detail Bet Breakdown</span>
                      </h3>
                      <div className="text-xs text-slate-400">
                        {selectedLedgerEntry.bets.length} Total Recorded Bets
                      </div>
                    </div>
                    <button
                      onClick={() => setSelectedLedgerEntry(null)}
                      className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white cursor-pointer"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="flex-1 overflow-y-auto custom-scrollbar my-4 space-y-2 font-mono-numbers">
                    {selectedLedgerEntry.bets.map((b: any) => (
                      <div
                        key={b.id}
                        className="p-2.5 rounded-xl bg-[#060b17] border border-slate-800 text-xs flex items-center justify-between"
                      >
                        <div className="flex items-center gap-3">
                          <span className={`w-8 h-8 rounded-lg font-black text-sm flex items-center justify-center ${
                            'section' in b ? 'bg-cyan-500/20 text-cyan-300' : 'bg-amber-500/20 text-amber-300'
                          }`}>
                            {b.number}
                          </span>
                          <div>
                            <div className="text-white font-bold">
                              @{b.username} • {'section' in b ? `2D (${b.section})` : '3D Official'}
                            </div>
                            <div className="text-[10px] text-slate-400">
                              Time: {b.time} • Mult: {b.multiplier}x
                            </div>
                          </div>
                        </div>

                        <div className="text-right">
                          <div className="font-bold text-white">{b.amount.toLocaleString()} MMK</div>
                          <div className="text-[10px] font-bold">
                            {b.status === 'win' && <span className="text-emerald-400">+{b.winAmount.toLocaleString()} WIN</span>}
                            {b.status === 'lose' && <span className="text-rose-400">LOSE</span>}
                            {b.status === 'pending' && <span className="text-amber-400">PENDING</span>}
                            {b.status === 'cancelled_by_admin' && <span className="text-slate-400">CANCELLED</span>}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs font-mono-numbers">
                    <span className="text-slate-400">Total Day Settlement:</span>
                    <span className={`text-base font-extrabold ${selectedLedgerEntry.netTotal >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {selectedLedgerEntry.netTotal >= 0 ? `+${selectedLedgerEntry.netTotal.toLocaleString()}` : selectedLedgerEntry.netTotal.toLocaleString()} MMK
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 5: MASTER SWITCHES & TIMES */}
        {activeTab === 'controls' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Master Switches */}
            <div className="bg-[#0e172e] border border-slate-800 rounded-2xl p-5 space-y-5">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2 pb-3 border-b border-slate-800">
                <Power className="w-4 h-4 text-cyan-400" />
                <span>Master Betting Switches (စိတ်ကြိုက် ON / OFF)</span>
              </h3>

              {/* Server Online Switch */}
              <div className="p-4 rounded-xl bg-[#060b17] border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="text-sm font-bold text-white">System Server Switch</div>
                  <div className="text-xs text-slate-400">Turn OFF to display maintenance screen to all users</div>
                </div>
                <button
                  type="button"
                  onClick={() => handleSaveSettings({ serverOnline: !settings.serverOnline })}
                  className={`px-4 py-2 rounded-xl text-xs font-black transition-all cursor-pointer ${
                    settings.serverOnline !== false
                      ? 'bg-emerald-500 text-black shadow-lg shadow-emerald-500/30'
                      : 'bg-rose-600 text-white shadow-lg shadow-rose-600/30'
                  }`}
                >
                  {settings.serverOnline !== false ? 'SERVER ONLINE (ON)' : 'MAINTENANCE (OFF)'}
                </button>
              </div>

              {/* 2D Instant On/Off Switch */}
              <div className="p-4 rounded-xl bg-[#060b17] border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="text-sm font-bold text-white">2D Betting Master Switch</div>
                  <div className="text-xs text-slate-400">Instantly open or lock all 2D betting</div>
                </div>
                <button
                  type="button"
                  onClick={() => handleSaveSettings({ betting2D_enabled: !settings.betting2D_enabled })}
                  className={`px-4 py-2 rounded-xl text-xs font-black transition-all cursor-pointer ${
                    settings.betting2D_enabled !== false
                      ? 'bg-cyan-400 text-black shadow-lg shadow-cyan-400/30'
                      : 'bg-rose-600 text-white shadow-lg shadow-rose-600/30'
                  }`}
                >
                  {settings.betting2D_enabled !== false ? '2D OPEN (ON)' : '2D CLOSED (OFF)'}
                </button>
              </div>

              {/* 3D Instant On/Off Switch */}
              <div className="p-4 rounded-xl bg-[#060b17] border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="text-sm font-bold text-white">3D Betting Master Switch</div>
                  <div className="text-xs text-slate-400">Instantly open or lock all 3D betting</div>
                </div>
                <button
                  type="button"
                  onClick={() => handleSaveSettings({ betting3D_enabled: !settings.betting3D_enabled })}
                  className={`px-4 py-2 rounded-xl text-xs font-black transition-all cursor-pointer ${
                    settings.betting3D_enabled !== false
                      ? 'bg-amber-400 text-black shadow-lg shadow-amber-400/30'
                      : 'bg-rose-600 text-white shadow-lg shadow-rose-600/30'
                  }`}
                >
                  {settings.betting3D_enabled !== false ? '3D OPEN (ON)' : '3D CLOSED (OFF)'}
                </button>
              </div>
            </div>

            {/* Close Times & Days */}
            <div className="bg-[#0e172e] border border-slate-800 rounded-2xl p-5 space-y-4">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2 pb-3 border-b border-slate-800">
                <Clock className="w-4 h-4 text-blue-400" />
                <span>Close Times & Schedules (ပိတ်ချိန်များ စိတ်ကြိုက်ပြောင်းရန်)</span>
              </h3>

              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">2D 12:01 PM Section Close Time</label>
                  <input
                    type="text"
                    value={closeTime2D1201}
                    onChange={(e) => setCloseTime2D1201(e.target.value)}
                    className="w-full px-3 py-2 bg-[#060b17] border border-slate-700 rounded-xl text-white font-mono text-xs focus:border-cyan-400 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">2D 04:30 PM Section Close Time</label>
                  <input
                    type="text"
                    value={closeTime2D1630}
                    onChange={(e) => setCloseTime2D1630(e.target.value)}
                    className="w-full px-3 py-2 bg-[#060b17] border border-slate-700 rounded-xl text-white font-mono text-xs focus:border-cyan-400 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">3D Close Time (3D ပိတ်ချိန် စိတ်ကြိုက်သတ်မှတ်ရန်)</label>
                  <input
                    type="text"
                    value={closeTime3D}
                    onChange={(e) => setCloseTime3D(e.target.value)}
                    className="w-full px-3 py-2 bg-[#060b17] border border-slate-700 rounded-xl text-white font-mono text-xs focus:border-amber-400 outline-none"
                  />
                </div>

                <div className="pt-2">
                  <button
                    onClick={() => handleSaveSettings({
                      closeTime2D_1201: closeTime2D1201,
                      closeTime2D_1630: closeTime2D1630,
                      closeTime3D: closeTime3D,
                    })}
                    disabled={savingSettings}
                    className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-xs transition-all cursor-pointer shadow-md"
                  >
                    Save Close Times
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 6: CLOSED NUMBERS & LIMITS */}
        {activeTab === 'limits' && (
          <div className="space-y-6">
            {/* Quick Grid Selector Banner */}
            <div className="bg-gradient-to-r from-cyan-950/60 via-[#0e172e] to-blue-950/60 border border-cyan-500/40 rounded-2xl p-5 shadow-xl flex flex-wrap items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse" />
                  <h3 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-cyan-400" />
                    <span>2D 00-99 Quick Grid Selector (စာရိုက်စရာမလိုဘဲ အကွက်ဖြင့် ပိတ်ရန်/Limit လျှော့ရန်)</span>
                  </h3>
                </div>
                <p className="text-xs text-slate-300 mt-1">
                  00-99 အကွက်များကို နိပ်ပြီး ပိတ်ဂဏန်းများ အလွယ်တကူ ရွေးချယ်နိုင်သလို ဂဏန်းတစ်ခုချင်းစီတိုင်းအတွက် သီးသန့် Limit (ဥပမာ 20,000 MMK) လည်း လျှော့ချသတ်မှတ်နိုင်ပါသည်
                </p>
              </div>

              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setGridSection('12:01 PM');
                    setIsGridModalOpen(true);
                  }}
                  className="px-4 py-2.5 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-black font-black text-xs shadow-lg shadow-cyan-400/25 active:scale-95 transition-all cursor-pointer flex items-center gap-1.5"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>12:01 PM အကွက်ဖွင့်မည်</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setGridSection('04:30 PM');
                    setIsGridModalOpen(true);
                  }}
                  className="px-4 py-2.5 rounded-xl bg-blue-500 hover:bg-blue-400 text-white font-black text-xs shadow-lg shadow-blue-500/25 active:scale-95 transition-all cursor-pointer flex items-center gap-1.5"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>04:30 PM အကွက်ဖွင့်မည်</span>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* 2D Limits & Closed Numbers */}
              <div className="bg-[#0e172e] border border-slate-800 rounded-2xl p-5 space-y-4 shadow-xl">
                <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                  <h3 className="text-sm font-bold text-white uppercase tracking-wider text-cyan-400 flex items-center gap-2">
                    <Sliders className="w-4 h-4" />
                    <span>2D Multiplier, Commission & Limits (2D အဆ / ကော်မရှင် / Limit)</span>
                  </h3>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      2D Multiplier (အဆ) - Default: 80x
                    </label>
                    <input
                      type="number"
                      value={multiplier2DInput}
                      onChange={(e) => setMultiplier2DInput(e.target.value)}
                      className="w-full px-3 py-2 bg-[#060b17] border border-slate-700 rounded-xl text-white font-mono-numbers text-xs focus:border-cyan-400 outline-none font-bold"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-cyan-300 mb-1">
                      2D Commission % (ကော်မရှင် ရာခိုင်နှုန်း)
                    </label>
                    <div className="relative">
                      <input
                        type="number"
                        step="0.5"
                        min="0"
                        max="100"
                        value={commission2DInput}
                        onChange={(e) => setCommission2DInput(e.target.value)}
                        placeholder="e.g. 12"
                        className="w-full px-3 py-2 bg-[#060b17] border border-cyan-500/50 rounded-xl text-white font-mono-numbers text-xs focus:border-cyan-400 outline-none font-bold pr-8"
                      />
                      <span className="absolute right-3 top-2 text-xs font-bold text-cyan-400">%</span>
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    2D Default Bet Limit (MMK) - အများဆုံးထိုးငွေ မူလ Limit (ဥပမာ 100,000)
                  </label>
                  <input
                    type="number"
                    value={limit2DInput}
                    onChange={(e) => setLimit2DInput(e.target.value)}
                    className="w-full px-3 py-2 bg-[#060b17] border border-slate-700 rounded-xl text-white font-mono-numbers text-xs focus:border-cyan-400 outline-none"
                  />
                </div>

                {/* 12:01 Closed Numbers display */}
                <div className="p-3 rounded-xl bg-[#060b17] border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-300">12:01 PM ပိတ်ဂဏန်းများ ({closed2D1201Input ? closed2D1201Input.split(',').filter(Boolean).length : 0} ခု):</span>
                    <button
                      type="button"
                      onClick={() => {
                        setGridSection('12:01 PM');
                        setIsGridModalOpen(true);
                      }}
                      className="text-[11px] font-bold text-cyan-400 hover:underline cursor-pointer flex items-center gap-1"
                    >
                      <Sparkles className="w-3 h-3" />
                      <span>00-99 တွင် ရွေးမည်</span>
                    </button>
                  </div>
                  <input
                    type="text"
                    value={closed2D1201Input}
                    onChange={(e) => setClosed2D1201Input(e.target.value)}
                    placeholder="e.g. 18, 24, 79, 99"
                    className="w-full px-3 py-2 bg-[#0a1122] border border-slate-700 rounded-lg text-white font-mono text-xs focus:border-cyan-400 outline-none"
                  />
                  {/* 12:01 Custom Limits summary */}
                  {Object.keys(customLimits2D_1201).length > 0 && (
                    <div className="text-[11px] text-amber-300 pt-1">
                      <span className="font-bold">12:01 PM သီးသန့် Limit သတ်မှတ်ထားသော ဂဏန်းများ:</span>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {Object.entries(customLimits2D_1201).map(([n, l]) => (
                          <span key={n} className="px-1.5 py-0.5 rounded bg-amber-500/15 text-amber-300 border border-amber-500/30 text-[10px] font-mono-numbers">
                            {n}:{l >= 1000 ? `${l/1000}K` : l}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* 04:30 Closed Numbers display */}
                <div className="p-3 rounded-xl bg-[#060b17] border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-300">04:30 PM ပိတ်ဂဏန်းများ ({closed2D1630Input ? closed2D1630Input.split(',').filter(Boolean).length : 0} ခု):</span>
                    <button
                      type="button"
                      onClick={() => {
                        setGridSection('04:30 PM');
                        setIsGridModalOpen(true);
                      }}
                      className="text-[11px] font-bold text-blue-400 hover:underline cursor-pointer flex items-center gap-1"
                    >
                      <Sparkles className="w-3 h-3" />
                      <span>00-99 တွင် ရွေးမည်</span>
                    </button>
                  </div>
                  <input
                    type="text"
                    value={closed2D1630Input}
                    onChange={(e) => setClosed2D1630Input(e.target.value)}
                    placeholder="e.g. 05, 33, 88"
                    className="w-full px-3 py-2 bg-[#0a1122] border border-slate-700 rounded-lg text-white font-mono text-xs focus:border-blue-400 outline-none"
                  />
                  {/* 04:30 Custom Limits summary */}
                  {Object.keys(customLimits2D_1630).length > 0 && (
                    <div className="text-[11px] text-amber-300 pt-1">
                      <span className="font-bold">04:30 PM သီးသန့် Limit သတ်မှတ်ထားသော ဂဏန်းများ:</span>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {Object.entries(customLimits2D_1630).map(([n, l]) => (
                          <span key={n} className="px-1.5 py-0.5 rounded bg-amber-500/15 text-amber-300 border border-amber-500/30 text-[10px] font-mono-numbers">
                            {n}:{l >= 1000 ? `${l/1000}K` : l}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                <button
                  type="button"
                  onClick={() => {
                    const list1201 = closed2D1201Input.split(',').map(s => s.trim()).filter(Boolean);
                    const list1630 = closed2D1630Input.split(',').map(s => s.trim()).filter(Boolean);
                    const commPct2D = Number(commission2DInput) || 12;
                    handleSaveSettings({
                      multiplier2D: Number(multiplier2DInput) || 80,
                      commissionRate2D: commPct2D / 100,
                      limit2D: Number(limit2DInput) || 100000,
                      closedNumbers2D_1201: list1201,
                      closedNumbers2D_1630: list1630,
                      customLimits2D_1201: customLimits2D_1201,
                      customLimits2D_1630: customLimits2D_1630,
                    });
                  }}
                  className="w-full py-2.5 bg-cyan-400 hover:bg-cyan-300 text-black font-extrabold rounded-xl text-xs transition-all cursor-pointer shadow-lg shadow-cyan-400/20"
                >
                  Save 2D Multiplier, Commission & Limits
                </button>
              </div>

              {/* 3D Limits & Multipliers (Direct 500x, Toot 10x, Chai 10x) */}
              <div className="bg-[#0e172e] border border-slate-800 rounded-2xl p-5 space-y-4 shadow-xl">
                <h3 className="text-sm font-bold text-white uppercase tracking-wider pb-3 border-b border-slate-800 text-amber-400 flex items-center gap-2">
                  <Award className="w-4 h-4" />
                  <span>3D Multiplier, Commission & Limits (3D အလျော်အစား / ပတ်လည် / ချာ)</span>
                </h3>

                {/* 3D Payout Multipliers: Direct, Toot, Adjacent */}
                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="block text-[11px] font-bold text-amber-300 mb-1">
                      👑 ဒဲ့ပေါက် (ဆ)
                    </label>
                    <input
                      type="number"
                      value={multiplier3DInput}
                      onChange={(e) => setMultiplier3DInput(e.target.value)}
                      placeholder="500"
                      className="w-full px-3 py-2 bg-[#060b17] border border-amber-500/50 rounded-xl text-white font-mono-numbers text-xs focus:border-amber-400 outline-none font-bold"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-blue-300 mb-1">
                      🔄 ပတ်လည်/Toot (ဆ)
                    </label>
                    <input
                      type="number"
                      value={multiplier3DTootInput}
                      onChange={(e) => setMultiplier3DTootInput(e.target.value)}
                      placeholder="10"
                      className="w-full px-3 py-2 bg-[#060b17] border border-blue-500/50 rounded-xl text-white font-mono-numbers text-xs focus:border-blue-400 outline-none font-bold"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-purple-300 mb-1">
                      🎯 အနီးစပ်/ချာ (ဆ)
                    </label>
                    <input
                      type="number"
                      value={multiplier3DChaiInput}
                      onChange={(e) => setMultiplier3DChaiInput(e.target.value)}
                      placeholder="10"
                      className="w-full px-3 py-2 bg-[#060b17] border border-purple-500/50 rounded-xl text-white font-mono-numbers text-xs focus:border-purple-400 outline-none font-bold"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-amber-300 mb-1">
                      3D Commission % (ကော်မရှင် %)
                    </label>
                    <div className="relative">
                      <input
                        type="number"
                        step="0.5"
                        min="0"
                        max="100"
                        value={commission3DInput}
                        onChange={(e) => setCommission3DInput(e.target.value)}
                        placeholder="e.g. 10"
                        className="w-full px-3 py-2 bg-[#060b17] border border-amber-500/50 rounded-xl text-white font-mono-numbers text-xs focus:border-amber-400 outline-none font-bold pr-8"
                      />
                      <span className="absolute right-3 top-2 text-xs font-bold text-amber-400">%</span>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      3D Limit (MMK)
                    </label>
                    <input
                      type="number"
                      value={limit3DInput}
                      onChange={(e) => setLimit3DInput(e.target.value)}
                      placeholder="50000"
                      className="w-full px-3 py-2 bg-[#060b17] border border-slate-700 rounded-xl text-white font-mono-numbers text-xs focus:border-amber-400 outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    3D Closed Numbers (ကော်မာခံ၍ ရိုက်ထည့်ပါ - e.g. 123, 777, 999)
                  </label>
                  <input
                    type="text"
                    value={closed3DInput}
                    onChange={(e) => setClosed3DInput(e.target.value)}
                    className="w-full px-3 py-2 bg-[#060b17] border border-slate-700 rounded-xl text-white font-mono text-xs focus:border-amber-400 outline-none"
                  />
                </div>

                <button
                  type="button"
                  onClick={() => {
                    const list3D = closed3DInput.split(',').map(s => s.trim()).filter(Boolean);
                    const commPct3D = Number(commission3DInput) || 10;
                    handleSaveSettings({
                      multiplier3D: Number(multiplier3DInput) || 500,
                      multiplier3D_toot: Number(multiplier3DTootInput) || 10,
                      multiplier3D_chai: Number(multiplier3DChaiInput) || 10,
                      commissionRate3D: commPct3D / 100,
                      limit3D: Number(limit3DInput) || 50000,
                      closedNumbers3D: list3D,
                    });
                  }}
                  className="w-full py-2.5 bg-amber-400 hover:bg-amber-300 text-black font-extrabold rounded-xl text-xs transition-all cursor-pointer shadow-lg shadow-amber-400/20"
                >
                  Save 3D Multipliers (500x/10x/10x), Commission & Limits
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TAB 7: ANNOUNCEMENTS & UPDATES */}
        {activeTab === 'announcements' && (
          <div className="bg-[#0e172e] border border-slate-800 rounded-2xl p-6 max-w-3xl space-y-4">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider pb-3 border-b border-slate-800">
              Announcements & Customer Service Channels (သတင်းနှင့် လင့်ခ်များ)
            </h3>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Home Screen Running Marquee Bar (Noti ပြေးစာသား)
              </label>
              <textarea
                rows={3}
                value={announcementInput}
                onChange={(e) => setAnnouncementInput(e.target.value)}
                className="w-full px-3 py-2 bg-[#060b17] border border-slate-700 rounded-xl text-white text-xs focus:border-cyan-400 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Viber Support Channel Link (URL)
              </label>
              <input
                type="text"
                value={viberLinkInput}
                onChange={(e) => setViberLinkInput(e.target.value)}
                placeholder="https://viber.com/..."
                className="w-full px-3 py-2 bg-[#060b17] border border-slate-700 rounded-xl text-white text-xs font-mono focus:border-cyan-400 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Telegram Customer Care Link (URL)
              </label>
              <input
                type="text"
                value={telegramLinkInput}
                onChange={(e) => setTelegramLinkInput(e.target.value)}
                placeholder="https://t.me/..."
                className="w-full px-3 py-2 bg-[#060b17] border border-slate-700 rounded-xl text-white text-xs font-mono focus:border-cyan-400 outline-none"
              />
            </div>

            <button
              onClick={() => handleSaveSettings({
                announcement: announcementInput,
                serviceLink1: { label: 'Viber Support Channel', url: viberLinkInput || 'https://viber.com' },
                serviceLink2: { label: 'Telegram Customer Care', url: telegramLinkInput || 'https://telegram.org' },
              })}
              disabled={savingSettings}
              className="py-2.5 px-6 bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black font-extrabold rounded-xl text-xs transition-all cursor-pointer shadow-lg"
            >
              Update Notice & Links
            </button>
          </div>
        )}
      </main>

      {/* BALANCE ADJUSTMENT MODAL */}
      {balanceModalUser && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0e172e] border border-slate-700 rounded-3xl p-6 max-w-sm w-full space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <h3 className="text-sm font-bold text-white">Adjust User Balance</h3>
                <div className="text-xs text-cyan-400 font-mono-numbers">@{balanceModalUser.username}</div>
              </div>
              <button
                type="button"
                onClick={() => setBalanceModalUser(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3 rounded-xl bg-[#060b17] border border-slate-800 flex items-center justify-between text-xs font-mono-numbers">
              <span className="text-slate-400">Current Balance:</span>
              <span className="text-white font-black text-sm">{balanceModalUser.balance.toLocaleString()} MMK</span>
            </div>

            {/* Action Type */}
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setAdjustAction('add')}
                className={`py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  adjustAction === 'add'
                    ? 'bg-emerald-500 text-black font-black'
                    : 'bg-slate-800 text-slate-300'
                }`}
              >
                Deposit (+) ငွေသွင်း
              </button>
              <button
                type="button"
                onClick={() => setAdjustAction('subtract')}
                className={`py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  adjustAction === 'subtract'
                    ? 'bg-rose-500 text-white font-black'
                    : 'bg-slate-800 text-slate-300'
                }`}
              >
                Withdraw (-) ငွေထုတ်
              </button>
            </div>

            {/* Amount input */}
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Amount (MMK) *</label>
              <input
                type="number"
                value={adjustAmount}
                onChange={(e) => setAdjustAmount(e.target.value)}
                placeholder="e.g. 50000"
                className="w-full px-3 py-2 bg-[#060b17] border border-slate-700 rounded-xl text-white font-mono-numbers text-sm focus:border-cyan-400 outline-none"
              />
            </div>

            {/* Quick buttons */}
            <div className="flex gap-2">
              {['10000', '50000', '100000', '500000'].map((val) => (
                <button
                  key={val}
                  type="button"
                  onClick={() => setAdjustAmount(val)}
                  className="flex-1 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] font-mono-numbers font-bold"
                >
                  +{Number(val).toLocaleString()}
                </button>
              ))}
            </div>

            {/* Remark input */}
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Remark (မှတ်ချက်)</label>
              <input
                type="text"
                value={adjustRemark}
                onChange={(e) => setAdjustRemark(e.target.value)}
                placeholder="e.g. WavePay transfer #9938"
                className="w-full px-3 py-2 bg-[#060b17] border border-slate-700 rounded-xl text-white text-xs focus:border-cyan-400 outline-none"
              />
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setBalanceModalUser(null)}
                className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleAdjustBalance}
                disabled={adjustingBalance || !adjustAmount}
                className={`flex-1 py-2.5 rounded-xl text-xs font-extrabold text-black transition-all ${
                  adjustAction === 'add'
                    ? 'bg-emerald-400 hover:bg-emerald-300'
                    : 'bg-rose-500 hover:bg-rose-400 text-white'
                }`}
              >
                {adjustingBalance ? 'Updating...' : 'Confirm Update'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 2D 00-99 Quick Grid Selector Modal */}
      <GridSelector2DModal
        isOpen={isGridModalOpen}
        onClose={() => setIsGridModalOpen(false)}
        section={gridSection}
        onSectionChange={(newSec) => setGridSection(newSec)}
        initialClosedNumbers={
          gridSection === '12:01 PM'
            ? (closed2D1201Input ? closed2D1201Input.split(',').map(s => s.trim()).filter(Boolean) : [])
            : (closed2D1630Input ? closed2D1630Input.split(',').map(s => s.trim()).filter(Boolean) : [])
        }
        initialCustomLimits={gridSection === '12:01 PM' ? customLimits2D_1201 : customLimits2D_1630}
        defaultLimit={Number(limit2DInput) || 100000}
        onSave={(newClosed, newLimits) => {
          if (gridSection === '12:01 PM') {
            setClosed2D1201Input(newClosed.join(', '));
            setCustomLimits2D_1201(newLimits);
            handleSaveSettings({
              closedNumbers2D_1201: newClosed,
              customLimits2D_1201: newLimits,
            });
          } else {
            setClosed2D1630Input(newClosed.join(', '));
            setCustomLimits2D_1630(newLimits);
            handleSaveSettings({
              closedNumbers2D_1630: newClosed,
              customLimits2D_1630: newLimits,
            });
          }
        }}
      />

      {/* Delete User Account Confirmation Modal */}
      {userToDelete && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-[#0e172e] border border-rose-500/40 rounded-2xl p-5 shadow-2xl space-y-4">
            <div className="flex items-center gap-3 text-rose-400">
              <div className="w-10 h-10 rounded-xl bg-rose-500/20 border border-rose-500/30 flex items-center justify-center shrink-0">
                <Trash2 className="w-5 h-5 text-rose-400" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Delete User Account?</h3>
                <p className="text-xs text-rose-300">User အကောင့်အား အပြီးတိုင် ဖျက်ချမည်</p>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-[#060b17] border border-slate-800 text-xs space-y-1 text-slate-300">
              <div>အကောင့်အမည်: <span className="font-bold text-white font-mono">@{userToDelete.username}</span></div>
              <div>လက်ကျန်ငွေ: <span className="font-bold text-cyan-300 font-mono-numbers">{userToDelete.balance.toLocaleString()} MMK</span></div>
              <p className="text-rose-400/90 text-[11px] pt-1">
                သတိပြုရန် - ဤလုပ်ဆောင်ချက်ကို ပြန်ပြင်၍ မရပါ။ User ဒေတာများ အားလုံး ဖျက်ချခံရပါမည်။
              </p>
            </div>

            <div className="flex gap-2 pt-1">
              <button
                type="button"
                onClick={() => setUserToDelete(null)}
                disabled={deletingUser}
                className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold cursor-pointer"
              >
                မလုပ်တော့ပါ
              </button>
              <button
                type="button"
                onClick={() => handleDeleteUser(userToDelete)}
                disabled={deletingUser}
                className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-500 text-white font-black rounded-xl text-xs shadow-lg shadow-rose-600/30 active:scale-95 transition-all cursor-pointer"
              >
                {deletingUser ? 'Deleting...' : 'အပြီးဖျက်မည်'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
