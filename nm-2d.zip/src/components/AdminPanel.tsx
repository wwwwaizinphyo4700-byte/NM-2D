import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ShieldCheck, UserPlus, Users, Settings as SettingsIcon, 
  Trophy, CheckCircle2, AlertCircle, X, Database, Clock
} from 'lucide-react';
import { AppSettings, User } from '../types.ts';
import { formatMyanmarDate } from '../utils/myanmarTime.ts';

interface AdminPanelProps {
  currentUser: User;
  settings: AppSettings;
  onUpdateSettings: (newSettings: AppSettings) => void;
  onClose: () => void;
  onRefreshData: () => void;
}

export default function AdminPanel({
  currentUser,
  settings,
  onUpdateSettings,
  onClose,
  onRefreshData,
}: AdminPanelProps) {
  const [activeTab, setActiveTab] = useState<'users' | 'closed' | '3d' | '2d'>('users');

  // Users state
  const [usersList, setUsersList] = useState<User[]>([]);
  const [newUsername, setNewUsername] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [newBalance, setNewBalance] = useState('100000');
  const [userRole, setUserRole] = useState<'user' | 'admin'>('user');
  const [userMsg, setUserMsg] = useState<{ text: string; success: boolean } | null>(null);

  // Closed Numbers state
  const [closed1201, setClosed1201] = useState(settings.closedNumbers2D_1201.join(', '));
  const [closed1630, setClosed1630] = useState(settings.closedNumbers2D_1630.join(', '));
  const [closedMsg, setClosedMsg] = useState<string | null>(null);

  // 3D Official Draw Settlement state
  const [drawDate3D, setDrawDate3D] = useState(formatMyanmarDate());
  const [winningResult3D, setWinningResult3D] = useState('');
  const [settle3DMsg, setSettle3DMsg] = useState<{ text: string; success: boolean } | null>(null);
  const [settling3D, setSettling3D] = useState(false);

  // 2D Manual Settle state
  const [date2D, setDate2D] = useState(formatMyanmarDate());
  const [section2D, setSection2D] = useState<'12:01 PM' | '04:30 PM'>('12:01 PM');
  const [result2D, setResult2D] = useState('');
  const [settle2DMsg, setSettle2DMsg] = useState<{ text: string; success: boolean } | null>(null);

  const fetchUsers = async () => {
    try {
      const res = await fetch('/api/users');
      if (res.ok) {
        const data = await res.json();
        setUsersList(data);
      }
    } catch (e) {
      // Silent
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  // Handle User Creation
  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUsername.trim() || !newPassword.trim()) {
      setUserMsg({ text: 'Username and password required', success: false });
      return;
    }

    try {
      const res = await fetch('/api/users/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: newUsername.trim(),
          password: newPassword.trim(),
          balance: Number(newBalance) || 100000,
          role: userRole,
        }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        setUserMsg({ text: `User "${newUsername}" created successfully!`, success: true });
        setNewUsername('');
        setNewPassword('');
        fetchUsers();
      } else {
        setUserMsg({ text: data.message || 'Creation failed', success: false });
      }
    } catch (e) {
      setUserMsg({ text: 'Error connecting to server', success: false });
    }
  };

  // Handle Save Closed Numbers
  const handleSaveClosed = async () => {
    const list1201 = closed1201
      .split(',')
      .map((s) => s.trim().padStart(2, '0'))
      .filter((s) => /^\d{2}$/.test(s));

    const list1630 = closed1630
      .split(',')
      .map((s) => s.trim().padStart(2, '0'))
      .filter((s) => /^\d{2}$/.test(s));

    try {
      const res = await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          closedNumbers2D_1201: list1201,
          closedNumbers2D_1630: list1630,
        }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        onUpdateSettings(data.settings);
        setClosedMsg('Closed numbers saved successfully!');
        setTimeout(() => setClosedMsg(null), 2000);
      }
    } catch (e) {
      setClosedMsg('Failed to save settings');
    }
  };

  // Handle Settle 3D
  const handleSettle3D = async (e: React.FormEvent) => {
    e.preventDefault();
    const digits = winningResult3D.trim();
    if (!/^\d{3}$/.test(digits)) {
      setSettle3DMsg({ text: 'Result must be exactly 3 digits (e.g. 725)', success: false });
      return;
    }

    setSettling3D(true);
    setSettle3DMsg(null);

    try {
      const res = await fetch('/api/admin/settle-3d', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          date: drawDate3D,
          resultNumber: digits,
        }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        setSettle3DMsg({
          text: `Settled ${data.settledCount} bets for ${drawDate3D} with result ${digits}!`,
          success: true,
        });
        onRefreshData();
      } else {
        setSettle3DMsg({ text: data.message || 'Settlement failed', success: false });
      }
    } catch (e) {
      setSettle3DMsg({ text: 'Connection error during settlement', success: false });
    } finally {
      setSettling3D(false);
    }
  };

  // Handle Settle 2D Manual
  const handleSettle2D = async (e: React.FormEvent) => {
    e.preventDefault();
    const digits = result2D.trim();
    if (!/^\d{2}$/.test(digits)) {
      setSettle2DMsg({ text: 'Result must be exactly 2 digits (e.g. 58)', success: false });
      return;
    }

    try {
      const res = await fetch('/api/admin/settle-2d', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          date: date2D,
          section: section2D,
          resultNumber: digits,
        }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        setSettle2DMsg({ text: `2D ${section2D} settled with result ${digits}!`, success: true });
        onRefreshData();
      } else {
        setSettle2DMsg({ text: data.message || 'Settlement failed', success: false });
      }
    } catch (e) {
      setSettle2DMsg({ text: 'Error settling 2D', success: false });
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 select-none">
      <div className="w-full max-w-md h-[90vh] bg-[#091122] border border-cyan-500/30 rounded-3xl flex flex-col shadow-2xl overflow-hidden text-slate-100">
        
        {/* HEADER */}
        <header className="shrink-0 p-3.5 bg-[#0e1930] border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-cyan-500/20 border border-cyan-400 flex items-center justify-center text-cyan-300">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-black text-white uppercase tracking-wider">
                Admin Control Panel
              </h2>
              <div className="text-[10px] text-cyan-400 font-mono-numbers">
                Logged in as: {currentUser.username}
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </header>

        {/* TABS SELECTOR */}
        <div className="shrink-0 p-2 bg-[#060c18] border-b border-slate-800/80">
          <div className="grid grid-cols-4 gap-1 p-0.5 bg-[#091224] rounded-xl border border-slate-800 text-[10px] font-black uppercase">
            <button
              onClick={() => setActiveTab('users')}
              className={`py-2 rounded-lg transition-all cursor-pointer ${
                activeTab === 'users' ? 'bg-cyan-500 text-black shadow' : 'text-slate-400 hover:text-white'
              }`}
            >
              Users
            </button>
            <button
              onClick={() => setActiveTab('closed')}
              className={`py-2 rounded-lg transition-all cursor-pointer ${
                activeTab === 'closed' ? 'bg-cyan-500 text-black shadow' : 'text-slate-400 hover:text-white'
              }`}
            >
              Closed
            </button>
            <button
              onClick={() => setActiveTab('3d')}
              className={`py-2 rounded-lg transition-all cursor-pointer ${
                activeTab === '3d' ? 'bg-cyan-500 text-black shadow' : 'text-slate-400 hover:text-white'
              }`}
            >
              3D Draw
            </button>
            <button
              onClick={() => setActiveTab('2d')}
              className={`py-2 rounded-lg transition-all cursor-pointer ${
                activeTab === '2d' ? 'bg-cyan-500 text-black shadow' : 'text-slate-400 hover:text-white'
              }`}
            >
              2D Settle
            </button>
          </div>
        </div>

        {/* SCROLLABLE BODY */}
        <div className="flex-1 overflow-y-auto custom-scrollbar p-3 space-y-4">
          
          {/* TAB 1: USER MANAGEMENT */}
          {activeTab === 'users' && (
            <div className="space-y-4">
              {/* Form to create new user */}
              <div className="p-3.5 rounded-2xl bg-[#0c162c] border border-cyan-500/20">
                <div className="flex items-center gap-1.5 text-xs font-bold text-cyan-300 mb-2.5">
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>Create Authorized Account</span>
                </div>
                <form onSubmit={handleCreateUser} className="space-y-2.5">
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[9px] uppercase font-bold text-slate-400 mb-0.5">
                        Username
                      </label>
                      <input
                        type="text"
                        value={newUsername}
                        onChange={(e) => setNewUsername(e.target.value)}
                        placeholder="e.g. member02"
                        className="w-full px-2.5 py-2 bg-[#060b17] border border-slate-700 rounded-xl text-white font-mono-numbers text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-[9px] uppercase font-bold text-slate-400 mb-0.5">
                        Password
                      </label>
                      <input
                        type="password"
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        placeholder="Password"
                        className="w-full px-2.5 py-2 bg-[#060b17] border border-slate-700 rounded-xl text-white font-mono-numbers text-xs"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[9px] uppercase font-bold text-slate-400 mb-0.5">
                        Initial Balance (MMK)
                      </label>
                      <input
                        type="number"
                        value={newBalance}
                        onChange={(e) => setNewBalance(e.target.value)}
                        placeholder="100000"
                        className="w-full px-2.5 py-2 bg-[#060b17] border border-slate-700 rounded-xl text-white font-mono-numbers text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-[9px] uppercase font-bold text-slate-400 mb-0.5">
                        Account Role
                      </label>
                      <select
                        value={userRole}
                        onChange={(e) => setUserRole(e.target.value as any)}
                        className="w-full px-2.5 py-2 bg-[#060b17] border border-slate-700 rounded-xl text-white font-mono-numbers text-xs"
                      >
                        <option value="user">Member (Player)</option>
                        <option value="admin">Administrator</option>
                      </select>
                    </div>
                  </div>

                  {userMsg && (
                    <div className={`p-2 rounded-lg text-xs flex items-center gap-1.5 ${
                      userMsg.success ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-300'
                    }`}>
                      {userMsg.success ? <CheckCircle2 className="w-3.5 h-3.5" /> : <AlertCircle className="w-3.5 h-3.5" />}
                      <span>{userMsg.text}</span>
                    </div>
                  )}

                  <button
                    type="submit"
                    className="w-full py-2.5 bg-gradient-to-r from-cyan-400 to-blue-500 text-black font-extrabold text-xs rounded-xl shadow cursor-pointer"
                  >
                    Add User
                  </button>
                </form>
              </div>

              {/* Users Directory */}
              <div>
                <div className="text-[10px] uppercase font-bold text-slate-400 px-1 mb-1.5 flex items-center justify-between">
                  <span>Registered Users ({usersList.length})</span>
                  <span>Balance</span>
                </div>
                <div className="space-y-1.5 font-mono-numbers">
                  {usersList.map((u) => (
                    <div
                      key={u.id}
                      className="p-2.5 rounded-xl bg-[#0b1424] border border-slate-800 text-xs flex items-center justify-between"
                    >
                      <div className="flex items-center gap-2">
                        <span className="w-7 h-7 rounded-lg bg-slate-800 flex items-center justify-center font-bold text-cyan-300">
                          {u.username.slice(0, 2).toUpperCase()}
                        </span>
                        <div>
                          <div className="text-white font-bold">{u.username}</div>
                          <div className="text-[10px] text-slate-400 uppercase">{u.role}</div>
                        </div>
                      </div>
                      <div className="text-cyan-300 font-bold">
                        {Number(u.balance).toLocaleString()} MMK
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: CLOSED NUMBERS */}
          {activeTab === 'closed' && (
            <div className="space-y-3">
              <div className="p-3.5 rounded-2xl bg-[#0c162c] border border-cyan-500/20 space-y-3">
                <div className="flex items-center gap-1.5 text-xs font-bold text-cyan-300">
                  <SettingsIcon className="w-3.5 h-3.5" />
                  <span>2D Closed / Blocked Numbers</span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Numbers entered here cannot be bet by users. Separate numbers with commas.
                </p>

                <div>
                  <label className="block text-[10px] uppercase font-bold text-cyan-400 mb-1">
                    12:01 Section Blocked Numbers
                  </label>
                  <input
                    type="text"
                    value={closed1201}
                    onChange={(e) => setClosed1201(e.target.value)}
                    placeholder="18, 24, 79, 99"
                    className="w-full px-3 py-2 bg-[#060b17] border border-slate-700 rounded-xl text-white font-mono-numbers text-xs"
                  />
                </div>

                <div>
                  <label className="block text-[10px] uppercase font-bold text-blue-400 mb-1">
                    4:30 Section Blocked Numbers
                  </label>
                  <input
                    type="text"
                    value={closed1630}
                    onChange={(e) => setClosed1630(e.target.value)}
                    placeholder="05, 33, 88"
                    className="w-full px-3 py-2 bg-[#060b17] border border-slate-700 rounded-xl text-white font-mono-numbers text-xs"
                  />
                </div>

                {closedMsg && (
                  <div className="p-2 rounded-lg bg-emerald-500/20 text-emerald-400 text-xs">
                    {closedMsg}
                  </div>
                )}

                <button
                  type="button"
                  onClick={handleSaveClosed}
                  className="w-full py-2.5 bg-gradient-to-r from-cyan-400 to-blue-500 text-black font-extrabold text-xs rounded-xl shadow cursor-pointer"
                >
                  Save Closed Numbers
                </button>
              </div>
            </div>
          )}

          {/* TAB 3: 3D OFFICIAL DRAW SETTLEMENT */}
          {activeTab === '3d' && (
            <div className="space-y-3">
              <div className="p-3.5 rounded-2xl bg-[#0c162c] border border-cyan-500/20 space-y-3">
                <div className="flex items-center gap-1.5 text-xs font-bold text-cyan-300">
                  <Trophy className="w-3.5 h-3.5" />
                  <span>Official Thai 3D Draw Settlement</span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Thai Lottery is held on the 1st and 16th only. Enter official winning 3-digit number below to immediately settle all pending bets and pay winners.
                </p>

                <form onSubmit={handleSettle3D} className="space-y-3">
                  <div>
                    <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">
                      Draw Date (DD-MM-YYYY)
                    </label>
                    <input
                      type="text"
                      value={drawDate3D}
                      onChange={(e) => setDrawDate3D(e.target.value)}
                      placeholder="e.g. 16-09-2026"
                      className="w-full px-3 py-2 bg-[#060b17] border border-slate-700 rounded-xl text-white font-mono-numbers text-xs"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] uppercase font-bold text-cyan-400 mb-1">
                      Official 3-Digit Winning Number
                    </label>
                    <input
                      type="text"
                      maxLength={3}
                      value={winningResult3D}
                      onChange={(e) => setWinningResult3D(e.target.value.replace(/[^0-9]/g, ''))}
                      placeholder="e.g. 725"
                      className="w-full px-3 py-2.5 bg-[#060b17] border border-cyan-500 rounded-xl text-white font-mono-numbers text-lg font-black tracking-widest text-center"
                    />
                  </div>

                  {settle3DMsg && (
                    <div className={`p-2 rounded-lg text-xs flex items-center gap-1.5 ${
                      settle3DMsg.success ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-300'
                    }`}>
                      {settle3DMsg.success ? <CheckCircle2 className="w-3.5 h-3.5" /> : <AlertCircle className="w-3.5 h-3.5" />}
                      <span>{settle3DMsg.text}</span>
                    </div>
                  )}

                  <button
                    type="submit"
                    disabled={settling3D}
                    className="w-full py-2.5 bg-gradient-to-r from-cyan-400 to-blue-500 text-black font-extrabold text-xs rounded-xl shadow cursor-pointer disabled:opacity-50"
                  >
                    {settling3D ? 'Settling...' : 'Submit 3D Result & Settle Bets'}
                  </button>
                </form>
              </div>
            </div>
          )}

          {/* TAB 4: 2D MANUAL SETTLEMENT */}
          {activeTab === '2d' && (
            <div className="space-y-3">
              <div className="p-3.5 rounded-2xl bg-[#0c162c] border border-cyan-500/20 space-y-3">
                <div className="flex items-center gap-1.5 text-xs font-bold text-cyan-300">
                  <Clock className="w-3.5 h-3.5" />
                  <span>Manual 2D Section Settlement</span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Normally settled automatically from the Thai Stock 2D API. You can also manually trigger or verify section settlements here.
                </p>

                <form onSubmit={handleSettle2D} className="space-y-3">
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">
                        Date (DD-MM-YYYY)
                      </label>
                      <input
                        type="text"
                        value={date2D}
                        onChange={(e) => setDate2D(e.target.value)}
                        className="w-full px-3 py-2 bg-[#060b17] border border-slate-700 rounded-xl text-white font-mono-numbers text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">
                        Section
                      </label>
                      <select
                        value={section2D}
                        onChange={(e) => setSection2D(e.target.value as any)}
                        className="w-full px-3 py-2 bg-[#060b17] border border-slate-700 rounded-xl text-white font-mono-numbers text-xs"
                      >
                        <option value="12:01 PM">12:01 PM</option>
                        <option value="04:30 PM">4:30 PM</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] uppercase font-bold text-cyan-400 mb-1">
                      Official 2D Number (2 digits)
                    </label>
                    <input
                      type="text"
                      maxLength={2}
                      value={result2D}
                      onChange={(e) => setResult2D(e.target.value.replace(/[^0-9]/g, ''))}
                      placeholder="e.g. 58"
                      className="w-full px-3 py-2.5 bg-[#060b17] border border-cyan-500 rounded-xl text-white font-mono-numbers text-lg font-black tracking-widest text-center"
                    />
                  </div>

                  {settle2DMsg && (
                    <div className={`p-2 rounded-lg text-xs flex items-center gap-1.5 ${
                      settle2DMsg.success ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-300'
                    }`}>
                      {settle2DMsg.success ? <CheckCircle2 className="w-3.5 h-3.5" /> : <AlertCircle className="w-3.5 h-3.5" />}
                      <span>{settle2DMsg.text}</span>
                    </div>
                  )}

                  <button
                    type="submit"
                    className="w-full py-2.5 bg-gradient-to-r from-cyan-400 to-blue-500 text-black font-extrabold text-xs rounded-xl shadow cursor-pointer"
                  >
                    Settle 2D Section
                  </button>
                </form>
              </div>
            </div>
          )}

        </div>

        {/* FOOTER */}
        <footer className="shrink-0 p-2.5 bg-[#060c18] border-t border-slate-800 text-[10px] text-slate-400 flex items-center justify-center gap-1.5 font-mono-numbers">
          <Database className="w-3.5 h-3.5 text-cyan-400" />
          <span>Supabase / Persistent Database Storage Active</span>
        </footer>
      </div>
    </div>
  );
}
