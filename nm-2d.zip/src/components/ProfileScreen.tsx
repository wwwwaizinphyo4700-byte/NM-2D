import { LogOut, ExternalLink, ArrowLeft, MessageSquare, Send } from 'lucide-react';
import NM2DLogo from './NM2DLogo.tsx';
import { User, AppSettings } from '../types.ts';
import { playTouchSound } from '../utils/audio.ts';

interface ProfileScreenProps {
  user: User;
  settings: AppSettings;
  onLogout: () => void;
  onUpdateSettings: (newSettings: AppSettings) => void;
  onRefreshData: () => void;
  onBackToHome: () => void;
}

export default function ProfileScreen({
  user,
  settings,
  onLogout,
  onBackToHome,
}: ProfileScreenProps) {
  const viberUrl = settings.serviceLink1?.url || 'viber://chat?number=%2B959781187965';
  const telegramUrl = settings.serviceLink2?.url || 'https://t.me/zussio2';

  return (
    <div className="flex flex-col justify-between h-full w-full max-w-lg md:max-w-xl mx-auto bg-[#080d1a] text-slate-100 overflow-hidden select-none p-4">
      {/* Top Header */}
      <div className="flex items-center justify-between pb-2 border-b border-slate-800">
        <button
          onClick={() => {
            playTouchSound('tap');
            onBackToHome();
          }}
          className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <span className="text-xs uppercase font-extrabold tracking-wider text-slate-400">
          Account Profile
        </span>
        <div className="w-6" />
      </div>

      {/* Main Profile Info (f) */}
      <div className="my-auto flex flex-col items-center text-center space-y-4">
        {/* NM2D Logo (f) */}
        <div className="scale-110">
          <NM2DLogo size="lg" showSubtitle={false} />
        </div>

        {/* Username & Balance (f) */}
        <div>
          <div className="flex items-center justify-center gap-1.5">
            <h2 className="text-xl font-black text-white font-mono-numbers tracking-tight">
              {user.username}
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1 font-mono-numbers">
            Balance: <span className="text-cyan-300 font-bold">{Number(user.balance).toLocaleString()} MMK</span>
          </p>
        </div>

        {/* Customer Care Service Links */}
        <div className="w-full space-y-2.5 pt-2">
          {/* Viber Direct Chat */}
          <a
            href={viberUrl}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => playTouchSound('tap')}
            className="flex items-center justify-between p-3.5 rounded-2xl bg-[#0d1628] border border-purple-500/30 hover:border-purple-400 text-slate-200 transition-colors shadow-md group cursor-pointer"
          >
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center">
                <MessageSquare className="w-4 h-4" />
              </div>
              <div className="text-left">
                <div className="text-xs font-black text-purple-300">
                  {settings.serviceLink1?.label || 'Viber Support (09781187965)'}
                </div>
                <div className="text-[10px] text-slate-400">09781187965 သို့ တိုက်ရိုက် Chat မည်</div>
              </div>
            </div>
            <ExternalLink className="w-4 h-4 text-purple-400 group-hover:translate-x-0.5 transition-transform" />
          </a>

          {/* Telegram Direct Chat */}
          <a
            href={telegramUrl}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => playTouchSound('tap')}
            className="flex items-center justify-between p-3.5 rounded-2xl bg-[#0d1628] border border-cyan-500/30 hover:border-cyan-400 text-slate-200 transition-colors shadow-md group cursor-pointer"
          >
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center">
                <Send className="w-4 h-4" />
              </div>
              <div className="text-left">
                <div className="text-xs font-black text-cyan-300">
                  {settings.serviceLink2?.label || 'Telegram Support (@zussio2)'}
                </div>
                <div className="text-[10px] text-slate-400">@zussio2 သို့ တိုက်ရိုက် Chat မည်</div>
              </div>
            </div>
            <ExternalLink className="w-4 h-4 text-cyan-400 group-hover:translate-x-0.5 transition-transform" />
          </a>
        </div>
      </div>

      {/* Logout Button (f) */}
      <div className="w-full pt-4">
        <button
          onClick={() => {
            playTouchSound('alert');
            onLogout();
          }}
          className="w-full py-3.5 px-4 rounded-2xl bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/30 text-rose-300 font-extrabold text-sm active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-rose-950/40"
        >
          <LogOut className="w-4 h-4 text-rose-400" />
          <span>Logout</span>
        </button>
      </div>
    </div>
  );
}
