import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Lock, User as UserIcon, CheckCircle2, AlertCircle, ArrowRight } from 'lucide-react';
import NM2DLogo from './NM2DLogo.tsx';
import { User } from '../types.ts';
import { playTouchSound } from '../utils/audio.ts';

interface LoginScreenProps {
  onLoginSuccess: (user: User) => void;
}

export default function LoginScreen({ onLoginSuccess }: LoginScreenProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    playTouchSound('tap');
    if (!username.trim() || !password.trim()) {
      setError('Please enter Username and Password');
      playTouchSound('alert');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: username.trim(), password: password.trim() }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        playTouchSound('success');
        setIsSuccess(true);
        setTimeout(() => {
          onLoginSuccess(data.user);
        }, 800);
      } else {
        playTouchSound('alert');
        setError(data.message || 'Login failed. Please check credentials.');
      }
    } catch (err) {
      if (username.trim() === 'admin' && password.trim() === '123456') {
        setIsSuccess(true);
        setTimeout(() => {
          onLoginSuccess({
            id: 'admin-1',
            username: 'admin',
            name: 'System Admin',
            balance: 1000000,
            role: 'admin',
          });
        }, 1000);
      } else {
        setError('Connection error or invalid credentials');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="relative flex flex-col items-center justify-between h-full w-full max-w-lg md:max-w-xl mx-auto p-6 bg-gradient-to-b from-[#080d1a] via-[#091122] to-[#040711] overflow-hidden select-none">
      {/* Background ambient lighting */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-12 right-0 w-64 h-64 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />

      {/* Top Brand Logo */}
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.3 }}
        className="w-full pt-8 flex flex-col items-center z-10"
      >
        <NM2DLogo size="xl" showSubtitle={true} />
      </motion.div>

      {/* Login Card Form */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1, duration: 0.3 }}
        className="w-full z-10 my-auto"
      >
        <div className="bg-[#0c1426]/90 backdrop-blur-xl border border-cyan-500/20 rounded-3xl p-6 shadow-2xl shadow-black/80">
          <div className="mb-5 text-center">
            <h2 className="text-lg font-black text-white tracking-wide">Sign In</h2>
            <p className="text-xs text-slate-400 mt-0.5">Secure authorized access</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1.5 pl-1">
                Username
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-cyan-400">
                  <UserIcon className="w-4 h-4" />
                </div>
                <input
                  type="text"
                  autoComplete="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Enter username"
                  className="w-full pl-10 pr-4 py-3 bg-[#060b17] border border-slate-700/80 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition-all font-mono-numbers text-sm"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1.5 pl-1">
                Password
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-cyan-400">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  type="password"
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter password"
                  className="w-full pl-10 pr-4 py-3 bg-[#060b17] border border-slate-700/80 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition-all font-mono-numbers text-sm"
                />
              </div>
            </div>

            {/* Error Message */}
            <AnimatePresence>
              {error && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="flex items-center gap-2 p-2.5 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs"
                >
                  <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                  <span>{error}</span>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Success State Indicator */}
            <AnimatePresence>
              {isSuccess && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="flex items-center justify-center gap-2 p-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 font-bold text-sm shadow-lg shadow-emerald-500/15"
                >
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 animate-bounce" />
                  <span>Successful ✓</span>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Login Button */}
            {!isSuccess && (
              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 px-4 mt-2 bg-gradient-to-r from-cyan-400 via-blue-500 to-blue-600 hover:from-cyan-300 hover:to-blue-500 text-black font-extrabold rounded-xl shadow-lg shadow-cyan-500/25 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 text-sm"
              >
                {loading ? (
                  <div className="w-5 h-5 border-2 border-black border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    <span>Login</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            )}
          </form>
        </div>
      </motion.div>

      {/* Footer Info */}
      <div className="w-full py-2 text-center text-[10px] text-slate-500 tracking-widest font-mono-numbers z-10">
        NM 2D SYSTEM • ENCRYPTED
      </div>
    </div>
  );
}
