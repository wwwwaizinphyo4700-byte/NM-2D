import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  FileText, Calendar, ChevronRight, ArrowLeft, RefreshCw, 
  TrendingUp, TrendingDown, Database, ShieldCheck 
} from 'lucide-react';
import { User, DailyLedgerEntry, Bet2D, Bet3D } from '../types.ts';
import { playTouchSound } from '../utils/audio.ts';

interface LedgerScreenProps {
  user: User;
  onBackToHome: () => void;
}

export default function LedgerScreen({ user, onBackToHome }: LedgerScreenProps) {
  const [activeTab, setActiveTab] = useState<'ALL' | '2D' | '3D'>('ALL');
  const [loading, setLoading] = useState(false);
  const [ledgerAll, setLedgerAll] = useState<DailyLedgerEntry[]>([]);
  const [ledger2D, setLedger2D] = useState<DailyLedgerEntry[]>([]);
  const [ledger3D, setLedger3D] = useState<DailyLedgerEntry[]>([]);
  const [selectedEntry, setSelectedEntry] = useState<DailyLedgerEntry | null>(null);

  // Fetch aggregated daily ledger
  const fetchLedger = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/ledger?userId=${user.id}`);
      if (res.ok) {
        const data = await res.json();
        setLedgerAll(data.ledgerAll || []);
        setLedger2D(data.ledger2D || []);
        setLedger3D(data.ledger3D || []);
      }
    } catch (e) {
      console.error('Failed to fetch ledger:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLedger();
  }, [user.id]);

  const activeList = activeTab === 'ALL' ? ledgerAll : activeTab === '2D' ? ledger2D : ledger3D;

  return (
    <div className="flex flex-col justify-between h-full w-full max-w-lg md:max-w-xl mx-auto bg-[#0a0f1d] text-slate-100 overflow-hidden select-none">
      {/* FIXED (f) TOP HEADER */}
      <header className="shrink-0 p-3 bg-[#0d1424] border-b border-slate-800 flex items-center justify-between z-10">
        <button
          onClick={() => {
            playTouchSound('tap');
            onBackToHome();
          }}
          className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <div className="text-center">
          <h2 className="text-sm font-extrabold text-white uppercase tracking-wider">Settlement Ledger</h2>
          <div className="text-[10px] text-cyan-400 font-medium flex items-center justify-center gap-1">
            <ShieldCheck className="w-3 h-3 text-cyan-400" />
            <span>အမြဲတမ်း စာရင်းမှတ်တမ်း (Permanent Ledger)</span>
          </div>
        </div>
        <button
          onClick={() => {
            playTouchSound('tap');
            fetchLedger();
          }}
          className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-amber-400 cursor-pointer"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </header>

      {/* FIXED (f) ALL / 2D / 3D TAB SELECTOR */}
      <div className="shrink-0 p-2 bg-[#111929] border-b border-slate-800/80 z-10">
        <div className="grid grid-cols-3 p-1 bg-[#090d17] rounded-xl border border-slate-800 text-[11px]">
          <button
            onClick={() => {
              playTouchSound('select');
              setActiveTab('ALL');
              setSelectedEntry(null);
            }}
            className={`py-2 font-black uppercase tracking-wider rounded-lg transition-all cursor-pointer ${
              activeTab === 'ALL'
                ? 'bg-gradient-to-r from-cyan-400 to-blue-500 text-black shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            All စာရင်းချုပ်
          </button>
          <button
            onClick={() => {
              playTouchSound('select');
              setActiveTab('2D');
              setSelectedEntry(null);
            }}
            className={`py-2 font-black uppercase tracking-wider rounded-lg transition-all cursor-pointer ${
              activeTab === '2D'
                ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-black shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            2D Ledger
          </button>
          <button
            onClick={() => {
              playTouchSound('select');
              setActiveTab('3D');
              setSelectedEntry(null);
            }}
            className={`py-2 font-black uppercase tracking-wider rounded-lg transition-all cursor-pointer ${
              activeTab === '3D'
                ? 'bg-gradient-to-r from-emerald-400 to-emerald-500 text-black shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            3D Ledger
          </button>
        </div>
      </div>

      {/* SCROLLABLE (s) MAIN CONTENT */}
      <div className="flex-1 overflow-y-auto custom-scrollbar p-3 space-y-2">
        {loading ? (
          <div className="flex flex-col items-center justify-center py-20 text-slate-500 text-xs">
            <RefreshCw className="w-6 h-6 animate-spin mb-2 text-amber-400" />
            <span>Loading ledger summaries...</span>
          </div>
        ) : activeList.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-slate-500 text-xs text-center">
            <FileText className="w-8 h-8 text-slate-600 mb-2" />
            <p className="font-semibold text-slate-400">No {activeTab} ledger archives yet.</p>
            <p className="text-[11px] text-slate-500 mt-1">
              Confirmed bets and settlements automatically roll up here daily.
            </p>
          </div>
        ) : (
          <div className="space-y-2">
            <div className="text-[10px] uppercase font-bold text-slate-400 px-1 flex items-center justify-between">
              <span>Date: ရက်စွဲ / စုစုပေါင်းထိုးငွေ</span>
              <span>အသားတင်ရှင်းတမ်း (+/-)</span>
            </div>

            {activeList.map((row) => (
              <div
                key={row.date}
                onClick={() => {
                  playTouchSound('tap');
                  setSelectedEntry(row);
                }}
                className="p-3.5 rounded-2xl bg-[#0f172a] border border-slate-800/80 hover:border-cyan-400/40 active:scale-[0.99] transition-all cursor-pointer shadow-md shadow-black/40 flex items-center justify-between font-mono-numbers"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-cyan-400">
                    <Calendar className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white tracking-wide flex items-center gap-1.5">
                      <span className="text-slate-400 font-normal">Date:</span>
                      <span className="text-cyan-300 font-extrabold">{row.date}</span>
                    </div>
                    <div className="text-[10px] text-slate-400 mt-0.5">
                      ထိုးငွေ: <span className="text-slate-200 font-semibold">{row.totalBet.toLocaleString()}</span> MMK
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <div className="text-right">
                    <div className={`text-xs font-black ${row.netTotal >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {row.netTotal > 0 ? `+${row.netTotal.toLocaleString()}` : row.netTotal.toLocaleString()} MMK
                    </div>
                    <div className="text-[10px] text-slate-400 mt-0.5">
                      Comm: +{row.commission.toLocaleString()} MMK
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-500" />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* DETAIL MODAL FOR SELECTED DATE (Drilldown) */}
      <AnimatePresence>
        {selectedEntry && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex flex-col justify-end"
          >
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 250 }}
              className="bg-[#0e1627] border-t border-slate-700 rounded-t-3xl p-4 max-h-[85vh] flex flex-col text-slate-100 max-w-md mx-auto w-full"
            >
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div>
                  <h3 className="text-sm font-extrabold text-white">
                    {activeTab} Detailed Ledger: {selectedEntry.date}
                  </h3>
                  <div className="text-[10px] text-slate-400">
                    {selectedEntry.bets.length} recorded bets
                  </div>
                </div>
                <button
                  onClick={() => setSelectedEntry(null)}
                  className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white cursor-pointer"
                >
                  Close
                </button>
              </div>

              {/* Items Breakdown list */}
              <div className="flex-1 overflow-y-auto custom-scrollbar my-3 space-y-1.5 font-mono-numbers">
                {selectedEntry.bets.map((bet: any) => (
                  <div
                    key={bet.id}
                    className="p-2.5 rounded-xl bg-[#111c30] border border-slate-800 text-xs flex items-center justify-between"
                  >
                    <div className="flex items-center gap-2">
                      <span className="w-8 h-8 rounded-lg bg-amber-400/20 text-amber-300 font-black flex items-center justify-center text-sm">
                        {bet.number}
                      </span>
                      <div>
                        <div className="text-white font-medium">
                          {bet.section || '3D Official'} • {bet.time}
                        </div>
                        <div className="text-[10px] text-slate-400">
                          {bet.multiplier}x • Result: {bet.resultNumber || '--'}
                        </div>
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="font-bold text-white">
                        {bet.amount.toLocaleString()} MMK
                      </div>
                      <div className="text-[10px] font-bold">
                        {bet.status === 'win' && (
                          <span className="text-emerald-400">+{bet.winAmount.toLocaleString()} Win</span>
                        )}
                        {bet.status === 'lose' && (
                          <span className="text-rose-400">-{bet.amount.toLocaleString()} Lose</span>
                        )}
                        {bet.status === 'pending' && (
                          <span className="text-amber-400">Pending</span>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Modal summary footer */}
              <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs font-mono-numbers">
                <span className="text-slate-400">Net Day Settlement:</span>
                <span className={`text-base font-extrabold ${selectedEntry.netTotal >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {selectedEntry.netTotal > 0 ? `+${selectedEntry.netTotal.toLocaleString()}` : selectedEntry.netTotal.toLocaleString()} MMK
                </span>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* FIXED (f) PERMANENT RETENTION FOOTER */}
      <footer className="shrink-0 p-2.5 bg-[#0d1424] border-t border-slate-800/90 text-center text-[10px] text-slate-400 flex items-center justify-center gap-1.5">
        <Database className="w-3.5 h-3.5 text-cyan-400" />
        <span>လုံခြုံစိတ်ချရသော စာရင်းချုပ် မှတ်တမ်းများ • အမြဲတမ်း သိမ်းဆည်းထားပါသည်</span>
      </footer>
    </div>
  );
}
