import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { RefreshCw, Clock, Wallet, ShieldAlert, CheckCircle2, Megaphone } from 'lucide-react';
import NM2DLogo from './NM2DLogo.tsx';
import { User, LiveMarketData } from '../types.ts';
import { formatMyanmarDate, formatMyanmarTime, isMarketWeekend, isMarketOpenNow } from '../utils/myanmarTime.ts';
import { playTouchSound } from '../utils/audio.ts';

interface HomeScreenProps {
  user: User;
  announcement?: string;
  onRefreshBalance: () => void;
}

export default function HomeScreen({ user, announcement, onRefreshBalance }: HomeScreenProps) {
  const [liveData, setLiveData] = useState<LiveMarketData | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [mmtTime, setMmtTime] = useState<string>('');
  const [mmtDate, setMmtDate] = useState<string>('');

  const weekend = isMarketWeekend();
  const marketOpen = isMarketOpenNow();

  // Clock ticker in Myanmar Time
  useEffect(() => {
    const updateTime = () => {
      setMmtTime(formatMyanmarTime());
      setMmtDate(formatMyanmarDate());
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Fetch Live 2D Market Data only on open trading days, or once on mount for closed state
  const fetchMarket = async (silent = false) => {
    if (!silent) setIsRefreshing(true);
    try {
      const res = await fetch('/api/live');
      if (res.ok) {
        const data = await res.json();
        setLiveData(data);
      }
    } catch (e) {
      console.error('Failed to fetch market data:', e);
    } finally {
      if (!silent) setIsRefreshing(false);
    }
  };

  useEffect(() => {
    fetchMarket();
    // Only poll API repeatedly if NOT a weekend and within trading hours!
    if (!weekend && marketOpen) {
      const timer = setInterval(() => fetchMarket(true), 5000);
      return () => clearInterval(timer);
    }
  }, [weekend, marketOpen]);

  const liveTwod = liveData?.live?.twod || '--';
  const liveSet = liveData?.live?.set || '1,626.27';
  const liveVal = liveData?.live?.value || '85,650.24';

  // Section results
  const res1201 = liveData?.result?.find((r) => r.open_time.startsWith('12:01'))?.twod || '--';
  const res1630 = liveData?.result?.find((r) => r.open_time.startsWith('16:30'))?.twod || '--';

  return (
    <div className="relative flex flex-col justify-between h-full w-full max-w-lg md:max-w-xl mx-auto px-4 py-3 bg-[#080d1a] overflow-hidden select-none">
      {/* Background neon glows */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-16 right-0 w-52 h-52 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />

      {/* TOP HEADER: NM 2D Logo on left, Balance on right (Fixed) */}
      <header className="flex items-center justify-between z-10 pt-1 pb-2 border-b border-slate-800/80">
        <div className="flex items-center gap-2.5">
          <NM2DLogo size="sm" />
          <div>
            <div className="text-sm font-extrabold tracking-tight text-white flex items-center gap-1">
              <span>NM</span>
              <span className="text-cyan-400">2D</span>
            </div>
            <div className="text-[10px] text-cyan-400 font-bold uppercase tracking-wider flex items-center gap-1">
              {weekend ? (
                <span className="text-rose-400 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
                  WEEKEND CLOSED
                </span>
              ) : marketOpen ? (
                <span className="text-emerald-400 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  LIVE MARKET
                </span>
              ) : (
                <span className="text-amber-400 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                  SESSION CLOSED
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Balance Box */}
        <div className="flex items-center gap-2 bg-[#0d1527] border border-cyan-500/30 px-3 py-1.5 rounded-xl shadow-md shadow-black/50">
          <div className="text-right">
            <div className="text-[9px] uppercase tracking-wider text-slate-400 font-semibold flex items-center justify-end gap-1">
              <Wallet className="w-2.5 h-2.5 text-cyan-400" />
              <span>Balance</span>
            </div>
            <div className="text-sm font-black text-cyan-300 font-mono-numbers leading-tight">
              {Number(user.balance).toLocaleString()} <span className="text-[10px] text-slate-400 font-normal">MMK</span>
            </div>
          </div>
          <button
            onClick={() => {
              onRefreshBalance();
              fetchMarket();
            }}
            title="Refresh"
            className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-cyan-400 transition-colors cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-cyan-400' : ''}`} />
          </button>
        </div>
      </header>

      {/* CENTER STAGE: LIVE 2D DISPLAY (Fixed - strictly NO scroll) */}
      <main className="my-auto py-1 flex flex-col items-center justify-center z-10 space-y-2.5">
        {/* SLOW RUNNING NOTIFICATION MARQUEE (Above Live Card) */}
        <div className="w-full flex items-center gap-2 px-3 py-1.5 rounded-xl bg-gradient-to-r from-[#0c1527] via-[#0e1930] to-[#0c1527] border border-cyan-500/25 shadow-md shadow-black/40 overflow-hidden">
          <div className="shrink-0 flex items-center gap-1.5 px-1.5 py-0.5 rounded-md bg-cyan-500/15 border border-cyan-500/30 text-[10px] font-black uppercase text-cyan-300 tracking-wider">
            <Megaphone className="w-3 h-3 text-cyan-400 animate-pulse" />
            <span>Noti</span>
          </div>
          <div className="relative flex-1 overflow-hidden whitespace-nowrap">
            <div className="animate-marquee-slow text-xs text-slate-200 font-medium">
              {announcement || 'Welcome to NM 2D Official • Live Thai Stock 2D & 3D System • 12:01 PM & 04:30 PM Sections • 3D 500x Multiplier • Fast Automated Settlement'}
            </div>
          </div>
        </div>

        {/* Big Live Number Card */}
        <div className="relative w-full rounded-3xl p-0.5 bg-gradient-to-b from-cyan-400/40 via-slate-800 to-blue-600/30 shadow-2xl shadow-black/80">
          <div className="w-full rounded-[22px] bg-gradient-to-b from-[#0e172a] to-[#070b16] p-4 text-center">
            
            {/* Market Status Pill */}
            <div className="flex items-center justify-center gap-2 mb-1">
              {weekend ? (
                <span className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/15 border border-rose-500/30 text-rose-300 uppercase tracking-widest">
                  <ShieldAlert className="w-3 h-3 text-rose-400" />
                  Market Closed on Weekend
                </span>
              ) : marketOpen ? (
                <span className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 uppercase tracking-widest">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                  Live Thai Stock
                </span>
              ) : (
                <span className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/15 border border-amber-500/30 text-amber-300 uppercase tracking-widest">
                  <Clock className="w-3 h-3 text-amber-400" />
                  Market Session Resting
                </span>
              )}
            </div>

            {/* GIANT LIVE 2D NUMBER */}
            <div className="py-1">
              <motion.div
                key={liveTwod}
                initial={{ scale: 0.95, opacity: 0.8 }}
                animate={{ scale: 1, opacity: 1 }}
                className="text-7xl font-black font-mono-numbers tracking-tight text-transparent bg-clip-text bg-gradient-to-b from-white via-cyan-200 to-cyan-400 drop-shadow-[0_10px_20px_rgba(0,210,255,0.3)]"
              >
                {liveTwod}
              </motion.div>
            </div>

            {/* Live Date & Myanmar Time */}
            <div className="mt-1 flex items-center justify-center gap-2 text-xs text-slate-300 font-mono-numbers">
              <Clock className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
              <span>{mmtDate}</span>
              <span className="text-slate-600">•</span>
              <span className="text-cyan-300 font-bold">{mmtTime} (MMT)</span>
            </div>

            {/* SET & VALUE SECTION */}
            <div className="mt-4 pt-3 border-t border-slate-800/80 grid grid-cols-2 divide-x divide-slate-800/80 bg-[#060b17]/80 rounded-2xl p-2.5">
              <div className="text-center px-2">
                <div className="text-[10px] uppercase font-bold tracking-wider text-slate-400 mb-0.5">
                  Set
                </div>
                <div className="text-base font-extrabold text-white font-mono-numbers tracking-tight">
                  {liveSet}
                </div>
              </div>

              <div className="text-center px-2">
                <div className="text-[10px] uppercase font-bold tracking-wider text-slate-400 mb-0.5">
                  Value
                </div>
                <div className="text-base font-extrabold text-white font-mono-numbers tracking-tight">
                  {liveVal}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 12:01 & 4:30 SECTION RESULT DISPLAY (NON-CLICKABLE AS REQUESTED) */}
        <div className="w-full grid grid-cols-2 gap-3">
          {/* 12:01 Section Result Card */}
          <div className="p-3.5 rounded-2xl bg-gradient-to-b from-[#0f172a] to-[#090f1d] border border-cyan-500/20 shadow-lg">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-xs font-bold text-cyan-400">
                12:01 PM
              </span>
              <span className="text-[9px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 font-mono-numbers font-semibold">
                Morning
              </span>
            </div>
            <div className="flex items-baseline justify-between mt-1">
              <span className="text-[10px] text-slate-400 uppercase tracking-wide">Result</span>
              <span className="text-3xl font-black font-mono-numbers text-white tracking-wider">
                {res1201}
              </span>
            </div>
            <div className="mt-2 text-[10px] text-slate-500 font-mono-numbers">
              {res1201 !== '--' ? 'Official Settled' : 'Waiting Result'}
            </div>
          </div>

          {/* 4:30 Section Result Card */}
          <div className="p-3.5 rounded-2xl bg-gradient-to-b from-[#0f172a] to-[#090f1d] border border-blue-500/20 shadow-lg">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-xs font-bold text-blue-400">
                4:30 PM
              </span>
              <span className="text-[9px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 font-mono-numbers font-semibold">
                Evening
              </span>
            </div>
            <div className="flex items-baseline justify-between mt-1">
              <span className="text-[10px] text-slate-400 uppercase tracking-wide">Result</span>
              <span className="text-3xl font-black font-mono-numbers text-white tracking-wider">
                {res1630}
              </span>
            </div>
            <div className="mt-2 text-[10px] text-slate-500 font-mono-numbers">
              {res1630 !== '--' ? 'Official Settled' : 'Waiting Result'}
            </div>
          </div>
        </div>

        {/* Weekend / Market Closed Note if active */}
        {weekend && (
          <div className="w-full p-2.5 rounded-xl bg-slate-900/90 border border-slate-800 text-center text-xs text-slate-400">
            Stock exchange closed today. 2D resumes Monday morning.
          </div>
        )}
      </main>
    </div>
  );
}
