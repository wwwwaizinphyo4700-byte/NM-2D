import { useState, useEffect, useMemo } from 'react';
import { History, ArrowLeft, CheckCircle2, RotateCw, Trash2, X, RefreshCw, ShieldAlert } from 'lucide-react';
import { User, Bet3D, AppSettings } from '../types.ts';
import { formatMyanmarDate, generate3DPermutations } from '../utils/myanmarTime.ts';
import { playTouchSound } from '../utils/audio.ts';

interface Bet3DScreenProps {
  user: User;
  settings: AppSettings;
  onRefreshUserData: () => void;
  onBackToHome: () => void;
}

export default function Bet3DScreen({
  user,
  settings,
  onRefreshUserData,
  onBackToHome,
}: Bet3DScreenProps) {
  const [viewState, setViewState] = useState<'bet' | 'history'>('bet');

  // Bet inputs (f)
  const [amount, setAmount] = useState<string>('1000');
  const [inputDigits, setInputDigits] = useState<string>('');
  const [betList, setBetList] = useState<string[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // History state
  const [historyList, setHistoryList] = useState<Bet3D[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);

  // 3D Limits and usage tracking
  const [usage3D, setUsage3D] = useState<Record<string, number>>({});

  const todayDate = formatMyanmarDate();
  const mult3D = settings.multiplier3D || 500;
  const is3DOpen = settings.betting3D_enabled !== false;
  const closed3D = useMemo(() => settings.closedNumbers3D || [], [settings.closedNumbers3D]);
  const limit3D = settings.limit3D || 50000;

  // Winning result for current draw: entered by admin, otherwise '----'
  const officialResult = settings.official3DResults?.[todayDate] || settings.manual3DResult || '----';

  // Fetch 3D bet usage for live heatmap
  const fetch3DUsage = async () => {
    try {
      const res = await fetch(`/api/bets/usage?type=3d&date=${todayDate}`);
      if (res.ok) {
        const data = await res.json();
        setUsage3D(data.usage || {});
      }
    } catch (e) {}
  };

  useEffect(() => {
    fetch3DUsage();
    const interval = setInterval(fetch3DUsage, 4000);
    return () => clearInterval(interval);
  }, []);

  // Fetch 3D bet history
  const fetch3DHistory = async () => {
    setHistoryLoading(true);
    try {
      const res = await fetch(`/api/bets?userId=${user.id}&type=3d&date=${todayDate}`);
      if (res.ok) {
        const data = await res.json();
        setHistoryList(data.bets3D || []);
      }
    } catch (e) {
      console.error('Failed to fetch 3D history:', e);
    } finally {
      setHistoryLoading(false);
    }
  };

  useEffect(() => {
    if (viewState === 'history') {
      fetch3DHistory();
    }
  }, [viewState]);

  // Handle [R] Reverse / Permutations
  const handleReverseClick = () => {
    const trimmed = inputDigits.trim();
    if (trimmed.length !== 3) {
      setErrorMsg('Please enter a 3-digit number before pressing [R]');
      return;
    }

    const perms = generate3DPermutations(trimmed);
    const set = new Set([...betList, ...perms]);
    setBetList(Array.from(set));
    setInputDigits('');
    setErrorMsg(null);
  };

  // Add single direct number
  const handleAddDirect = () => {
    const trimmed = inputDigits.trim();
    if (trimmed.length !== 3) {
      setErrorMsg('Please enter exactly 3 digits (e.g., 112)');
      return;
    }
    if (!betList.includes(trimmed)) {
      setBetList([...betList, trimmed]);
    }
    setInputDigits('');
    setErrorMsg(null);
  };

  const handleRemoveNumber = (numToRemove: string) => {
    setBetList(betList.filter((n) => n !== numToRemove));
  };

  // Confirm and Place 3D Bet
  const handleConfirm3D = async () => {
    let finalNumbers = [...betList];
    if (inputDigits.trim().length === 3 && !finalNumbers.includes(inputDigits.trim())) {
      finalNumbers.push(inputDigits.trim());
    }

    if (finalNumbers.length === 0) {
      setErrorMsg('Please enter or select at least one 3D number');
      return;
    }

    if (!is3DOpen) {
      setErrorMsg('3D Betting is currently CLOSED by Admin');
      return;
    }

    const closedHits = finalNumbers.filter((n) => closed3D.includes(n));
    if (closedHits.length > 0) {
      setErrorMsg(`Cannot place bet: Numbers [${closedHits.join(', ')}] are CLOSED by Admin`);
      return;
    }

    const betAmt = Number(amount);
    if (isNaN(betAmt) || betAmt <= 0) {
      setErrorMsg('Please enter a valid amount');
      return;
    }

    const overLimitHits = finalNumbers.filter((n) => {
      const current = usage3D[n] || 0;
      return (current + betAmt) > limit3D;
    });
    if (overLimitHits.length > 0) {
      setErrorMsg(`Bet amount exceeds 3D limit of ${limit3D.toLocaleString()} MMK for numbers [${overLimitHits.join(', ')}]`);
      return;
    }

    const totalRequired = betAmt * finalNumbers.length;
    if (totalRequired > user.balance) {
      setErrorMsg(`Insufficient balance. Required: ${totalRequired.toLocaleString()} MMK`);
      return;
    }

    setSubmitting(true);
    setErrorMsg(null);

    const betsPayload = finalNumbers.map((num) => ({
      number: num,
      amount: betAmt,
    }));

    try {
      const res = await fetch('/api/bets/3d', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          bets: betsPayload,
        }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        setSubmitSuccess(true);
        onRefreshUserData();
        setTimeout(() => {
          setSubmitSuccess(false);
          setBetList([]);
          setInputDigits('');
          setViewState('history');
        }, 1100);
      } else {
        setErrorMsg(data.message || 'Failed to place 3D bet');
      }
    } catch (e) {
      setErrorMsg('Network error while placing 3D bet');
    } finally {
      setSubmitting(false);
    }
  };

  // 3D History totals calculation
  const historyTotals = useMemo(() => {
    let totalBet = 0;
    let winLose = 0;
    let commission = 0;

    historyList.forEach((b) => {
      totalBet += b.amount;
      if (b.status === 'win') {
        winLose += (b.winAmount - b.amount);
      } else if (b.status === 'lose') {
        winLose -= b.amount;
      }
      commission += b.commission;
    });

    const net = winLose + commission;
    return { totalBet, winLose, commission, net };
  }, [historyList]);

  // --------------------------------------------------------------------------
  // VIEW: 3D HISTORY SCREEN
  // --------------------------------------------------------------------------
  if (viewState === 'history') {
    return (
      <div className="flex flex-col justify-between h-full w-full max-w-lg md:max-w-xl mx-auto bg-[#080d1a] text-slate-100 overflow-hidden select-none">
        {/* FIXED (f) TOP HEADER */}
        <header className="shrink-0 p-3 bg-[#0a1122] border-b border-slate-800 flex items-center justify-between z-10">
          <button
            onClick={() => setViewState('bet')}
            className="flex items-center gap-1.5 text-xs font-semibold text-slate-300 hover:text-white px-2 py-1.5 rounded-lg bg-slate-800/80 active:scale-95 transition-all cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4 text-cyan-400" />
            <span>Back to 3D Bet</span>
          </button>
          <div className="text-center">
            <h2 className="text-sm font-black text-white uppercase tracking-wider">3D Bet History</h2>
            <div className="text-[10px] text-cyan-400 font-mono-numbers">{todayDate}</div>
          </div>
          <button
            onClick={fetch3DHistory}
            className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-cyan-400 cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${historyLoading ? 'animate-spin' : ''}`} />
          </button>
        </header>

        {/* FIXED (f) DATE & RESULT BAR */}
        <div className="shrink-0 px-3 py-2.5 bg-[#0e1628] border-b border-slate-800/80 grid grid-cols-2 gap-2 text-center">
          <div className="p-2.5 rounded-xl bg-[#060b17] border border-cyan-500/20">
            <span className="text-[10px] uppercase font-bold text-slate-400">Date</span>
            <div className="text-sm font-bold font-mono-numbers text-white mt-1">
              {todayDate}
            </div>
          </div>
          <div className="p-2.5 rounded-xl bg-[#060b17] border border-cyan-500/20">
            <span className="text-[10px] uppercase font-bold text-slate-400">Result</span>
            <div className="text-xl font-black font-mono-numbers text-cyan-300 mt-1">
              {officialResult}
            </div>
          </div>
        </div>

        {/* SCROLLABLE (s) 3D BETS LIST */}
        <div className="flex-1 overflow-y-auto custom-scrollbar p-3 space-y-2">
          {historyLoading ? (
            <div className="flex flex-col items-center justify-center py-16 text-slate-500 text-xs">
              <RefreshCw className="w-5 h-5 animate-spin mb-2 text-cyan-400" />
              <span>Loading 3D bets...</span>
            </div>
          ) : historyList.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-slate-500 text-xs text-center">
              <History className="w-8 h-8 text-slate-600 mb-2" />
              <p>No 3D bets recorded for today yet.</p>
            </div>
          ) : (
            historyList.map((bet) => (
              <div
                key={bet.id}
                className="p-2.5 rounded-xl bg-[#0d1629] border border-slate-800/80 flex items-center justify-between text-xs font-mono-numbers"
              >
                <div className="flex items-center gap-3">
                  <div className="w-12 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-lg font-black text-cyan-300 tracking-wider">
                    {bet.number}
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-slate-800 text-slate-300">
                        3D Bet
                      </span>
                      <span className="text-[10px] text-slate-400">{bet.multiplier || 500}x</span>
                    </div>
                    <div className="text-[10px] text-slate-400 mt-0.5">
                      {bet.date} • {bet.time}
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  <div className="font-bold text-white">
                    {bet.amount.toLocaleString()} MMK
                  </div>
                  <div className="text-[11px] font-bold mt-0.5">
                    {bet.status === 'win' && (
                      <span className="text-emerald-400">+{bet.winAmount.toLocaleString()} Win</span>
                    )}
                    {bet.status === 'lose' && (
                      <span className="text-rose-400">-{bet.amount.toLocaleString()} Lose</span>
                    )}
                    {bet.status === 'pending' && (
                      <span className="text-amber-400/80 font-normal">Pending</span>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* FIXED (f) FINANCIAL TOTAL FOOTER */}
        <footer className="shrink-0 p-3 bg-[#0a1122] border-t border-slate-800/90 shadow-2xl">
          <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs font-mono-numbers">
            <div className="flex items-center justify-between text-slate-400">
              <span>Total Bet:</span>
              <span className="text-white font-bold">{historyTotals.totalBet.toLocaleString()} MMK</span>
            </div>
            <div className="flex items-center justify-between text-slate-400">
              <span>Win/Lose:</span>
              <span className={`font-bold ${historyTotals.winLose >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                {historyTotals.winLose > 0 ? `+${historyTotals.winLose.toLocaleString()}` : historyTotals.winLose.toLocaleString()} MMK
              </span>
            </div>
            <div className="flex items-center justify-between text-slate-400">
              <span>Commission:</span>
              <span className="text-cyan-400 font-bold">+{historyTotals.commission.toLocaleString()} MMK</span>
            </div>
            <div className="flex items-center justify-between font-bold border-t border-slate-700/60 pt-1">
              <span className="text-cyan-300">Net Total:</span>
              <span className={`text-sm ${historyTotals.net >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                {historyTotals.net > 0 ? `+${historyTotals.net.toLocaleString()}` : historyTotals.net.toLocaleString()} MMK
              </span>
            </div>
          </div>
        </footer>
      </div>
    );
  }

  // --------------------------------------------------------------------------
  // VIEW: 3D BETTING SCREEN (Default)
  // --------------------------------------------------------------------------
  const currentTotal = (Number(amount) || 0) * (betList.length + (inputDigits.trim().length === 3 && !betList.includes(inputDigits.trim()) ? 1 : 0));

  return (
    <div className="flex flex-col justify-between h-full w-full max-w-lg md:max-w-xl mx-auto bg-[#080d1a] text-slate-100 overflow-hidden select-none">
      {/* FIXED (f) TOP HEADER: Back & History */}
      <header className="shrink-0 p-3 bg-[#0a1122] border-b border-slate-800 flex items-center justify-between z-10">
        <div className="flex items-center gap-2">
          <button
            onClick={onBackToHome}
            className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div className="flex items-center gap-1.5">
            <span className="px-2 py-0.5 rounded bg-cyan-400 text-black text-xs font-black">3D</span>
            <span className="text-sm font-bold text-white tracking-wide">3D Bet Section</span>
          </div>
        </div>

        {/* History Button (f) */}
        <button
          onClick={() => setViewState('history')}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-cyan-500/15 to-blue-500/15 border border-cyan-500/30 text-cyan-300 text-xs font-bold hover:bg-cyan-500/25 active:scale-95 transition-all cursor-pointer"
        >
          <History className="w-3.5 h-3.5 text-cyan-400" />
          <span>History</span>
        </button>
      </header>

      {/* FIXED (f) AMOUNT & CLOSE TIME ROW */}
      <div className="shrink-0 p-3 bg-[#0d1628] border-b border-slate-800/80 space-y-2 z-10">
        <div className="grid grid-cols-2 gap-3 items-center">
          {/* Amount (---) (f) */}
          <div>
            <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">
              Amount (MMK)
            </label>
            <input
              type="number"
              min="100"
              step="100"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="1000"
              className="w-full px-3 py-2 bg-[#060b17] border border-slate-700 rounded-xl text-white font-mono-numbers text-sm font-bold focus:outline-none focus:border-cyan-400"
            />
          </div>

          {/* Close Time & On/Off Status */}
          <div>
            <div className="flex items-center justify-between text-[10px] uppercase font-bold text-slate-400 mb-1">
              <span>Close Time</span>
              <span className={`px-1.5 py-0.5 rounded text-[9px] font-black uppercase tracking-wider ${
                is3DOpen ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40' : 'bg-rose-500/25 text-rose-300 border border-rose-500/50'
              }`}>
                {is3DOpen ? 'OPEN' : 'CLOSED'}
              </span>
            </div>
            <div className={`flex items-center justify-center px-3 py-2 border rounded-xl text-sm font-mono-numbers font-bold ${
              !is3DOpen ? 'bg-rose-950/30 border-rose-500/60 text-rose-300' : 'bg-[#060b17] border-slate-700/80 text-white'
            }`}>
              {settings.closeTime3D || '02:30 PM'}
            </div>
          </div>
        </div>

        {/* Closed by Admin Alert Banner */}
        {!is3DOpen && (
          <div className="p-2 rounded-xl bg-rose-600/20 border border-rose-500/50 text-rose-300 text-xs font-bold flex items-center justify-center gap-2 animate-pulse">
            <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0" />
            <span>3D Betting is currently CLOSED by Admin</span>
          </div>
        )}

        {/* Quick Amount presets */}
        <div className="flex items-center justify-between gap-2 overflow-x-auto pb-0.5 custom-scrollbar">
          <div className="flex items-center gap-1.5 shrink-0">
            {['500', '1000', '2000', '5000', '10000'].map((val) => (
              <button
                key={val}
                disabled={!is3DOpen}
                onClick={() => setAmount(val)}
                className={`px-2.5 py-0.5 rounded-lg text-[10px] font-mono-numbers font-semibold border cursor-pointer disabled:opacity-40 ${
                  amount === val
                    ? 'bg-cyan-400 text-black border-cyan-400 font-bold'
                    : 'bg-slate-800/80 text-slate-300 border-slate-700 hover:border-slate-500'
                }`}
              >
                {parseInt(val).toLocaleString()}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-1.5 shrink-0 text-[10px] font-mono-numbers">
            <span className="px-2 py-0.5 rounded-md bg-amber-500/15 border border-amber-500/30 text-amber-300 font-bold">
              {settings.multiplier3D || 500}x
            </span>
            <span className="px-2 py-0.5 rounded-md bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 font-bold">
              {Math.round((settings.commissionRate3D || 0.10) * 100)}% Com
            </span>
          </div>
        </div>
      </div>

      {/* FIXED (f) NUMBER INPUT & [ R ] REVERSE BUTTON */}
      <div className="shrink-0 p-3 bg-[#0a1122] border-b border-slate-800/80 z-10">
        <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1.5">
          Enter 3D Number [000 - 999] & [R] Reverse
        </label>
        <div className="flex items-center gap-2">
          {/* 3D Digit Input [------] */}
          <div className="relative flex-1">
            <input
              type="text"
              maxLength={3}
              pattern="[0-9]*"
              inputMode="numeric"
              disabled={!is3DOpen}
              value={inputDigits}
              onChange={(e) => {
                const val = e.target.value.replace(/[^0-9]/g, '').slice(0, 3);
                setInputDigits(val);
                setErrorMsg(null);
              }}
              placeholder="e.g. 112"
              className="w-full px-3 py-2.5 bg-[#060b17] border border-slate-700 focus:border-cyan-400 rounded-xl text-white font-mono-numbers text-lg font-black tracking-widest text-center disabled:opacity-40"
            />
          </div>

          {/* [ R ] Reverse button */}
          <button
            type="button"
            onClick={handleReverseClick}
            disabled={!is3DOpen || inputDigits.trim().length !== 3}
            title="Generate Permutations (R)"
            className="px-4 py-2.5 bg-gradient-to-r from-cyan-400 to-blue-500 text-black font-extrabold text-sm rounded-xl shadow-md shadow-cyan-500/20 active:scale-95 transition-all flex items-center gap-1 cursor-pointer disabled:opacity-40"
          >
            <RotateCw className="w-3.5 h-3.5" />
            <span>[ R ]</span>
          </button>

          {/* Add Direct Button */}
          <button
            type="button"
            onClick={handleAddDirect}
            disabled={!is3DOpen || inputDigits.trim().length !== 3}
            className="px-3.5 py-2.5 bg-blue-600 text-white font-extrabold text-xs rounded-xl shadow-md active:scale-95 transition-all cursor-pointer disabled:opacity-40"
          >
            Add
          </button>
        </div>

        <div className="mt-1.5 text-[10px] text-slate-400 flex items-center justify-between">
          <span>Tip: 112 + [R] generates 112, 211, 121</span>
          <span className="text-cyan-400 font-bold">{mult3D}x Multiplier</span>
        </div>
      </div>

      {/* ERROR MESSAGE DISPLAY */}
      {errorMsg && (
        <div className="shrink-0 mx-3 mt-2 p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
          {errorMsg}
        </div>
      )}

      {/* MIDDLE: SLIP NUMBERS LIST */}
      <div className="flex-1 overflow-y-auto custom-scrollbar p-3 space-y-2">
        <div className="flex items-center justify-between text-xs font-mono-numbers px-1 text-slate-400">
          <span>Active 3D Slip ({betList.length} numbers)</span>
          {betList.length > 0 && (
            <button
              onClick={() => setBetList([])}
              className="text-rose-400 hover:text-rose-300 text-[11px] flex items-center gap-1 cursor-pointer"
            >
              <Trash2 className="w-3 h-3" />
              <span>Clear Slip</span>
            </button>
          )}
        </div>

        {betList.length === 0 ? (
          <div className="py-12 text-center text-slate-500 text-xs flex flex-col items-center">
            <span className="w-12 h-12 rounded-2xl bg-slate-800/40 border border-slate-700/50 flex items-center justify-center text-slate-400 font-mono-numbers font-bold text-lg mb-2">
              3D
            </span>
            <p>Enter 3 digits above and press [R] or Add to build your bet slip.</p>
          </div>
        ) : (
          <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
            {betList.map((num) => {
              const isClosed = closed3D.includes(num);
              const currentBet = usage3D[num] || 0;
              const ratio = Math.min(1, currentBet / limit3D);
              const isFull = ratio >= 1;

              let chipStyle: React.CSSProperties = {};
              if (isClosed || isFull) {
                chipStyle = {
                  backgroundColor: 'rgba(225, 29, 72, 0.95)',
                  borderColor: '#f43f5e',
                  color: '#ffffff',
                };
              } else if (ratio > 0) {
                const alphaBg = Math.min(0.85, 0.18 + ratio * 0.70);
                const alphaBorder = Math.min(0.95, 0.30 + ratio * 0.65);
                chipStyle = {
                  backgroundColor: `rgba(225, 29, 72, ${alphaBg})`,
                  borderColor: `rgba(244, 63, 94, ${alphaBorder})`,
                  color: '#ffffff',
                };
              }

              return (
                <div
                  key={num}
                  style={chipStyle}
                  className={`p-2 rounded-xl border flex items-center justify-between font-mono-numbers text-sm font-black transition-all ${
                    isClosed || isFull
                      ? 'shadow-md shadow-rose-950/60'
                      : ratio > 0
                      ? 'shadow-sm'
                      : 'bg-[#0e1628] border-cyan-500/30 text-cyan-300'
                  }`}
                >
                  <div className="flex flex-col">
                    <span>{num}</span>
                    {isClosed ? (
                      <span className="text-[8px] font-black uppercase text-white tracking-wider">CLOSED</span>
                    ) : isFull ? (
                      <span className="text-[8px] font-black uppercase text-white tracking-wider">FULL</span>
                    ) : ratio > 0 ? (
                      <span className="text-[8px] font-bold text-rose-200">{Math.round(ratio * 100)}%</span>
                    ) : null}
                  </div>
                  <button
                    onClick={() => handleRemoveNumber(num)}
                    className="p-1 text-slate-400 hover:text-white cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* FIXED (f) CONFIRM FOOTER */}
      <footer className="shrink-0 p-3 bg-[#0a1122] border-t border-slate-800 space-y-2.5 z-10">
        <div className="flex items-center justify-between text-xs font-mono-numbers px-1">
          <span className="text-slate-400">Total Investment:</span>
          <span className="text-base font-extrabold text-cyan-300">
            {currentTotal.toLocaleString()} MMK
          </span>
        </div>

        <div className="flex items-center justify-between text-[11px] text-slate-400 px-1">
          <span>Available Balance:</span>
          <span className="font-mono-numbers text-slate-200">
            {user.balance.toLocaleString()} MMK
          </span>
        </div>

        <button
          onClick={handleConfirm3D}
          disabled={!is3DOpen || submitting || (betList.length === 0 && inputDigits.trim().length !== 3)}
          className="w-full py-3.5 px-4 bg-gradient-to-r from-cyan-400 via-blue-500 to-blue-600 hover:from-cyan-300 hover:to-blue-500 text-black font-extrabold rounded-xl shadow-lg shadow-cyan-500/25 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-40 text-sm"
        >
          {submitting ? (
            <div className="w-5 h-5 border-2 border-black border-t-transparent rounded-full animate-spin" />
          ) : submitSuccess ? (
            <>
              <CheckCircle2 className="w-5 h-5 text-emerald-950" />
              <span>Successful ✓</span>
            </>
          ) : (
            <span>Confirm 3D Bet</span>
          )}
        </button>
      </footer>
    </div>
  );
}
