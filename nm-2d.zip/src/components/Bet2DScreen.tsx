import { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  History, ArrowLeft, CheckCircle2, AlertTriangle, 
  Trash2, X, RefreshCw, Lock, ShieldAlert
} from 'lucide-react';
import { User, Bet2D, AppSettings, LiveMarketData } from '../types.ts';
import { 
  formatMyanmarDate, 
  getSectionCloseStatus, 
  isMarketWeekend 
} from '../utils/myanmarTime.ts';
import { playTouchSound } from '../utils/audio.ts';

interface Bet2DScreenProps {
  user: User;
  initialSection?: '12:01 PM' | '04:30 PM';
  settings: AppSettings;
  liveData: LiveMarketData | null;
  onRefreshUserData: () => void;
  onBackToHome: () => void;
}

export default function Bet2DScreen({
  user,
  initialSection = '12:01 PM',
  settings,
  liveData,
  onRefreshUserData,
  onBackToHome,
}: Bet2DScreenProps) {
  const [section, setSection] = useState<'12:01 PM' | '04:30 PM'>(initialSection);
  const [viewState, setViewState] = useState<'betting' | 'review' | 'history'>('betting');
  
  // Betting inputs
  const [amount, setAmount] = useState<string>('1000');
  const [selectedNumbers, setSelectedNumbers] = useState<Set<string>>(new Set());
  const [submitting, setSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [closedNumberError, setClosedNumberError] = useState<string[] | null>(null);
  const [generalError, setGeneralError] = useState<string | null>(null);

  // History state
  const [historyList, setHistoryList] = useState<Bet2D[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);

  // Number usage / limit tracking for live heatmap coloring
  const [numberUsage, setNumberUsage] = useState<Record<string, number>>({});

  const weekend = isMarketWeekend();
  // Close time status for current section
  const closeStatus = useMemo(() => getSectionCloseStatus(section), [section]);

  // Closed numbers for current section
  const activeClosedNumbers = useMemo(() => {
    return section === '12:01 PM' 
      ? settings.closedNumbers2D_1201 
      : settings.closedNumbers2D_1630;
  }, [section, settings]);

  // Fetch number usage for limit heatmap
  const fetchUsage = async () => {
    try {
      const todayDate = formatMyanmarDate();
      const res = await fetch(`/api/bets/usage?date=${todayDate}&section=${section}`);
      if (res.ok) {
        const data = await res.json();
        setNumberUsage(data.usage || {});
      }
    } catch (e) {
      // Ignore
    }
  };

  useEffect(() => {
    fetchUsage();
    const interval = setInterval(fetchUsage, 4000);
    return () => clearInterval(interval);
  }, [section]);

  // Fetch user's 2D bet history from server
  const fetchHistory = async () => {
    setHistoryLoading(true);
    try {
      const todayDate = formatMyanmarDate();
      const res = await fetch(`/api/bets?userId=${user.id}&type=2d&date=${todayDate}`);
      if (res.ok) {
        const data = await res.json();
        setHistoryList(data.bets2D || []);
      }
    } catch (e) {
      console.error('Failed to fetch history:', e);
    } finally {
      setHistoryLoading(false);
    }
  };

  useEffect(() => {
    if (viewState === 'history') {
      fetchHistory();
    }
  }, [viewState, section]);

  // Number selection toggle
  const toggleNumber = (numStr: string) => {
    if (closeStatus.isClosed) return; // Strict lockout when closed!
    const updated = new Set(selectedNumbers);
    if (updated.has(numStr)) {
      updated.delete(numStr);
    } else {
      updated.add(numStr);
    }
    setSelectedNumbers(updated);
    setClosedNumberError(null);
  };

  // Quick selection helpers
  const selectQuick = (type: string) => {
    if (closeStatus.isClosed) return;
    const next = new Set<string>();
    for (let i = 0; i < 100; i++) {
      const s = i.toString().padStart(2, '0');
      const d1 = parseInt(s[0], 10);
      const d2 = parseInt(s[1], 10);

      if (type === 'all') next.add(s);
      else if (type === 'even' && i % 2 === 0) next.add(s);
      else if (type === 'odd' && i % 2 !== 0) next.add(s);
      else if (type === 'double' && d1 === d2) next.add(s);
      else if (type === 'small' && i < 50) next.add(s);
      else if (type === 'big' && i >= 50) next.add(s);
    }
    setSelectedNumbers(next);
    setClosedNumberError(null);
  };

  const clearSelection = () => {
    if (closeStatus.isClosed) return;
    setSelectedNumbers(new Set());
    setClosedNumberError(null);
  };

  // Review step
  const handleProceedToReview = () => {
    if (closeStatus.isClosed) {
      setGeneralError(`This section is CLOSED (${closeStatus.closeTimeLabel})`);
      return;
    }
    if (selectedNumbers.size === 0) {
      setGeneralError('Please select at least one number');
      return;
    }
    const betAmt = Number(amount);
    if (isNaN(betAmt) || betAmt <= 0) {
      setGeneralError('Please enter a valid bet amount');
      return;
    }
    const totalRequired = betAmt * selectedNumbers.size;
    if (totalRequired > user.balance) {
      setGeneralError(`Insufficient balance. Required: ${totalRequired.toLocaleString()} MMK`);
      return;
    }

    setGeneralError(null);
    setViewState('review');
  };

  // Confirm and Place Bets
  const handleConfirmBets = async () => {
    if (closeStatus.isClosed) {
      setGeneralError(`This section is CLOSED (${closeStatus.closeTimeLabel})`);
      return;
    }

    setSubmitting(true);
    setGeneralError(null);
    setClosedNumberError(null);

    const betAmt = Number(amount) || 1000;
    const betsPayload = Array.from(selectedNumbers).map((num) => ({
      number: num,
      amount: betAmt,
    }));

    try {
      const res = await fetch('/api/bets/2d', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          section,
          bets: betsPayload,
        }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        setSubmitSuccess(true);
        onRefreshUserData();
        setTimeout(() => {
          setSubmitSuccess(false);
          setSelectedNumbers(new Set());
          setViewState('history');
        }, 1100);
      } else {
        if (data.blockedNumbers && data.blockedNumbers.length > 0) {
          setClosedNumberError(data.blockedNumbers);
        } else {
          setGeneralError(data.message || 'Failed to place bets');
        }
      }
    } catch (e) {
      setGeneralError('Network error while placing bet');
    } finally {
      setSubmitting(false);
    }
  };

  // One-click remove blocked numbers
  const removeBlockedNumbers = () => {
    if (!closedNumberError) return;
    const updated = new Set(selectedNumbers);
    closedNumberError.forEach((n) => updated.delete(n));
    setSelectedNumbers(updated);
    setClosedNumberError(null);
    if (updated.size === 0) {
      setViewState('betting');
    }
  };

  // Results for 12:01 and 4:30
  const res1201 = liveData?.result?.find((r) => r.open_time.startsWith('12:01'))?.twod || '--';
  const res1630 = liveData?.result?.find((r) => r.open_time.startsWith('16:30'))?.twod || '--';

  // Calculate history financial totals
  const historyTotals = useMemo(() => {
    let totalBet = 0;
    let winLose = 0;
    let commission = 0;

    historyList.forEach((b) => {
      totalBet += b.amount;
      if (b.status === 'win') {
        winLose += (b.winAmount - b.amount);
      } else if (b.status === 'lose') {
        winLose -= b.amount;
      }
      commission += b.commission;
    });

    const net = winLose + commission;
    return { totalBet, winLose, commission, net };
  }, [historyList]);

  // --------------------------------------------------------------------------
  // VIEW: HISTORY SCREEN
  // --------------------------------------------------------------------------
  if (viewState === 'history') {
    return (
      <div className="flex flex-col justify-between h-full w-full max-w-lg md:max-w-xl mx-auto bg-[#080d1a] text-slate-100 overflow-hidden select-none">
        {/* FIXED (f) TOP HEADER */}
        <header className="shrink-0 p-3 bg-[#0a1122] border-b border-slate-800 flex items-center justify-between z-10">
          <button
            onClick={() => setViewState('betting')}
            className="flex items-center gap-1.5 text-xs font-semibold text-slate-300 hover:text-white px-2 py-1.5 rounded-lg bg-slate-800/80 active:scale-95 transition-all cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4 text-cyan-400" />
            <span>Back to Bet</span>
          </button>
          <div className="text-center">
            <h2 className="text-sm font-black text-white uppercase tracking-wider">2D Bet History</h2>
            <div className="text-[10px] text-cyan-400 font-mono-numbers">{formatMyanmarDate()}</div>
          </div>
          <button
            onClick={fetchHistory}
            className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-cyan-400 cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${historyLoading ? 'animate-spin' : ''}`} />
          </button>
        </header>

        {/* FIXED (f) SECTION RESULTS BAR */}
        <div className="shrink-0 px-3 py-2 bg-[#0e1628] border-b border-slate-800/80 grid grid-cols-2 gap-2 text-center">
          <div className="p-2 rounded-xl bg-[#060b17] border border-cyan-500/20">
            <span className="text-[10px] uppercase font-bold text-slate-400">12:01 Result</span>
            <div className="text-2xl font-black font-mono-numbers text-cyan-400">{res1201}</div>
          </div>
          <div className="p-2 rounded-xl bg-[#060b17] border border-blue-500/20">
            <span className="text-[10px] uppercase font-bold text-slate-400">4:30 Result</span>
            <div className="text-2xl font-black font-mono-numbers text-blue-400">{res1630}</div>
          </div>
        </div>

        {/* SCROLLABLE (s) BETS LIST */}
        <div className="flex-1 overflow-y-auto custom-scrollbar p-3 space-y-2">
          {historyLoading ? (
            <div className="flex flex-col items-center justify-center py-16 text-slate-500 text-xs">
              <RefreshCw className="w-5 h-5 animate-spin mb-2 text-cyan-400" />
              <span>Loading bets...</span>
            </div>
          ) : historyList.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-slate-500 text-xs text-center">
              <History className="w-8 h-8 text-slate-600 mb-2" />
              <p>No 2D bets recorded for today yet.</p>
            </div>
          ) : (
            historyList.map((bet) => (
              <div
                key={bet.id}
                className="p-2.5 rounded-xl bg-[#0d1629] border border-slate-800/80 flex items-center justify-between text-xs font-mono-numbers"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-lg font-black text-cyan-300">
                    {bet.number}
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-slate-800 text-slate-300">
                        {bet.section}
                      </span>
                      <span className="text-[10px] text-slate-400">{bet.multiplier}x</span>
                    </div>
                    <div className="text-[10px] text-slate-400 mt-0.5">
                      {bet.date} • {bet.time}
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  <div className="font-bold text-white">
                    {bet.amount.toLocaleString()} MMK
                  </div>
                  <div className="text-[11px] font-bold mt-0.5">
                    {bet.status === 'win' && (
                      <span className="text-emerald-400">+{bet.winAmount.toLocaleString()} Win</span>
                    )}
                    {bet.status === 'lose' && (
                      <span className="text-rose-400">-{bet.amount.toLocaleString()} Lose</span>
                    )}
                    {bet.status === 'pending' && (
                      <span className="text-amber-400/80 font-normal">Pending</span>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* FIXED (f) FINANCIAL TOTAL FOOTER */}
        <footer className="shrink-0 p-3 bg-[#0a1122] border-t border-slate-800/90 shadow-2xl">
          <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs font-mono-numbers">
            <div className="flex items-center justify-between text-slate-400">
              <span>Total Bet:</span>
              <span className="text-white font-bold">{historyTotals.totalBet.toLocaleString()} MMK</span>
            </div>
            <div className="flex items-center justify-between text-slate-400">
              <span>Win/Lose:</span>
              <span className={`font-bold ${historyTotals.winLose >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                {historyTotals.winLose > 0 ? `+${historyTotals.winLose.toLocaleString()}` : historyTotals.winLose.toLocaleString()} MMK
              </span>
            </div>
            <div className="flex items-center justify-between text-slate-400">
              <span>Commission:</span>
              <span className="text-cyan-400 font-bold">+{historyTotals.commission.toLocaleString()} MMK</span>
            </div>
            <div className="flex items-center justify-between font-bold border-t border-slate-700/60 pt-1">
              <span className="text-cyan-300">Net Total:</span>
              <span className={`text-sm ${historyTotals.net >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                {historyTotals.net > 0 ? `+${historyTotals.net.toLocaleString()}` : historyTotals.net.toLocaleString()} MMK
              </span>
            </div>
          </div>
        </footer>
      </div>
    );
  }

  // --------------------------------------------------------------------------
  // VIEW: REVIEW / CONFIRMATION SCREEN
  // --------------------------------------------------------------------------
  if (viewState === 'review') {
    const betAmt = Number(amount) || 1000;
    const totalRequired = betAmt * selectedNumbers.size;
    const mult = settings.multiplier2D || 80;
    const todayDate = formatMyanmarDate();

    return (
      <div className="flex flex-col justify-between h-full w-full max-w-lg md:max-w-xl mx-auto bg-[#080d1a] text-slate-100 overflow-hidden select-none">
        {/* FIXED (f) HEADER */}
        <header className="shrink-0 p-3 bg-[#0a1122] border-b border-slate-800 flex items-center justify-between z-10">
          <button
            onClick={() => setViewState('betting')}
            disabled={submitting}
            className="flex items-center gap-1.5 text-xs font-semibold text-slate-300 hover:text-white px-2 py-1.5 rounded-lg bg-slate-800/80 active:scale-95 transition-all cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4 text-cyan-400" />
            <span>Edit Numbers</span>
          </button>
          <div className="text-center">
            <h2 className="text-sm font-black text-white uppercase tracking-wider">Confirm 2D Bet</h2>
            <div className="text-[10px] text-cyan-400 font-mono-numbers">{section}</div>
          </div>
          <div className="w-10" />
        </header>

        {/* ADMIN CLOSED NUMBERS WARNING BANNER */}
        <AnimatePresence>
          {closedNumberError && closedNumberError.length > 0 && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="shrink-0 m-3 p-3 rounded-2xl bg-rose-500/15 border border-rose-500/40 text-rose-300 text-xs shadow-lg"
            >
              <div className="flex items-start gap-2">
                <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
                <div className="flex-1">
                  <div className="font-bold text-rose-200">Admin Closed Numbers Detected!</div>
                  <p className="text-[11px] text-rose-300 mt-0.5">
                    The following numbers are closed by Admin for this section:
                  </p>
                  <div className="flex flex-wrap gap-1.5 my-2">
                    {closedNumberError.map((n) => (
                      <span
                        key={n}
                        className="px-2 py-0.5 rounded-md bg-rose-600/30 border border-rose-500 font-bold font-mono-numbers text-rose-100"
                      >
                        {n}
                      </span>
                    ))}
                  </div>
                  <button
                    onClick={removeBlockedNumbers}
                    className="w-full py-2 px-3 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 active:scale-95 transition-all cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Remove Blocked Numbers & Proceed</span>
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* GENERAL ERROR BANNER */}
        {generalError && (
          <div className="shrink-0 m-3 p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
            {generalError}
          </div>
        )}

        {/* SCROLLABLE (s) REVIEW LIST */}
        <div className="flex-1 overflow-y-auto custom-scrollbar p-3 space-y-1.5">
          <div className="text-[11px] uppercase font-bold text-slate-400 px-1 mb-1 flex items-center justify-between">
            <span>Date / Section / Number / Multiplier / Amount</span>
            <span>({selectedNumbers.size} items)</span>
          </div>

          {Array.from(selectedNumbers).map((num) => {
            const isBlocked = activeClosedNumbers.includes(num);
            return (
              <div
                key={num}
                className={`p-2.5 rounded-xl border flex items-center justify-between text-xs font-mono-numbers transition-colors ${
                  isBlocked
                    ? 'bg-rose-950/40 border-rose-500/60 text-rose-300'
                    : 'bg-[#0e1628] border-slate-800 text-slate-200'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-sm ${
                    isBlocked ? 'bg-rose-600 text-white' : 'bg-cyan-500/20 text-cyan-300'
                  }`}>
                    {num}
                  </span>
                  <div>
                    <div className="text-white font-medium">{todayDate} • {section}</div>
                    <div className="text-[10px] text-slate-400">Multiplier: {mult}x</div>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <div className="font-bold text-white">{betAmt.toLocaleString()} MMK</div>
                    {isBlocked && (
                      <span className="text-[10px] font-bold text-rose-400 uppercase">Closed</span>
                    )}
                  </div>
                  <button
                    onClick={() => toggleNumber(num)}
                    className="p-1 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-slate-800 transition-colors"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* FIXED (f) BOTTOM ACTION */}
        <footer className="shrink-0 p-3 bg-[#0a1122] border-t border-slate-800 space-y-2.5">
          <div className="flex items-center justify-between text-xs font-mono-numbers px-1">
            <span className="text-slate-400">Total Investment:</span>
            <span className="text-base font-extrabold text-cyan-300">
              {totalRequired.toLocaleString()} MMK
            </span>
          </div>

          <div className="flex items-center justify-between text-[11px] text-slate-400 px-1">
            <span>Remaining Balance:</span>
            <span className="font-mono-numbers text-slate-200">
              {(user.balance - totalRequired).toLocaleString()} MMK
            </span>
          </div>

          <button
            onClick={handleConfirmBets}
            disabled={submitting || selectedNumbers.size === 0}
            className="w-full py-3.5 px-4 bg-gradient-to-r from-cyan-400 via-blue-500 to-blue-600 hover:from-cyan-300 hover:to-blue-500 text-black font-extrabold rounded-xl shadow-lg shadow-cyan-500/25 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 text-sm"
          >
            {submitting ? (
              <div className="w-5 h-5 border-2 border-black border-t-transparent rounded-full animate-spin" />
            ) : submitSuccess ? (
              <>
                <CheckCircle2 className="w-5 h-5 text-emerald-950" />
                <span>Successful ✓</span>
              </>
            ) : (
              <span>Confirm & Place Bet</span>
            )}
          </button>
        </footer>
      </div>
    );
  }

  // --------------------------------------------------------------------------
  // VIEW: 2D BETTING SCREEN (Default)
  // --------------------------------------------------------------------------
  return (
    <div className="flex flex-col justify-between h-full w-full max-w-lg md:max-w-xl mx-auto bg-[#080d1a] text-slate-100 overflow-hidden select-none relative">
      {/* FIXED (f) TOP HEADER: Section & History */}
      <header className="shrink-0 p-3 bg-[#0a1122] border-b border-slate-800 flex items-center justify-between z-10">
        <div className="flex items-center gap-2">
          <button
            onClick={onBackToHome}
            className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          {/* Section Selector Pills */}
          <div className="flex bg-[#050914] p-0.5 rounded-xl border border-slate-800">
            <button
              onClick={() => {
                setSection('12:01 PM');
                setClosedNumberError(null);
                setGeneralError(null);
              }}
              className={`px-3 py-1 rounded-lg text-xs font-black transition-all cursor-pointer ${
                section === '12:01 PM'
                  ? 'bg-cyan-400 text-black shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              12:01 AM
            </button>
            <button
              onClick={() => {
                setSection('04:30 PM');
                setClosedNumberError(null);
                setGeneralError(null);
              }}
              className={`px-3 py-1 rounded-lg text-xs font-black transition-all cursor-pointer ${
                section === '04:30 PM'
                  ? 'bg-blue-500 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              4:30 PM
            </button>
          </div>
        </div>

        {/* History Button (f) */}
        <button
          onClick={() => setViewState('history')}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-cyan-500/15 to-blue-500/15 border border-cyan-500/30 text-cyan-300 text-xs font-bold hover:bg-cyan-500/25 active:scale-95 transition-all cursor-pointer"
        >
          <History className="w-3.5 h-3.5 text-cyan-400" />
          <span>History</span>
        </button>
      </header>

      {/* STRICT CLOSED OVERLAY / BANNER IF CLOSED */}
      {closeStatus.isClosed ? (
        <div className="shrink-0 p-4 bg-rose-950/40 border-b border-rose-600/40 flex flex-col items-center justify-center text-center space-y-1">
          <div className="flex items-center gap-2 text-rose-400 font-black text-sm uppercase tracking-wider">
            <Lock className="w-4 h-4" />
            <span>SECTION CLOSED ({closeStatus.closeTimeLabel})</span>
          </div>
          <p className="text-[11px] text-rose-300">
            {weekend 
              ? 'Market is closed on weekends (Saturday & Sunday).'
              : section === '12:01 PM'
              ? '12:01 PM section closed at 11:50 AM (10 mins before result).'
              : '4:30 PM section closed at 03:50 PM.'}
          </p>
        </div>
      ) : (
        /* FIXED (f) AMOUNT & CLOSE TIME ROW WHEN OPEN */
        <div className="shrink-0 p-3 bg-[#0d1628] border-b border-slate-800/80 space-y-2 z-10">
          <div className="grid grid-cols-2 gap-3 items-center">
            {/* Amount Input [------] (f) */}
            <div>
              <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">
                Amount (MMK)
              </label>
              <input
                type="number"
                min="100"
                step="100"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="1000"
                className="w-full px-3 py-2 bg-[#060b17] border border-slate-700 rounded-xl text-white font-mono-numbers text-sm font-bold focus:outline-none focus:border-cyan-400"
              />
            </div>

            {/* Close Time Indicator [------] (f) */}
            <div>
              <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">
                Close Time
              </label>
              <div className="flex items-center justify-between px-3 py-2 bg-[#060b17] border border-slate-700/80 rounded-xl text-xs font-mono-numbers">
                <span className="text-white font-bold">{closeStatus.closeTimeLabel}</span>
                <span className="text-[10px] px-1.5 py-0.5 rounded font-bold bg-emerald-500/20 text-emerald-400">
                  {closeStatus.remainingText}
                </span>
              </div>
            </div>
          </div>

          {/* Quick Amount presets and Commission info */}
          <div className="flex items-center justify-between gap-2 overflow-x-auto pb-0.5 custom-scrollbar">
            <div className="flex items-center gap-1.5 shrink-0">
              {['500', '1000', '2000', '5000', '10000', '20000'].map((val) => (
                <button
                  key={val}
                  onClick={() => setAmount(val)}
                  className={`px-2 py-0.5 rounded-lg text-[10px] font-mono-numbers font-semibold border cursor-pointer ${
                    amount === val
                      ? 'bg-cyan-400 text-black border-cyan-400 font-bold'
                      : 'bg-slate-800/80 text-slate-300 border-slate-700 hover:border-slate-500'
                  }`}
                >
                  {parseInt(val).toLocaleString()}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-1.5 shrink-0 text-[10px] font-mono-numbers">
              <span className="px-2 py-0.5 rounded-md bg-cyan-500/15 border border-cyan-500/30 text-cyan-300 font-bold">
                {settings.multiplier2D || 80}x
              </span>
              <span className="px-2 py-0.5 rounded-md bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 font-bold">
                {Math.round((settings.commissionRate2D || 0.12) * 100)}% Com
              </span>
            </div>
          </div>
        </div>
      )}

      {/* SCROLLABLE (s) 00-99 NUMBERS GRID & NEXT (s) */}
      <div className={`flex-1 overflow-y-auto custom-scrollbar p-3 space-y-3 ${closeStatus.isClosed ? 'opacity-40 pointer-events-none' : ''}`}>
        {/* Quick Select Tool Pills */}
        <div className="flex flex-wrap items-center gap-1.5 p-2 rounded-2xl bg-[#0b1222] border border-slate-800 text-[10px] font-bold">
          <button
            onClick={() => selectQuick('all')}
            className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 cursor-pointer"
          >
            All (100)
          </button>
          <button
            onClick={() => selectQuick('odd')}
            className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 cursor-pointer"
          >
            Odd
          </button>
          <button
            onClick={() => selectQuick('even')}
            className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 cursor-pointer"
          >
            Even
          </button>
          <button
            onClick={() => selectQuick('double')}
            className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 cursor-pointer"
          >
            Double
          </button>
          <button
            onClick={() => selectQuick('small')}
            className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 cursor-pointer"
          >
            00-49
          </button>
          <button
            onClick={() => selectQuick('big')}
            className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 cursor-pointer"
          >
            50-99
          </button>
          {selectedNumbers.size > 0 && (
            <button
              onClick={clearSelection}
              className="ml-auto px-2 py-1 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 cursor-pointer"
            >
              Clear
            </button>
          )}
        </div>

        {/* Selection Stats */}
        <div className="flex items-center justify-between px-1 text-xs font-mono-numbers">
          <span className="text-slate-400">
            Selected: <span className="text-cyan-400 font-bold">{selectedNumbers.size}</span> numbers
          </span>
          <span className="text-slate-400">
            Total: <span className="text-cyan-300 font-bold">{((Number(amount) || 0) * selectedNumbers.size).toLocaleString()}</span> MMK
          </span>
        </div>

        {/* 00 - 99 NUMBERS GRID (s) */}
        <div className="grid grid-cols-5 sm:grid-cols-10 gap-1.5">
          {Array.from({ length: 100 }, (_, i) => {
            const numStr = i.toString().padStart(2, '0');
            const isSelected = selectedNumbers.has(numStr);
            const isClosed = activeClosedNumbers.includes(numStr);
            const currentBet = numberUsage[numStr] || 0;
            const limit = settings.limit2D || 10000;
            const ratio = Math.min(1, currentBet / limit);
            const isLimitFull = ratio >= 1;

            // Dynamic heatmap styling: grows deeper red as it nears the limit
            let dynamicStyle: React.CSSProperties = {};
            if (!isSelected && !isClosed && !isLimitFull && ratio > 0) {
              const alphaBg = Math.min(0.85, 0.15 + ratio * 0.70);
              const alphaBorder = Math.min(0.95, 0.30 + ratio * 0.65);
              dynamicStyle = {
                backgroundColor: `rgba(225, 29, 72, ${alphaBg})`,
                borderColor: `rgba(244, 63, 94, ${alphaBorder})`,
              };
            }

            return (
              <button
                key={numStr}
                type="button"
                style={dynamicStyle}
                disabled={closeStatus.isClosed || isClosed || isLimitFull}
                onClick={() => toggleNumber(numStr)}
                title={
                  isClosed
                    ? `${numStr} is CLOSED by Admin`
                    : isLimitFull
                    ? `${numStr} reached limit of ${limit.toLocaleString()} MMK`
                    : currentBet > 0
                    ? `${numStr}: Bet ${currentBet.toLocaleString()} / Limit ${limit.toLocaleString()} MMK (${Math.round(ratio * 100)}%)`
                    : `${numStr}`
                }
                className={`relative aspect-square rounded-xl text-sm font-black font-mono-numbers flex flex-col items-center justify-center transition-all cursor-pointer active:scale-95 ${
                  isSelected
                    ? 'bg-gradient-to-br from-cyan-300 to-blue-500 text-black shadow-md shadow-cyan-500/30 ring-2 ring-cyan-300'
                    : isClosed
                    ? 'bg-rose-600 border border-rose-500 text-white shadow-md shadow-rose-950 font-black'
                    : isLimitFull
                    ? 'bg-rose-600 border border-rose-500 text-white shadow-md shadow-rose-950 font-black'
                    : ratio > 0
                    ? 'text-white border'
                    : 'bg-[#0d1628] border border-slate-800/90 text-slate-200 hover:border-slate-600 hover:bg-slate-800'
                }`}
              >
                <span>{numStr}</span>
                {isClosed ? (
                  <span className="absolute bottom-0.5 text-[7px] font-black text-white/95 uppercase tracking-tighter">
                    CLOSED
                  </span>
                ) : isLimitFull ? (
                  <span className="absolute bottom-0.5 text-[7px] font-black text-white/95 uppercase tracking-tighter">
                    FULL
                  </span>
                ) : ratio > 0 ? (
                  <span className="absolute bottom-0.5 text-[7px] font-extrabold text-rose-200 tracking-tighter">
                    {Math.round(ratio * 100)}%
                  </span>
                ) : null}
              </button>
            );
          })}
        </div>

        {/* General Error notice */}
        {generalError && (
          <div className="p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
            {generalError}
          </div>
        )}

        {/* NEXT BUTTON (s) */}
        <div className="pt-2 pb-4">
          <button
            onClick={handleProceedToReview}
            disabled={closeStatus.isClosed || selectedNumbers.size === 0}
            className="w-full py-3.5 px-4 bg-gradient-to-r from-cyan-400 via-blue-500 to-blue-600 hover:from-cyan-300 hover:to-blue-500 text-black font-extrabold rounded-xl shadow-lg shadow-cyan-500/25 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-40 text-sm"
          >
            <span>Next ({selectedNumbers.size})</span>
          </button>
        </div>
      </div>
    </div>
  );
}
