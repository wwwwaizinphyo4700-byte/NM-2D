interface LogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showSubtitle?: boolean;
}

export default function NM2DLogo({ size = 'md', showSubtitle = false }: LogoProps) {
  const pixelSizes = {
    sm: 36,
    md: 52,
    lg: 84,
    xl: 120,
  };

  const dim = pixelSizes[size] || 52;

  return (
    <div className="flex flex-col items-center justify-center select-none">
      <div 
        style={{ width: dim, height: dim }}
        className="relative flex items-center justify-center drop-shadow-[0_4px_16px_rgba(0,180,255,0.4)]"
      >
        <svg
          viewBox="0 0 200 200"
          className="w-full h-full"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            {/* Outer Glow & Gradients */}
            <radialGradient id="nmBg" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#081021" />
              <stop offset="70%" stopColor="#040711" />
              <stop offset="100%" stopColor="#000000" />
            </radialGradient>

            <linearGradient id="neonRing" x1="0" y1="0" x2="200" y2="200" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#00d2ff" />
              <stop offset="50%" stopColor="#0066ff" />
              <stop offset="100%" stopColor="#00d2ff" />
            </linearGradient>

            <linearGradient id="crownGrad" x1="50" y1="20" x2="150" y2="60" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#00c8ff" />
              <stop offset="50%" stopColor="#0055ff" />
              <stop offset="100%" stopColor="#0099ff" />
            </linearGradient>

            <linearGradient id="nmWhite" x1="50" y1="50" x2="150" y2="120" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#ffffff" />
              <stop offset="60%" stopColor="#e2ecf9" />
              <stop offset="100%" stopColor="#b4c9e8" />
            </linearGradient>

            <linearGradient id="nmBlue" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#0077ff" />
              <stop offset="100%" stopColor="#0044cc" />
            </linearGradient>

            <radialGradient id="blueBall" cx="35%" cy="35%" r="65%">
              <stop offset="0%" stopColor="#66e0ff" />
              <stop offset="40%" stopColor="#0088ff" />
              <stop offset="85%" stopColor="#003399" />
              <stop offset="100%" stopColor="#001a4d" />
            </radialGradient>

            <radialGradient id="redBall" cx="35%" cy="35%" r="65%">
              <stop offset="0%" stopColor="#ff7777" />
              <stop offset="40%" stopColor="#ee1122" />
              <stop offset="85%" stopColor="#990011" />
              <stop offset="100%" stopColor="#4d0008" />
            </radialGradient>

            <filter id="cyanGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="3" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>

          {/* Background circle */}
          <circle cx="100" cy="100" r="94" fill="url(#nmBg)" />

          {/* Outer Neon Blue Ring */}
          <circle
            cx="100"
            cy="100"
            r="92"
            stroke="url(#neonRing)"
            strokeWidth="5"
            filter="url(#cyanGlow)"
          />
          <circle
            cx="100"
            cy="100"
            r="87"
            stroke="#00f0ff"
            strokeWidth="1.2"
            strokeOpacity="0.8"
          />

          {/* CROWN AT TOP */}
          <path
            d="M 68 54 
               L 72 38 
               L 85 46 
               L 100 28 
               L 115 46 
               L 128 38 
               L 132 54 
               Z"
            fill="url(#crownGrad)"
            stroke="#00ffff"
            strokeWidth="1"
          />
          {/* Crown Jewels (small circles on peaks) */}
          <circle cx="72" cy="38" r="2.5" fill="#ffffff" />
          <circle cx="100" cy="28" r="3" fill="#ffffff" />
          <circle cx="128" cy="38" r="2.5" fill="#ffffff" />

          {/* 3D LETTER "N" */}
          {/* Left vertical block */}
          <polygon points="46,56 62,56 62,112 46,112" fill="url(#nmWhite)" />
          {/* Diagonal */}
          <polygon points="62,56 78,56 100,105 100,112 84,112" fill="url(#nmWhite)" />
          {/* 3D Shadow bevel on N */}
          <polygon points="98,56 100,56 100,112 84,112" fill="url(#nmBlue)" />
          <polygon points="62,112 78,112 62,75" fill="#0055dd" />

          {/* 3D LETTER "M" */}
          {/* Left upright */}
          <polygon points="98,56 108,56 108,112 98,112" fill="url(#nmWhite)" />
          {/* Center V cut */}
          <polygon points="108,56 122,56 132,88 124,96" fill="url(#nmWhite)" />
          <polygon points="124,96 132,88 142,56 154,56 136,104" fill="url(#nmBlue)" />
          {/* Right upright */}
          <polygon points="144,56 156,56 156,112 144,112" fill="url(#nmBlue)" />

          {/* "= 2D =" SECTION */}
          {/* Left speed lines */}
          <line x1="42" y1="119" x2="68" y2="119" stroke="#00d2ff" strokeWidth="3" strokeLinecap="round" />
          <line x1="46" y1="125" x2="64" y2="125" stroke="#0099ff" strokeWidth="2" strokeLinecap="round" />

          {/* 2D Text in Center */}
          <text
            x="100"
            y="130"
            textAnchor="middle"
            fontFamily="Arial, Helvetica, sans-serif"
            fontWeight="900"
            fontSize="26"
            fontStyle="italic"
            letterSpacing="-0.5"
            fill="#ffffff"
            stroke="#001833"
            strokeWidth="1"
          >
            2D
          </text>

          {/* Right speed lines */}
          <line x1="132" y1="119" x2="158" y2="119" stroke="#00d2ff" strokeWidth="3" strokeLinecap="round" />
          <line x1="136" y1="125" x2="154" y2="125" stroke="#0099ff" strokeWidth="2" strokeLinecap="round" />

          {/* BOTTOM LOTTERY BALLS: Blue "2" and Red "7" */}
          {/* Blue Ball: "2" */}
          <g>
            <circle cx="85" cy="148" r="17" fill="url(#blueBall)" />
            {/* White label circle */}
            <circle cx="85" cy="148" r="9.5" fill="#ffffff" />
            {/* Number 2 */}
            <text
              x="85"
              y="153"
              textAnchor="middle"
              fontFamily="Arial, Helvetica, sans-serif"
              fontWeight="900"
              fontSize="14"
              fill="#0b172a"
            >
              2
            </text>
          </g>

          {/* Red Ball: "7" */}
          <g>
            <circle cx="117" cy="150" r="17" fill="url(#redBall)" />
            {/* White label circle */}
            <circle cx="117" cy="150" r="9.5" fill="#ffffff" />
            {/* Number 7 */}
            <text
              x="117"
              y="155"
              textAnchor="middle"
              fontFamily="Arial, Helvetica, sans-serif"
              fontWeight="900"
              fontSize="14"
              fill="#0b172a"
            >
              7
            </text>
          </g>

          {/* Bottom Neon Swoosh Ring wrapping balls */}
          <path
            d="M 62 144 C 64 165, 84 178, 100 178 C 118 178, 138 165, 140 146"
            fill="none"
            stroke="#00d2ff"
            strokeWidth="3.5"
            strokeLinecap="round"
          />
        </svg>
      </div>

      {showSubtitle && (
        <div className="mt-2 text-center">
          <h1 className="text-xl font-extrabold tracking-tight text-white flex items-center justify-center gap-1.5">
            <span>NM</span>
            <span className="text-[#00d2ff]">2D</span>
          </h1>
          <p className="text-[10px] text-cyan-400 tracking-widest uppercase font-semibold">
            Official System
          </p>
        </div>
      )}
    </div>
  );
}
