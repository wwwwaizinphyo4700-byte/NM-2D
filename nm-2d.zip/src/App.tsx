import { useState, useEffect } from 'react';
import { Home, Flame, Box, FileText, User as UserIcon, WifiOff, AlertTriangle, RefreshCw, ShieldAlert, Monitor } from 'lucide-react';
import LoginScreen from './components/LoginScreen.tsx';
import HomeScreen from './components/HomeScreen.tsx';
import Bet2DScreen from './components/Bet2DScreen.tsx';
import Bet3DScreen from './components/Bet3DScreen.tsx';
import LedgerScreen from './components/LedgerScreen.tsx';
import ProfileScreen from './components/ProfileScreen.tsx';
import WebAdminPortal from './components/WebAdminPortal.tsx';
import { User, AppSettings, LiveMarketData } from './types.ts';
import { playTouchSound } from './utils/audio.ts';

type Tab = 'home' | '2d' | '3d' | 'ledger' | 'profile';

export default function App() {
  // Mode switcher between User App (Player App) and Web Admin Portal
  // Admin is strictly accessed by navigating to URL /admin or query ?admin=1
  // No visible button or header link is displayed inside the user mobile app
  const [viewMode, setViewMode] = useState<'app' | 'admin'>(() => {
    if (typeof window !== 'undefined') {
      const path = window.location.pathname.toLowerCase();
      const search = window.location.search.toLowerCase();
      if (path === '/admin' || path.startsWith('/admin/') || search.includes('view=admin') || search.includes('admin=1')) {
        return 'admin';
      }
    }
    return 'app';
  });

  // Listen to popstate or url changes for /admin
  useEffect(() => {
    const handleLocationChange = () => {
      const path = window.location.pathname.toLowerCase();
      const search = window.location.search.toLowerCase();
      if (path === '/admin' || path.startsWith('/admin/') || search.includes('view=admin') || search.includes('admin=1')) {
        setViewMode('admin');
      } else {
        setViewMode('app');
      }
    };
    window.addEventListener('popstate', handleLocationChange);
    return () => window.removeEventListener('popstate', handleLocationChange);
  }, []);

  // Offline detector state
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Require Login EVERY TIME app is opened/refreshed (Zero persistent storage auto-login)
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  useEffect(() => {
    // Clear any previous persistent login tokens
    localStorage.removeItem('nm2d_remember_user');
    sessionStorage.removeItem('nm2d_session_user');
  }, []);

  const [activeTab, setActiveTab] = useState<Tab>('home');
  const [active2DSection, setActive2DSection] = useState<'12:01 PM' | '04:30 PM'>('12:01 PM');
  const [liveData, setLiveData] = useState<LiveMarketData | null>(null);

  const [settings, setSettings] = useState<AppSettings>({
    serverOnline: true,
    maintenanceMessage: 'System is currently undergoing maintenance. Please check back shortly.',
    closedNumbers2D_1201: ['18', '24', '79', '99'],
    closedNumbers2D_1630: ['05', '33', '88'],
    closedNumbers3D: [],
    limit2D: 100000,
    limit3D: 50000,
    closeTime2D_1201: '11:50 AM',
    closeTime2D_1630: '03:50 PM',
    closeTime3D: '02:30 PM',
    closeDays2D: ['Saturday', 'Sunday'],
    multiplier2D: 80,
    commissionRate2D: 0.12,
    multiplier3D: 500,
    commissionRate3D: 0.10,
    official3DResults: {},
    manual3DResult: '',
    announcement: 'Welcome to NM 2D Official • Live Thai Stock 2D & 3D System • 12:01 PM & 4:30 PM Sections • 3D 500x Multiplier',
    minVersion: '1.0.0',
    serviceLink1: { label: 'Viber Support Channel', url: 'https://viber.com' },
    serviceLink2: { label: 'Telegram Customer Care', url: 'https://telegram.org' },
  });

  // Fetch settings from server / Supabase
  const fetchSettings = async () => {
    if (!navigator.onLine) return;
    try {
      const res = await fetch('/api/settings');
      if (res.ok) {
        const data = await res.json();
        setSettings(data);
      }
    } catch (e) {
      // Keep defaults
    }
  };

  // Fetch market data from server
  const fetchMarketData = async () => {
    if (!navigator.onLine) return;
    try {
      const res = await fetch('/api/live');
      if (res.ok) {
        const data = await res.json();
        setLiveData(data);
      }
    } catch (e) {
      // Keep fallback
    }
  };

  // Refresh user balance from server
  const refreshUserData = async () => {
    if (!currentUser || !navigator.onLine) return;
    try {
      const res = await fetch(`/api/users/${currentUser.id}`);
      if (res.ok) {
        const data = await res.json();
        setCurrentUser(data);
        if (localStorage.getItem('nm2d_remember_user')) {
          localStorage.setItem('nm2d_remember_user', JSON.stringify(data));
        } else {
          sessionStorage.setItem('nm2d_session_user', JSON.stringify(data));
        }
      }
    } catch (e) {
      // Keep state
    }
  };

  useEffect(() => {
    fetchSettings();
    fetchMarketData();

    // Real-time synchronization polling (reflects changes made in Supabase automatically)
    const syncInterval = setInterval(() => {
      fetchSettings();
      if (currentUser) {
        refreshUserData();
      }
    }, 4000);

    return () => clearInterval(syncInterval);
  }, [currentUser?.id]);

  const handleLoginSuccess = (user: User) => {
    setCurrentUser(user);
    setActiveTab('home');
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('nm2d_remember_user');
    sessionStorage.removeItem('nm2d_session_user');
    setActiveTab('home');
  };

  // ==========================================
  // PLAYER MOBILE APP VIEW (User Side)
  // No admin links or buttons are visible to users
  // ==========================================
  const renderAppContent = () => {
    // 1. Full Offline Block: If no internet connection, completely prevent all operations
    if (!isOnline) {
      return (
        <div className="flex flex-col items-center justify-center h-full w-full max-w-lg md:max-w-xl mx-auto bg-[#080d1a] p-6 text-center select-none text-slate-100">
          <div className="w-16 h-16 rounded-3xl bg-rose-500/15 border border-rose-500/30 flex items-center justify-center text-rose-400 mb-4 animate-pulse">
            <WifiOff className="w-8 h-8" />
          </div>
          <h2 className="text-lg font-black text-white uppercase tracking-wider mb-2">
            No Internet Connection
          </h2>
          <p className="text-xs text-rose-300 max-w-xs leading-relaxed mb-6 font-medium">
            အင်တာနက်လိုင်းမရှိပါ။ အင်တာနက်လိုင်း ပြန်လည်ရရှိမှသာ စနစ်အား အသုံးပြုနိုင်ပါမည်။ (Internet connection is required to use this application)
          </p>
          <button
            onClick={() => {
              playTouchSound('tap');
              setIsOnline(navigator.onLine);
              fetchSettings();
            }}
            className="px-5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 hover:border-cyan-400 text-xs font-bold text-cyan-300 flex items-center gap-2 cursor-pointer shadow-lg active:scale-95 transition-all"
          >
            <RefreshCw className="w-4 h-4" />
            <span>စစ်ဆေးမည် (Retry Connection)</span>
          </button>
        </div>
      );
    }

    // 2. System Offline / Maintenance Mode
    // If system server is turned off by admin, block everyone except admin
    if (settings.serverOnline === false && currentUser?.role !== 'admin') {
      return (
        <div className="flex flex-col items-center justify-center h-full w-full max-w-lg md:max-w-xl mx-auto bg-[#080d1a] p-6 text-center select-none text-slate-100">
          <div className="w-16 h-16 rounded-3xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400 mb-4 animate-pulse">
            <ShieldAlert className="w-8 h-8" />
          </div>
          <h2 className="text-lg font-black text-white uppercase tracking-wider mb-2">
            System Maintenance
          </h2>
          <p className="text-xs text-amber-300 max-w-xs leading-relaxed mb-6 font-medium">
            {settings.maintenanceMessage || 'စနစ်အား ယာယီပြုပြင်ထိန်းသိမ်းနေပါသည်။ ခေတ္တစောင့်ဆိုင်းပြီးနောက် ပြန်လည်ဝင်ရောက်ပေးပါ။'}
          </p>
          <button
            onClick={() => {
              playTouchSound('tap');
              fetchSettings();
              if (currentUser) refreshUserData();
            }}
            className="px-5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 hover:border-cyan-400 text-xs font-bold text-cyan-300 flex items-center gap-2 cursor-pointer shadow-lg active:scale-95 transition-all"
          >
            <RefreshCw className="w-4 h-4" />
            <span>ပြန်လည်စစ်ဆေးမည် (Check Again)</span>
          </button>
        </div>
      );
    }

    // If user is not authenticated, show Login Screen
    if (!currentUser) {
      return <LoginScreen onLoginSuccess={handleLoginSuccess} />;
    }

    return (
      <div className="flex flex-col h-full w-full max-w-xl mx-auto bg-[#080d1a] overflow-hidden select-none border-0 md:border-x md:border-slate-800/40 shadow-2xl relative">
        {/* SCREEN ROUTING CONTAINER */}
        <div className="flex-1 overflow-hidden relative">
          {activeTab === 'home' && (
            <HomeScreen
              user={currentUser}
              announcement={settings.announcement}
              onRefreshBalance={refreshUserData}
            />
          )}

          {activeTab === '2d' && (
            <Bet2DScreen
              user={currentUser}
              initialSection={active2DSection}
              settings={settings}
              liveData={liveData}
              onRefreshUserData={refreshUserData}
              onBackToHome={() => setActiveTab('home')}
            />
          )}

          {activeTab === '3d' && (
            <Bet3DScreen
              user={currentUser}
              settings={settings}
              onRefreshUserData={refreshUserData}
              onBackToHome={() => setActiveTab('home')}
            />
          )}

          {activeTab === 'ledger' && (
            <LedgerScreen
              user={currentUser}
              onBackToHome={() => setActiveTab('home')}
            />
          )}

          {activeTab === 'profile' && (
            <ProfileScreen
              user={currentUser}
              settings={settings}
              onLogout={handleLogout}
              onUpdateSettings={setSettings}
              onRefreshData={() => {
                fetchSettings();
                refreshUserData();
              }}
              onBackToHome={() => setActiveTab('home')}
            />
          )}
        </div>

        {/* FIXED BOTTOM NAVIGATION BAR: Home | 2D Bet | 3D Bet | Ledger | Profile */}
        <nav className="shrink-0 h-16 bg-[#060b17]/95 backdrop-blur-md border-t border-slate-800/80 px-2 flex items-center justify-around z-30">
          {/* Home */}
          <button
            onClick={() => {
              playTouchSound('select');
              setActiveTab('home');
            }}
            className={`flex flex-col items-center justify-center flex-1 py-1 transition-all cursor-pointer ${
              activeTab === 'home' ? 'text-cyan-400 scale-105' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Home className="w-5 h-5 mb-0.5" />
            <span className="text-[10px] font-bold tracking-tight">Home</span>
          </button>

          {/* 2D Bet */}
          <button
            onClick={() => {
              playTouchSound('select');
              setActiveTab('2d');
            }}
            className={`flex flex-col items-center justify-center flex-1 py-1 transition-all cursor-pointer ${
              activeTab === '2d' ? 'text-cyan-400 scale-105' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Flame className="w-5 h-5 mb-0.5" />
            <span className="text-[10px] font-bold tracking-tight">2D Bet</span>
          </button>

          {/* 3D Bet */}
          <button
            onClick={() => {
              playTouchSound('select');
              setActiveTab('3d');
            }}
            className={`flex flex-col items-center justify-center flex-1 py-1 transition-all cursor-pointer ${
              activeTab === '3d' ? 'text-cyan-400 scale-105' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Box className="w-5 h-5 mb-0.5" />
            <span className="text-[10px] font-bold tracking-tight">3D Bet</span>
          </button>

          {/* Ledger */}
          <button
            onClick={() => {
              playTouchSound('select');
              setActiveTab('ledger');
            }}
            className={`flex flex-col items-center justify-center flex-1 py-1 transition-all cursor-pointer ${
              activeTab === 'ledger' ? 'text-cyan-400 scale-105' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileText className="w-5 h-5 mb-0.5" />
            <span className="text-[10px] font-bold tracking-tight">Ledger</span>
          </button>

          {/* Profile */}
          <button
            onClick={() => {
              playTouchSound('select');
              setActiveTab('profile');
            }}
            className={`flex flex-col items-center justify-center flex-1 py-1 transition-all cursor-pointer ${
              activeTab === 'profile' ? 'text-cyan-400 scale-105' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <UserIcon className="w-5 h-5 mb-0.5" />
            <span className="text-[10px] font-bold tracking-tight">Profile</span>
          </button>
        </nav>
      </div>
    );
  };

  // If viewMode is 'admin', render dedicated Web Admin Control Center
  // Note: Admin panel is protected by master password 'waizin4700'
  if (viewMode === 'admin') {
    return (
      <div className="min-h-screen w-full bg-[#060b17] flex flex-col">
        <WebAdminPortal
          settings={settings}
          onUpdateSettings={setSettings}
        />
      </div>
    );
  }

  // ==========================================
  // PLAYER MOBILE APP VIEW (User Side)
  // No admin links or buttons are visible to users
  // ==========================================
  return (
    <div className="flex flex-col h-screen w-full bg-[#080d1a] overflow-hidden">
      <div className="flex-1 overflow-hidden">
        {renderAppContent()}
      </div>
    </div>
  );
}
